% GENERATE_PERFORMANCE_MAPS
% Sweep Mach and altitude ONLY within valid engine operating envelope:
%   Mach 0–1.6
%   Altitude 0–15.3 km
%   PLA ≤ 1.3, AB ∈ [0,1]

clear; clc;

% --- Path setup ---
this_dir = fileparts(mfilename('fullpath'));
project_root = fileparts(this_dir);
addpath(project_root);
subfolders = {'core','data','main','physics','tests','utilities'};
for k = 1:numel(subfolders)
    addpath(genpath(fullfile(project_root, subfolders{k})));
end

% --- Inputs ---
cfg = config_model();
base_inputs = load_inputs(cfg);
params = base_inputs.params;

% --- Hard limits of operating envelope ---
MAX_MACH = 1.6;
MAX_ALT  = 15.3e3;   % meters
MAX_PLA  = 1.3;

% --- Sweep definition (clamped to envelope bounds) ---
mach_vals   = linspace(0, MAX_MACH, 13);
alt_vals_m  = linspace(0, MAX_ALT, 11);
[Mach_grid, Alt_grid] = meshgrid(mach_vals, alt_vals_m);

% Select a small set of throttle levels within valid envelope
pla_levels   = [0.6, 1.0, 1.2];       % all ≤ 1.3
ab_levels    = [0,   0,   1];
level_names  = {'MIL PLA=0.6','MAX Dry PLA=1.0','AB PLA=1.2'};

num_alt    = numel(alt_vals_m);
num_mach   = numel(mach_vals);
num_levels = numel(pla_levels);

Thrust = nan(num_alt, num_mach, num_levels);
TSFC   = nan(num_alt, num_mach, num_levels);
Tt4    = nan(num_alt, num_mach, num_levels);

% --- Solve cycle (clamped operations) ---
for lev = 1:num_levels
    PLA_cmd = min(pla_levels(lev), MAX_PLA);   % safety clamp

    for ia = 1:num_alt
        for im = 1:num_mach

            % ensure atmospheric point is inside envelope
            alt_val = min(alt_vals_m(ia), MAX_ALT);
            mach_val = min(mach_vals(im), MAX_MACH);

            op = struct();
            op.params = params;
            op.atm = struct('alt', alt_val, ...
                            'M0', mach_val, ...
                            'use_standard_atm', true);
            op.PLA = PLA_cmd;
            op.AB  = ab_levels(lev);

            out = solve_cycle(cfg, op);

            % store results
            Thrust(ia, im, lev) = out.Thrust;
            TSFC(ia, im, lev)   = out.TSFC;
            if isfield(out,'Tt4')
                Tt4(ia, im, lev) = out.Tt4;
            end
        end
    end
end

% --- Plot directory ---
plots_dir = fullfile(project_root,'data','plots');
if ~exist(plots_dir,'dir')
    mkdir(plots_dir);
end

alt_vals_km = alt_vals_m / 1000;

% Choose readable subset for 2D plots
alt_indices  = unique(round(linspace(1, num_alt, min(num_alt, 4))));
mach_indices = unique(round(linspace(1, num_mach, min(num_mach,4))));
colors_alt  = lines(numel(alt_indices));
colors_mach = lines(numel(mach_indices));

% --- Plotting (all envelopes strictly clamped) ---
for lev = 1:num_levels
    thrust_kN = Thrust(:,:,lev) / 1000;
    tsfc_vals = TSFC(:,:,lev);

    % Thrust vs Mach (within envelope)
    fig1 = figure('Visible','off','Color','w');
    hold on; grid on;
    for ia = 1:numel(alt_indices)
        idx = alt_indices(ia);
        plot(mach_vals, thrust_kN(idx,:), 'LineWidth', 1.8, 'Color', colors_alt(ia,:));
    end
    xlabel('Mach'); ylabel('Thrust [kN]');
    title(sprintf('Thrust vs Mach (%s)', level_names{lev}));
    legend(arrayfun(@(a) sprintf('Alt %.1f km', alt_vals_km(a)), alt_indices,'UniformOutput',false));
    exportgraphics(fig1, fullfile(plots_dir, sprintf('thrust_vs_mach_level%d.png',lev)));
    close(fig1);

    % TSFC vs Mach
    fig2 = figure('Visible','off','Color','w');
    hold on; grid on;
    for ia = 1:numel(alt_indices)
        idx = alt_indices(ia);
        plot(mach_vals, tsfc_vals(idx,:), 'LineWidth', 1.8, 'Color', colors_alt(ia,:));
    end
    xlabel('Mach'); ylabel('TSFC [kg/N/s]');
    title(sprintf('TSFC vs Mach (%s)', level_names{lev}));
    exportgraphics(fig2, fullfile(plots_dir, sprintf('tsfc_vs_mach_level%d.png',lev)));
    close(fig2);

    % Thrust vs Altitude
    fig3 = figure('Visible','off','Color','w');
    hold on; grid on;
    for im = 1:numel(mach_indices)
        idx = mach_indices(im);
        plot(alt_vals_km, thrust_kN(:,idx), 'LineWidth', 1.8, 'Color', colors_mach(im,:));
    end
    xlabel('Altitude [km]'); ylabel('Thrust [kN]');
    title(sprintf('Thrust vs Altitude (%s)', level_names{lev}));
    exportgraphics(fig3, fullfile(plots_dir, sprintf('thrust_vs_alt_level%d.png',lev)));
    close(fig3);

    % TSFC vs Altitude
    fig4 = figure('Visible','off','Color','w');
    hold on; grid on;
    for im = 1:numel(mach_indices)
        idx = mach_indices(im);
        plot(alt_vals_km, tsfc_vals(:,idx), 'LineWidth', 1.8, 'Color', colors_mach(im,:));
    end
    xlabel('Altitude [km]'); ylabel('TSFC [kg/N/s]');
    title(sprintf('TSFC vs Altitude (%s)', level_names{lev}));
    exportgraphics(fig4, fullfile(plots_dir, sprintf('tsfc_vs_alt_level%d.png',lev)));
    close(fig4);
end

% Save results
map = struct();
map.mach_vals   = mach_vals;
map.alt_vals_m  = alt_vals_m;
map.PLA_levels  = pla_levels;
map.AB_levels   = ab_levels;
map.Thrust_N    = Thrust;
map.TSFC        = TSFC;
map.Tt4_K       = Tt4;

outfile = fullfile(project_root,'data','performance_map_results.mat');
save(outfile, '-struct', 'map');

fprintf('Saved envelope-clamped performance map to %s\n', outfile);
fprintf('Plots saved to %s\n', plots_dir);
