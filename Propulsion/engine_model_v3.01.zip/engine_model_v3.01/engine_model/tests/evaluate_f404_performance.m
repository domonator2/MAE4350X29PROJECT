% EVALUATE_F404_PERFORMANCE Quick helper to print dry and AB performance.
clear; clc;

project_root = fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(project_root));

cfg = config_model();
in = inputs_F404_defaults(cfg);

% Baseline operating point (sea-level static)
op = struct();
op.params = in.params;
op.atm = in.atm;
op.PLA = 1.0;
op.AB = 0.0;

% Dry check
dry = solve_cycle(cfg, op);

% Max AB check at full throttle
op.PLA = 1.3;
op.AB = 1.0;
wet = solve_cycle(cfg, op);

fprintf('Dry thrust (PLA=1.0, AB=0): %.2f kN, TSFC: %.4e kg/N/s\n', dry.Thrust/1000, dry.TSFC);
fprintf('AB thrust  (PLA=1.3, AB=1): %.2f kN, TSFC: %.4e kg/N/s\n', wet.Thrust/1000, wet.TSFC);

out_table = table( ...
    {'Dry'; 'Afterburning'}, ...
    [dry.Thrust; wet.Thrust] / 1000, ...
    [dry.TSFC; wet.TSFC], ...
    [1.0; 1.3], ...
    [0.0; 1.0], ...
    'VariableNames', {'Condition','Thrust_kN','TSFC_kg_per_N_s','PLA','AB'});
out_path = fullfile(project_root, 'data', 'f404_performance_check.csv');
writetable(out_table, out_path);
fprintf('Wrote verification metrics to %s\n', out_path);
