# AI Coding Agent Instructions for engine_model

## Project Overview
MATLAB-based modular thermodynamic model for a military turbofan jet engine (General Electric F404-GE-400 class). Models steady-state or transient operation across compressor, combustor, turbine, afterburner, nozzle, and bypass components. Outputs thrust, TSFC, and cycle station properties for performance analysis and control law development.

**Primary reference engines:**
- **General Electric F404-GE-400**: Powers FA-18 Hornets (2 engines per aircraft). Characteristics: 3-stage fan, variable inlet guide vanes, annular combustor, 2-stage turbine, variable nozzle, integral afterburner.
- See: Frith (ADA164562) for F404 architecture; Mattingly for cycle fundamentals; NACA/NASA turbine/compressor maps for off-design performance.

## Architecture: Core Execution Path
1. **`main/run_model.m`** – Entry point. Sets up paths, loads config/inputs, calls `simulate_engine()`, plots and saves results.
2. **`core/simulate_engine.m`** – Time-loop orchestrator. Iterates over N time steps, applies throttle schedules (PLA, AB), calls `solve_cycle()` for each point, collects results into arrays.
3. **`core/solve_cycle.m`** – **Central coordinator**. Single operating point solver:
   - Resolves atmosphere (altitude → ISA T₀, p₀, ρ₀, V₀)
   - Computes inlet ram effects and pressure recovery
   - Estimates core/fan mass flow from corrected flow and inlet swallow constraints
   - Calls physics modules in order: compressor → combustor → turbine → afterburner → nozzle/mixer
   - Returns station totals (Pt, Tt at each station) and performance (OPR, f, thrust, TSFC)
4. **`core/compute_outputs.m`** – Extracts final metrics from `cycle` struct (work splits, thrust, fuel flow, TSFC).

## Critical Data Flow & Conventions

### Config (`cfg`) – Global Settings
- `cfg.const.*` – Thermodynamic constants (R, cp, γ, γ_hot)
- `cfg.params.*` – Nominal baseline values (PR_c, eta_c, eta_t, p_drop_comb, mdot)
- `cfg.dt`, `cfg.t_end` – Time step and simulation duration
- `cfg.save_path` – Output file path (relative paths resolved in project root)

### Inputs (`in`) – Run-Specific Data
Loaded from `data/load_inputs.m` (or external MAT file):
- `in.atm.*` – Atmosphere profiles: altitude, Mach, T₀, p₀ (can be scalars or vectors)
- `in.params.*` – Component parameters (override cfg.params): PR_c, eta_c, eta_t, nozzle areas, thrust/TSFC scales, etc.
- `in.schedules.PLA`, `in.schedules.AB` – Throttle/afterburner commands (vectors of length N)
- `in.time` – Time base for simulation (auto-filled if missing)

### Operating Point (`op`) – Per-step Snapshot
- `op.PLA`, `op.AB` – Throttle state (filtered via first-order lag with tau_PLA, tau_AB)
- `op.atm` – Atmosphere struct for this time step (sliced from in.atm)
- `op.params` – References in.params

### Cycle Struct (`cycle`) – Thermodynamic State & Schedule Resolution
Central struct in `solve_cycle()`. Contains:
- **Station totals**: Pt2 (inlet), Pt3 (compressor exit), Pt4 (burner exit), Pt9 (nozzle inlet), etc.
- **Temperature totals**: Tt2, Tt3, Tt4, Tt9, etc.
- **Control schedules**: PLA, AB_sched, AB_cmd, Tt4_cmd (set from interpolation tables)
- **Mass flows**: mdot_core, mdot_fan, mdot_capture (from corrected flow), bleed/cooling offsets
- **Derived props**: gamma_hot, thrust_scale, tsfc_scale (empirical corrections)
- **Nozzle state**: A8_cmd, A9_cmd (throat/exit areas from PLA/AB schedule)

**Key insight**: All throttle effects (PR_comp_eff, eta_comp_eff, Tt4_cmd, nozzle areas, thrust scale) are **scheduled** via `cycle.PLA` and `cycle.AB_cmd` **before** calling physics modules. Physics modules are **parameterless** beyond the instantaneous state.

### Results (`results`) – Output
Struct returned from `simulate_engine()`:
- Time-series arrays: `Tt2, Tt3, Tt4, Pt2, Pt3, Pt4, etc.` (each length N)
- Performance: `Thrust, TSFC, OPR, f` (fuel-air ratio)
- Command logs: `PLA, AB, Tt4_cmd, alt, M0, T0, p0`
- Saved to disk as MAT + human-readable CSV summary

## Nozzle Physics Improvements (v2.8+)

### Convergent-Divergent Nozzle with Full Isentropic Relations
**File: `physics/nozzle_model.m`**

The nozzle model now implements:
- **NPR_crit logic**: Correctly identifies choked (sonic throat) vs unchoked conditions
  - NPR_crit = ((γ+1)/2)^(γ/(γ-1)) ≈ 1.893 for γ=1.4
  - Throat becomes sonic when NPR > NPR_crit
- **Variable-area expansion**: For convergent-divergent nozzles (A9 > A8):
  - Subsonic exit if NPR < NPR_crit
  - Supersonic exit (M > 1) if NPR > NPR_crit and A_exit/A_throat > 1
  - Inverts area-Mach relation to find exit M given A/A*
- **Pressure thrust term**: Gross thrust = mdot·(Ve - V0) + (Pe - p0)·Ae
  - Captures back-pressure effects at high altitude or altitude cruise
- **Isentropic temperature/pressure relations**: Full temperature ratios T_ratio = 1 + 0.5·(γ-1)·M²
  - Uses hot-gas gamma (γ_hot ≈ 1.32 for post-combustor flow)
  - Properly accounts for high-temperature combustion products

### Inlet Recovery Schedule (Farokhi Sections 6.10-6.15)
**File: `utilities/inlet_recovery_schedule.m`** (new)

Replaces placeholder inlet_recovery_simple with MIL-standard normal-shock inlet losses:
- **Subsonic (M < 0.5)**: η ≈ 0.98–0.995 (minimal loss)
- **Transonic (M = 0.9–1.0)**: η ≈ 0.97–0.96 (inlet acceleration)
- **Supersonic (M = 1.2)**: η ≈ 0.92–0.88 (normal shock at inlet lip)
- **Hypersonic (M > 1.6)**: η ≈ 0.80–0.70 (strong shock + boundary layer effects)

Curve-fit to Farokhi Fig. 6.12 and MIL-standard inlet recovery tables. Uses normal-shock pressure relations:
$$\frac{Pt_{shock}}{Pt_0} = \left( \frac{2\gamma M_1^2 - (\gamma-1)}{(\gamma+1)} \right)^{\gamma/(\gamma-1)} \cdot \frac{(\gamma+1)/2}{1 + 0.5(\gamma-1)M_1^2}$$

Can override with custom table via `op.params.M_inlet_tab` / `op.params.eta_inlet_tab` (length N vectors)

## Tt4 Schedule & Compressor Corrections (Phase 2, v2.8+)

### Burner Exit Temperature Schedule (Tt4)
**File: `core/schedule_Tt4.m`**

PLA and AB-dependent combustor outlet temperature schedule based on F404 class engines:
- **Idle (PLA ≤ 0.3, AB=0)**: Tt4 ≈ 1000 K (~1340 R)
- **Mid-range (0.3 < PLA < 1.0, AB=0)**: Linear ramp → 1700 K at MIL
- **MIL dry (PLA ≥ 1.0, AB=0)**: Tt4 ≈ 1700 K (max without AB)
- **MAX AB (PLA ≥ 1.3, AB=1)**: Tt4 ≈ 2150 K (augmentor adds ~450 K above MIL baseline)

Default anchor values (tunable via `params.Tt4_idle`, `params.Tt4_MIL`, `params.Tt4_MAX`):
```matlab
Tt4_cmd = schedule_Tt4(PLA, AB, params);
```

**Assumptions**:
- Linear interpolation between breakpoints (conservative, suitable for control law development)
- No altitude correction (future: add SAT derate)
- AB effectiveness independent of compressor PR (simplified augmentor model)

### Compressor Mach-Dependent Corrections
**File: `physics/compressor_correction_factors.m`**

Kurzke-style Mach-dependent modifiers account for transonic inlet effects and shock losses:
- **PR correction**: 1.00 (M=0.0) → 0.94 (M=1.6) — accounts for compressor face distortion and weak shock losses
- **Efficiency correction**: 1.00 (M=0.0) → 0.98 (M=1.6) — transonic separation losses
- **Corrected mass flow**: 1.00 (M=0.0) → 1.02 (M=1.6) — inlet boundary layer effects and flow redistribution

```matlab
[PR_fac, eta_fac, Wc_fac] = compressor_correction_factors(M0);
PR_comp   = PR_nominal * PR_fac;
eta_comp  = eta_nominal * eta_fac;
mdot_core = mdot_nominal * Wc_fac;
```

**Physics basis**:
- M < 0.9: Minimal correction (subsonic flow, no shock)
- 0.9 ≤ M ≤ 1.2: Transonic inlet shock ramps up correction (normal shock at inlet lip)
- M > 1.2: External compression or variable intake scheduling (fixed wedge shape in model, assumed ~15° external compression)

**Validation**: Integrated into `solve_cycle()` line 135. Applied to core compressor model call before thermal cycle calculation. Compressor outlet (Pt3, Tt3) are now Mach-dependent, improving thrust slope at high Mach.

Each module (in `physics/`) takes **only** the instantaneous state + constants, computes output state, and returns. No internal maps or state evolution (maps are embedded in `solve_cycle.m` schedule resolution):

- **`compressor_model(cfg, inlet, params)`** – isentropic relations. Inputs: Pt_in, Tt_in, PR, eta. Outputs: Pt_out, Tt_out, specific work.
- **`combustion_model(cfg, comb_in, comb_params)`** – enthalpy balance + fuel flow. Inputs: Pt3, Tt3, mdot_air, Tt4_target. Outputs: Pt4, Tt4, fuel-air ratio f.
- **`turbine_model(cfg, turb_in, turb_params)`** – work extraction. Inputs: Pt4, Tt4, w_required, eta. Outputs: Pt5, Tt5, specific work.
- **`augmentor_model(cfg, aug_in)`** – afterburner (optional). Inputs: Pt5, Tt5, AB schedule. Outputs: Pt9, Tt9, dTt, mdot_fuel.
- **`nozzle_model(...)`** – thrust calculation from flow/pressure expansion. Inputs: mixed Pt9, Tt9, mdot_total, geometry (A8, A9), freestream (T0, M0). Outputs: thrust (Fg), exit velocity, actual mdot flowed.

**Pattern**: Each module returns a struct with `.Pt_out`, `.Tt_out`, and performance metrics. Pass results forward via `cycle` struct.

## Schedule Resolution & Throttle Logic

**PLA (Power Lever Angle)** – Primary throttle, 0.3 (idle) to ~1.3 (full AB):
- Maps to compressor PR_c and eta_c via Mach/altitude corrections
- Maps to burner outlet temperature Tt4 via lookup table `pla_breaks_dry` / `Tt4_dry_table`
- Maps to nozzle geometry (A8, A9) via extended schedules
- Empirical thrust scale applied post-physics

**AB (Afterburner)** – Scheduled as 0 (dry) to 1.0 (full AB):
- Only active if PLA > `PLA_idle` (e.g., 0.3)
- Blends between dry/AB nozzle areas and thrust scales
- Fuel only added if AB > 0 (via augmentor)

**Corrected Flow** – Mass flow normalization:
- Accounts for altitude/Mach via $\frac{W_c}{\sqrt{\theta}} = \text{const}$ scaling
- Clamped to inlet capture area and swallow limits to prevent unphysical growth
- Fallback: if no table, uses PLA-based scaling via `mdot_pla_tab` / `mdot_pla_scale`

**Empirical Corrections** – Applied to pure physics:
- Thrust scale: base (dry/AB) × Mach correction × altitude correction × PLA correction
- TSFC scale: blended dry→AB based on AB command
- Allow bounds: 0.4–2.0× to prevent extreme errors

## Input Data Handling

### MAT-file Schema (Optional)
If loading from external file, expected structure:
```
in.atm.T0, in.atm.p0, in.atm.M0, in.atm.alt  [can be scalar or vector of length N]
in.params    [struct with PR_c, eta_c, Tt4, eta_t, p_drop_comb, mdot, nozzle areas, scales, etc.]
in.time      [optional; auto-filled if absent]
in.schedules.PLA, in.schedules.AB  [vectors of length N]
```

### Profile Expansion
If scalar atmosphere provided, expanded to all N time steps. If vector, must match length N exactly.

### Baseline Defaults
`data/inputs_F404_defaults.m` provides starter values (mdot_core_nom ≈ 28 kg/s, OPR ≈ 12, Tt4 ≈ 1550 K). Override in MAT file or `cfg.params` for custom engine.

## Development Patterns

### Adding a New Component Model
1. Create `physics/component_model.m` with signature: `output = component_model(cfg, input_struct, param_struct)`
2. Input struct contains: Pt_in, Tt_in, mdot_in (as needed)
3. Output struct contains: Pt_out, Tt_out, plus specific work / efficiency / metrics
4. Insert call in `solve_cycle.m` **after prerequisite stations are set** and **before** stations that depend on it
5. Pack output into `cycle` struct (e.g., `cycle.Pt4 = output.Pt_out`)
6. Call `compute_outputs()` at end to roll new metrics into final summary

### Testing a Component in Isolation
- Create unit test in `tests/test_component.m`
- Call component with known inlet state and params, verify outlet makes thermodynamic sense
- Use `standard_atmosphere()` for reference T₀, p₀
- Example: compressor isentropic efficiency should be 0.7–0.95 for realistic engines

### Off-Design / Variable Gamma
- Combustor currently sets `gamma_hot` ≈ 1.32; turbine/nozzle use this for hot-gas expansion
- `cycle.gamma_hot` can be refined if fuel flow / composition is tracked
- Nozzle already has hook: passes `const_hot` with `gamma_hot` field

### Empirical vs. Physics Tuning
- Keep component models **physics-first** (isentropic + efficiency + pressure loss)
- Use **schedule tables** and **empirical scales** in `solve_cycle.m` for off-design corrections
- Reason: easy to validate physics in isolation; corrections localized to one function

## Key Helper Functions

### `getfieldwithdefault(struct, name, default)`
Safely extract struct fields with fallback to default. Used ubiquitously to handle optional parameters.

### `standard_atmosphere(alt_m)`
Returns (Tstd, Pstd, Dstd) for ISA at altitude. Called if `in.atm.use_standard_atm = true` (default).

### `interp1(x, y, xq, 'pchip', 'extrap')`
Cubic interpolation with extrapolation. Used for all schedule lookups (PLA → Tt4, Mach → thrust scale, etc.). **Always use 'pchip' + 'extrap' for smooth transients and bounded table extrapolation.**

## Validation & Debugging Checklist

### Current Accuracy Claims (v2.8+)

**VALIDATED OPERATING ENVELOPE:**
- **Mach range**: 0.0 to 0.9 (subsonic)
- **Altitude range**: 0 to 10 km
- **Throttle**: Full idle (0.3 PLA) to max dry (1.0 PLA)
- **Accuracy**: Dry thrust ±10–15%, TSFC trend ±12–18%
- **Physics**: Nozzle isentropic + inlet losses properly included

**IN DEVELOPMENT (requires further table calibration):**
- **Mach 0.9–1.2**: Convergent nozzle with normal-shock inlet
  - Expected accuracy ±8–12% once Tt4 schedule tuned to TM-4538
- **Mach 1.2–1.6**: Convergent-divergent with supersonic exit
  - Expected accuracy ±5–10% post-physics validation
- **Altitude 10–16 km**: Corrected-speed + altitude pressure effects
  - Requires Mach-dependent compressor PR/η schedules (Kurzke method)
- **Afterburner (AB > 0)**: Tt9 varies with PLA + AB fraction
  - Expected accuracy ±10–15% once TM-88273 Tt9 profiles integrated

**NOT YET VALID:**
- Any unchoked nozzle regime (rare; NPR_crit ≈ 1.9 provides margin)
- Shock-on-lip inlet buzz or buzz-off conditions
- Compressor surge/stall (no stall line modeling)
- Detailed stage-by-stage compressor behavior
- Variable-geometry inlet (slats/ramps) – normal shock assumed
- Afterburner thermal lag or fuel mixing delays

### F404 Design-Point Performance (ISA SLS, Sea Level, Standard Conditions)
**From ADA164562 (Frith) and design datasheets:**

| Parameter | Dry (Max) | Full AB | Unit | Notes |
|-----------|-----------|---------|------|-------|
| **Core mass flow** | 28–30 | 28–30 | kg/s | Slight increase possible via AB fuel |
| **Bypass ratio (BPR)** | 0.27–0.30 | 0.27–0.30 | – | Fan/core flow ratio; relatively low (afterburner-optimized) |
| **Overall pressure ratio (OPR)** | 12.0–14.0 | 12.0–14.0 | – | Compressor PR; roughly constant at design RPM |
| **Compressor efficiency** | 0.84–0.87 | 0.84–0.87 | – | Polytropic ~0.86; varies with speed/altitude |
| **Turbine efficiency** | 0.88–0.92 | 0.88–0.92 | – | Hot gas; higher than compressor |
| **Burner outlet (Tt4, dry)** | 1650–1680 | – | K | Design turbine inlet temperature; material limit ~1670 K |
| **Burner outlet (Tt4, AB engaged)** | – | 1650–1680 | K | AB heats core further; Tt9 can reach 1850+ K |
| **Thrust (dry)** | ~43–48 | – | kN | 2 engines total ≈ 90 kN dry; model 1 engine |
| **Thrust (full AB)** | – | ~70–80 | kN | 2 engines ≈ 160 kN AB; model 1 engine |
| **TSFC (dry)** | 0.65–0.75 | – | kg/(N·h) | Fuel burn per unit thrust |
| **TSFC (AB)** | – | 1.2–1.6 | kg/(N·h) | Significantly worse due to excess fuel injection |
| **Nozzle exit velocity** | 600–700 | 700–850 | m/s | Core + bypass mixed (with ram effects at speed) |
| **Inlet pressure recovery** | >0.95 (M=0) | >0.95 | – | ~0.98 at SLS; drops ~0.02–0.05 at M=0.9 |

### Typical Operating Ranges (Off-Design Corrections)
- **Altitude effect**: OPR and mass flow reduce ~2% per 1000 ft at constant PLA (corrected flow dominates)
- **Mach effect**: Inlet total temperature rise adds ~5–10 K per 0.1 Mach at SLS; total pressure recovery drops for M > 0.5
- **PLA schedule**: Idle ≈ 0.3 PLA → ~0.6 Tt4; Max dry ≈ 1.0 PLA → 1.65–1.68 Tt4; Max AB ≈ 1.3 PLA → +120–150 K dTt AB
- **Throttle transient**: Rise time ~1–3 s for full dry-to-AB transient (lag via tau_PLA, tau_AB)

### Model Validation Steps
1. **Design point check** (ISA SLS, M=0, PLA=1.0 dry):
   - Verify mdot_core ≈ 28 kg/s
   - Verify OPR ≈ 12–13
   - Verify Tt4 ≈ 1650–1680 K
   - Verify thrust ≈ 43–48 kN (before empirical scale correction)
   - Verify TSFC ≈ 0.7 kg/(N·h) before scale factor

2. **Idle check** (ISA SLS, M=0, PLA=0.3):
   - mdot_core should drop ~15–20% (corrected flow margin)
   - Tt4 should drop to ~1100–1200 K
   - Thrust should be ~10–15 kN
   - Engine should not stall (mdot > 0, Pt > 1 atm)

3. **High-altitude check** (35,000 ft, M=0.85, PLA=1.0):
   - Corrected mass flow should stay ~95–100% of design (swallow + corrected flow effects)
   - OPR may drop ~5–10% (lower altitude pressure and density)
   - Thrust reduces ~30–50% due to ambient pressure and temperature

4. **Afterburner check** (ISA SLS, M=0, PLA=1.0, AB=1.0):
   - Tt9 should reach 1850–1950 K (Tt4 + dTt_ab)
   - Thrust should increase ~45–55% over dry
   - mdot_fuel_ab should be ~10–15% of mdot_core
   - TSFC should double or triple

### Debugging Tools
- Use `print_run_summary()` in `run_model.m` to spot NaN or out-of-range values
- Save and inspect CSV summary for time-series anomalies
- Plot Pt and Tt at each station to verify monotonic pressure drop across ducts and expansion through turbine
- Check compressor work = turbine work (within small tolerance for shaft losses)
- Verify fuel-air ratio stays < 0.05 (physical limit for stoichiometry)

## File Organization Rules
- **No subdirectories inside `core/`, `physics/`, etc.** – All functions in flat folders for simplicity
- **Config** goes in `main/config_model.m` (never hardcoded in functions)
- **Input data** stored in `data/` as MAT files or defaults generators
- **Results** saved to `data/` with timestamp or run label
- **Plots** generated in `main/plot_results.m` from results struct

## Common Pitfalls
1. **Forgetting to filter throttle via first-order lag** – Will cause step input shocks. Use tau_PLA, tau_AB in `simulate_engine()`.
2. **Passing cycle struct BY REFERENCE and mutating in physics modules** – Keep modules pure; all outputs go back to cycle in solve_cycle only.
3. **Mismatched profile lengths** – Always expand scalar/vector atmosphere to length N in `load_inputs()`.
4. **Using cold-air gamma in hot-gas nozzle** – Set `gamma_hot = 1.32` for hot sections post-combustor; nozzle will apply it.
5. **Extrapolating schedules beyond table bounds** – 'pchip' + 'extrap' is safe; avoid hard clipping that breaks smooth transitions.

## Literature & References

### Primary F404 Documentation
- **Frith, Denis (ADA164562)**: "The General Electric F404 - Engine of the RAAF's New Fighter." RAAF Technical Report. Covers architecture (3-stage fan, annular combustor, 2-stage turbine), variable geometry scheduling, off-design behavior, and maintenance.
- **AIAA/NASA F404 Performance Paper (19940010668)**: Contains detailed performance maps and empirical corrections for Mach/altitude effects; thrust and TSFC scaling factors.

### Fundamental Cycle Theory
- **Mattingly et al., "Aircraft Engine Design" (2nd ed.)**: Chapter 3–5 cover thermodynamic cycle analysis, compressor/turbine efficiency definitions (polytropic vs. adiabatic), off-design performance prediction, and corrected flow concepts. **Essential for understanding cycle equations and assumptions in this model.**
- **NACA/NASA turbine and compressor reports**: Original efficiency and loss models; reference for tuning `eta_c`, `eta_t`, and `PR_eff` maps.

### Key Cycle Assumptions in This Model
**Aligned with Mattingly & ADA164562:**
1. **Compressor**: Lumped axial/centrifugal stages; efficiency modeled as constant polytropic or adiabatic. Real maps would account for stage-by-stage pressure ratios.
2. **Combustor**: Simple enthalpy balance (conserve energy input, account for burner pressure loss ~3–5%). Variable gamma (γ_hot ≈ 1.32) for hot gas; fuel heat of reaction ~43 MJ/kg.
3. **Turbine**: Expansion isentropic relations; efficiency typically 88–92% polytropic (higher than compressor due to favorable pressure gradients). Model assumes uncooled turbine or averaged cooling losses.
4. **Nozzle**: Isentropic + discharge coefficient; throat conditions set by mass flow balance; exit Mach determined from subsonic or sonic flow (shock-free assumption for design point).
5. **Corrected Flow** ($\dot{W}_c$): Mass flow normalized via $\frac{\dot{m} \sqrt{\theta}}{\delta}$ where θ = T_t / T_ref, δ = P_t / P_ref. Accounts for altitude/Mach changes without explicit maps.

### Typical Parameter Ranges (Reference ADA164562 + Mattingly)
- **Polytropic compressor efficiency** (e_c): 0.82–0.88 (Mattingly suggests 0.84–0.87 for modern axial compressors)
- **Polytropic turbine efficiency** (e_t): 0.87–0.94 (hot gas benefits from expansion ratio)
- **Combustor pressure loss** (Δp/p): 0.03–0.05 (annular combustor ≈ 4–5%)
- **Inlet pressure recovery**: 0.95–0.99 (subsonic); 0.85–0.98 (supersonic inlet at M > 0.9) per Mattingly Fig. 3.10
- **Burner fuel-air ratio** (f): 0.018–0.030 for kerosene; model caps at 0.05 for safety
- **Thrust coefficient** (Cd): 0.95–0.98 for convergent nozzle; includes friction + base pressure effects

### Empirical Corrections in This Model
Model uses **Mattingly + AFRL methodology** (as referenced in papers like 19940010668):
- **Corrected flow vs. PLA**: Non-linear schedule to prevent idle overprediction
- **Mach/altitude thrust scaling**: Accounts for inlet ram recovery and mission profiles not captured in physics-only approach
- **TSFC blending dry→AB**: Empirical to match published performance data (Frith, ADA164562)

This approach **balances physics fidelity with practical engineering accuracy** – keeping component models fundamental but allowing schedule tables to tune off-design behavior.

