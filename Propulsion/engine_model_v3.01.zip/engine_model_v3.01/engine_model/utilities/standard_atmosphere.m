function [a, rho, mu, nu, theta, delta, sigma, z, P, T] = standard_atmosphere(h, units)
%STANDARD_ATMOSPHERE ISO 2533:1975 standard atmosphere model with viscosity.
% More accurate model with support for SI and English units.
% Inputs:
%   h     : geometric altitude [m] or [ft] if units='EN'
%   units : 'SI' (default) or 'EN' for English units
% Outputs:
%   a     : speed of sound [m/s] or [ft/s]
%   rho   : density [kg/m^3] or [slug/ft^3]
%   mu    : dynamic viscosity [Ns/m^2] or [lbf*s/ft^2]
%   nu    : kinematic viscosity [m^2/s] or [ft^2/s]
%   theta : temperature ratio (T/T0)
%   delta : pressure ratio (P/P0)
%   sigma : density ratio (rho/rho0)
%   z     : geopotential altitude [m] or [ft]
%   P     : pressure [Pa] or [lbf/ft^2]
%   T     : temperature [K] or [°R]

% Physical constants (SI)
R = 287.0528;      % air gas constant [J/(kg*K)]
gamma = 1.4;       % specific heat ratio
g0 = 9.805545;     % gravitational acceleration [m/s^2]
T0 = 288.15;       % sea level temperature [K]
P0 = 101325;       % sea level pressure [Pa]
rho0 = P0 / (R * T0);  % sea level density [kg/m^3]
RE = 6378137;      % Earth's radius [m]

% Handle units input (default to SI)
if nargin < 2
    units = 'SI';
end

% Convert English altitude to SI first
if strcmp(units, 'EN')
    h = h * 0.3048;  % convert ft to m
end

% Compute geopotential altitude
z = (RE * h) / (RE + h);

% Compute temperature and pressure by altitude layer
if 0 <= z && z <= 11000
    Ti = 288.15;
    dT_dz = -6.5e-3;
    Pi = 101325;
    zi = 0;
    T = Ti + dT_dz * (z - zi);
    P = Pi * (T / Ti)^(-g0 / (R * dT_dz));
    
elseif 11000 < z && z <= 20000
    Ti = 216.65;
    dT_dz = 0;
    Pi = 22632.049;
    zi = 11000;
    T = Ti;
    P = Pi * exp(-g0 * (z - zi) / (R * Ti));
    
elseif 20000 < z && z <= 32000
    Ti = 216.65;
    dT_dz = 1e-3;
    Pi = 5474.882;
    zi = 20000;
    T = Ti + dT_dz * (z - zi);
    P = Pi * (T / Ti)^(-g0 / (R * dT_dz));
    
elseif 32000 < z && z <= 47000
    Ti = 228.65;
    dT_dz = 2.8e-3;
    Pi = 868.017;
    zi = 32000;
    T = Ti + dT_dz * (z - zi);
    P = Pi * (T / Ti)^(-g0 / (R * dT_dz));
    
elseif 47000 < z && z <= 52000
    Ti = 270.65;
    dT_dz = 0;
    Pi = 110.906;
    zi = 47000;
    T = Ti;
    P = Pi * exp(-g0 * (z - zi) / (R * Ti));
    
elseif 52000 < z && z <= 61000
    Ti = 270.65;
    dT_dz = -2e-3;
    Pi = 59.001;
    zi = 52000;
    T = Ti + dT_dz * (z - zi);
    P = Pi * (T / Ti)^(-g0 / (R * dT_dz));
    
elseif 61000 < z && z <= 79000
    Ti = 252.65;
    dT_dz = -4e-3;
    Pi = 18.210;
    zi = 61000;
    T = Ti + dT_dz * (z - zi);
    P = Pi * (T / Ti)^(-g0 / (R * dT_dz));
    
elseif 79000 < z && z <= 90000
    Ti = 180.65;
    dT_dz = 0;
    Pi = 1.038;
    zi = 79000;
    T = Ti;
    P = Pi * exp(-g0 * (z - zi) / (R * Ti));
    
else
    % Beyond 90 km: extrapolate or set to vacuum
    T = 180.65;
    P = 1.038;
    if z > 90000
        P = P * exp(-g0 * (z - 90000) / (R * 180.65));
    end
end

% Compute derived properties
a = sqrt(gamma * R * T);           % speed of sound
rho = P / (R * T);                 % density
mu = (1.458e-6) * (T^1.5) / (T + 110.4);  % Sutherland viscosity
nu = mu / rho;                     % kinematic viscosity
theta = T / T0;                    % temperature ratio
delta = P / P0;                    % pressure ratio
sigma = rho / rho0;                % density ratio

% Convert to English units if requested
if strcmp(units, 'EN')
    a = a * 3.28084;       % m/s to ft/s
    rho = rho * 0.00194032;  % kg/m^3 to slug/ft^3
    mu = mu * 0.02088543;  % Ns/m^2 to lbf*s/ft^2
    nu = nu * 10.7639;     % m^2/s to ft^2/s
    z = z * 3.28084;       % m to ft
    P = P * 0.020885;      % Pa to lbf/ft^2
    T = T * 1.8;           % K to degrees Rankine
end

end
