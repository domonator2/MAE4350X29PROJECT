function eta_inlet = inlet_recovery_schedule(M0, inlet_type)
%INLET_RECOVERY_SCHEDULE Mach-dependent inlet total-pressure recovery.
%
% Farokhi Section 6.10-6.15: normal shock + external compression inlet losses
% MIL-standard normal-shock inlet (typical for military fighters)
%
% Inputs:
%   M0         : freestream Mach number              [-]
%   inlet_type : 'normal-shock', 'external', 'subsonic' (default: 'normal-shock')
%
% Outputs:
%   eta_inlet  : total-pressure recovery ratio       [-]
%
% Notes:
%   - Mach = 0.0-0.2: ~0.995-0.98 (subsonic inlet, minimal loss)
%   - Mach = 0.5-0.9: ~0.98-0.95 (subsonic ram, slight loss)
%   - Mach = 1.0-1.2: ~0.92-0.88 (normal shock, moderate loss)
%   - Mach = 1.6+   : ~0.80-0.70 (strong shock, high loss)
%
% Farokhi references: normal shock relations in high-speed inlets

if nargin < 2
    inlet_type = 'normal-shock';
end

M0 = max(M0, 0.0);

% Pressure recovery from normal shock (Farokhi 6.10-6.13)
eta_inlet = inlet_total_pressure_recovery(M0, inlet_type);

% Clamp to reasonable bounds
eta_inlet = max(min(eta_inlet, 1.0), 0.60);

end

function eta = inlet_total_pressure_recovery(M, inlet_type)
%INLET_TOTAL_PRESSURE_RECOVERY Compute Pt_recovery / Pt_freestream.
%
% Based on normal shock relations and external compression inlet efficiency.
% Data curve-fit to Farokhi Fig. 6.12 (normal shock inlet) and MIL-standard
% inlet efficiency tables.

gamma = 1.4;

switch lower(inlet_type)
    case 'normal-shock'
        % Standard MIL normal-shock inlet (F-15, F-16, F-18 style)
        % Farokhi Figure 6.12 + MIL standard inlet efficiency tables
        % Conservative curve-fit (realistic military inlet losses)
        
        if M <= 0.2
            eta = 0.995;
        elseif M <= 0.5
            % Linear subsonic
            eta = 0.995 - (M - 0.2) / (0.5 - 0.2) * 0.015;
        elseif M <= 0.9
            % Gentle reduction 0.5 to 0.9 Mach
            eta = 0.980 - (M - 0.5) / (0.9 - 0.5) * 0.015;
        elseif M <= 1.0
            % Transonic (0.9 to 1.0)
            eta = 0.965 - (M - 0.9) / 0.1 * 0.015;
        elseif M <= 1.2
            % Normal shock begins (1.0 to 1.2)
            % Linear interpolation between transonic and low supersonic
            eta = 0.950 - (M - 1.0) / 0.2 * 0.050;
        elseif M <= 1.5
            % Growing normal shock losses (1.2 to 1.5)
            eta = 0.900 - (M - 1.2) / 0.3 * 0.100;
        elseif M <= 2.0
            % Strong shock / external compression (1.5 to 2.0)
            eta = 0.800 - (M - 1.5) / 0.5 * 0.050;
        else
            % High supersonic (M > 2.0)
            eta = 0.750 - (M - 2.0) / 1.0 * 0.050;
            eta = max(eta, 0.65);
        end
        eta = max(min(eta, 0.995), 0.65);  % reasonable bounds
    case 'external'
        % External compression inlet (variable ramps, slats)
        % Farokhi 6.15: better than normal shock but requires complex scheduling
        if M <= 1.0
            eta = 0.985;
        elseif M <= 1.5
            % Ramp schedule reduces effective shock strength
            eta = 0.985 - (M - 1.0) / (1.5 - 1.0) * (0.985 - 0.92);
        elseif M <= 2.0
            eta = 0.92 - (M - 1.5) / (2.0 - 1.5) * (0.92 - 0.85);
        else
            eta = 0.85 - (M - 2.0) / 0.5 * 0.05;
            eta = max(eta, 0.70);
        end
        
    case 'subsonic'
        % Subsonic inlet with minimal losses (M < 0.5 assumption)
        eta = 0.99;
        
    otherwise
        % Default to normal-shock
        eta = inlet_total_pressure_recovery(M, 'normal-shock');
end

end
