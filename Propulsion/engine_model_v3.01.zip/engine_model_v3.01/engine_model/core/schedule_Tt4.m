function Tt4_cmd = schedule_Tt4(PLA, AB, params)
%SCHEDULE_TT4 Commanded Tt4 [K] as function of power lever angle and AB.
%
% Inputs:
%   PLA   : power lever angle, nondimensional [0..1.3] where
%           0.0 ~ cutoff, 0.3 ~ idle, 1.0 ~ MIL, 1.3 ~ MAX AB
%   AB    : afterburner command [0..1], 0 = dry, 1 = full AB
%   params: struct (optional) with override fields:
%              Tt4_idle
%              Tt4_MIL
%              Tt4_MAX
%
% Output:
%   Tt4_cmd : commanded burner outlet total temperature [K]
%
% Notes:
%   - Numbers are anchored to typical F404-class behavior and NASA data.
%   - Use params.* if you later back-fit to TM-4538-derived values.

% ---- Default anchor temperatures (can be tuned) ----
if nargin < 3 || isempty(params)
    params = struct();
end
Tt4_idle = getfield_opt(params, 'Tt4_idle', 950.0);    % ~ 1300 R, conservative for idle
Tt4_MIL  = getfield_opt(params, 'Tt4_MIL',  1600.0);   % ~ 2880 R, realistic MIL
Tt4_MAX  = getfield_opt(params, 'Tt4_MAX',  1780.0);   % ~ 3204 R, F404 AB limit (tuned to 75 kN max)

% Clamp inputs
PLA = max(0.0, min(1.3, PLA));
AB  = max(0.0, min(1.0, AB));

% ---- Define key PLA breakpoints ----
PLA_idle = 0.30;   % idle
PLA_MIL  = 1.00;   % MIL (max dry)
PLA_MAX  = 1.30;   % full AB

% ---- Dry schedule (AB = 0) ----
if PLA <= PLA_idle
    Tt4_dry = Tt4_idle;
elseif PLA < PLA_MIL
    % Linear ramp from idle to MIL
    xi = (PLA - PLA_idle) / (PLA_MIL - PLA_idle);
    Tt4_dry = Tt4_idle + xi * (Tt4_MIL - Tt4_idle);
else
    % At or above MIL, clamp to MIL Tt4 (afterburner adds heat downstream)
    Tt4_dry = Tt4_MIL;
end

% ---- Afterburner schedule (AB = 1) ----
% Only meaningful from MIL to MAX
if PLA <= PLA_MIL
    Tt4_ab = Tt4_MIL;  % AB cannot be "below MIL": treat as MIL baseline
elseif PLA < PLA_MAX
    % Linear ramp MIL to MAX
    xi = (PLA - PLA_MIL) / (PLA_MAX - PLA_MIL);
    Tt4_ab = Tt4_MIL + xi * (Tt4_MAX - Tt4_MIL);
else
    Tt4_ab = Tt4_MAX;
end

% ---- Blend dry/AB with AB command ----
Tt4_cmd = (1 - AB) * Tt4_dry + AB * Tt4_ab;
end

function val = getfield_opt(s, name, default)
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    val = s.(name);
else
    val = default;
end
end
