function out = compute_outputs(cfg, cycle)
%COMPUTE_OUTPUTS Summarize cycle states into performance metrics.
% Inputs:
%   cfg   : configuration / constants (unused placeholder for future)
%   cycle : struct with key station data (Pt2, Pt3, wc, wt, f, etc.)
% Outputs:
%   out   : struct with OPR, work, fuel flow, thrust, TSFC

out = struct();

out.OPR = cycle.Pt3 / max(1e-9, cycle.Pt2);
out.wc  = getfieldwithdefault(cycle,'wc', NaN);
out.wt  = getfieldwithdefault(cycle,'wt', NaN);
out.f   = getfieldwithdefault(cycle,'f', NaN);
out.PLA = getfieldwithdefault(cycle,'PLA', NaN);
out.AB  = getfieldwithdefault(cycle,'AB', NaN);
out.Tt4_cmd = getfieldwithdefault(cycle,'Tt4_cmd', getfieldwithdefault(cycle,'Tt4', NaN));

mdot_core = getfieldwithdefault(cycle,'mdot_core', getfieldwithdefault(cycle,'mdot', NaN));
mdot_fan  = getfieldwithdefault(cycle,'mdot_fan', 0.0);
mdot_air  = mdot_core + mdot_fan;

mdot_fuel_core = getfieldwithdefault(cycle,'mdot_fuel_core', NaN);
mdot_fuel_ab   = getfieldwithdefault(cycle,'mdot_fuel_ab', 0.0);
mdot_fuel_fan  = getfieldwithdefault(cycle,'mdot_fuel_fan', 0.0);
mdot_fuel_total = mdot_fuel_core + mdot_fuel_ab + mdot_fuel_fan;

out.mdot_air  = mdot_air;
out.mdot_fuel_main = mdot_fuel_core;
out.mdot_fuel_ab   = mdot_fuel_ab;
out.mdot_fuel = mdot_fuel_total;

if isfield(cycle,'nozzle') && isfield(cycle.nozzle,'Fg')
    out.Thrust_gross = cycle.Fg;
    out.mdot_geom = getfieldwithdefault(cycle.nozzle,'mdot_geom',NaN);
    out.mdot_total_commanded = getfieldwithdefault(cycle.nozzle,'mdot_total_in',NaN);
else
    out.Thrust_gross = getfieldwithdefault(cycle,'Fg', NaN);
    out.mdot_geom = getfieldwithdefault(cycle,'mdot_geom',NaN);
    out.mdot_total_commanded = getfieldwithdefault(cycle,'mdot',NaN);
end
out.thrust_scale = getfieldwithdefault(cycle,'thrust_scale',1.0);
out.thrust_scale_lookup = getfieldwithdefault(cycle,'thrust_scale_lookup',NaN);
out.Ram_drag = getfieldwithdefault(cycle,'ram_drag', 0);
out.Thrust_net = getfieldwithdefault(cycle,'Fn', out.Thrust_gross - out.Ram_drag);
out.Thrust = out.Thrust_net;

out.tsfc_scale = getfieldwithdefault(cycle,'tsfc_scale',1.0);

if isnan(out.Thrust) || out.Thrust <= 0
    out.TSFC = NaN;
else
    out.TSFC = mdot_fuel_total ./ out.Thrust;
    out.TSFC = out.TSFC .* out.tsfc_scale;
end

end

function val = getfieldwithdefault(s, name, default)
if isstruct(s) && isfield(s, name)
    val = s.(name);
else
    val = default;
end
end
