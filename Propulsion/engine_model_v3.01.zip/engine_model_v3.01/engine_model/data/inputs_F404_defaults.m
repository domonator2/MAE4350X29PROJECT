function in = inputs_F404_defaults(cfg)
%INPUTS_F404_DEFAULTS Baseline GE F404-GE-400 style input set.
% Lightweight approximation derived from open literature; serves as a starter
% configuration until higher fidelity data are supplied.
%
% Optional Inputs:
%   cfg : if provided, uses cfg.dt/cfg.t_end for the default time vector.

if nargin < 1
    cfg = struct();
end

%% ------------------------------------------------------------------------
% 1. TIME VECTOR
% -------------------------------------------------------------------------
if isfield(cfg,'dt') && ~isempty(cfg.dt)
    dt = cfg.dt;
else
    dt = 0.1;    % [s]
end
if isfield(cfg,'t_end') && ~isempty(cfg.t_end)
    t_end = cfg.t_end;
else
    t_end = 10.0;   % [s]
end
time  = (0:dt:t_end).';

%% ------------------------------------------------------------------------
% 2. ATMOSPHERE (ISA SLS, M0 = 0)
% -------------------------------------------------------------------------
atm = struct();
atm.alt = 0.0;          % [m]
atm.T0  = 288.15;       % [K]
atm.p0  = 101325.0;     % [Pa]
atm.M0  = 0.0;          % [-]

%% ------------------------------------------------------------------------
% 3. THERMODYNAMIC CONSTANTS
% -------------------------------------------------------------------------
const = struct();
const.gamma = 1.4;
const.R     = 287.0;       % [J/(kg*K)]
const.cp    = 1004.0;      % [J/(kg*K)]
const.LHV   = 43e6;        % [J/kg]
const.eta_b = 0.99;

%% ------------------------------------------------------------------------
% 4. ENGINE PARAMETERS (approximate F404 core)
% -------------------------------------------------------------------------
params = struct();

params.PR_c        = 12.5;
params.eta_c       = 0.88;  % Increased from 0.86 to boost compressor output
params.Tt4_idle      = 1100.0;   % [K]
params.Tt4_MIL       = 1520.0;   % [K] at PLA=1.0 (MIL power, for positive thrust at cruise Mach)
params.Tt4_MAX       = 1780.0;   % [K] at PLA=1.3 (MAX AB power, F404 limit)
params.Tt4_main_max  = 1650.0;   % [K] main burner (turbine inlet) limit (published F404 spec)
params.Tt4_dry_max   = params.Tt4_main_max;  % legacy alias
params.dTt_ab_max    = 900.0;    % [K] augmentor temperature rise (realistic F404 AB at full throttle)
params.Tt4           = params.Tt4_main_max;
params.eta_t       = 0.88;
params.p_drop_comb = 0.08;
params.p_drop_ab   = 0.08;
params.eta_burner_main = 0.90;  % main burner efficiency
params.eta_burner_ab   = 0.60;  % augmentor effective efficiency (improved)

params.PLA_tau = 0.70;
params.AB_tau  = 0.30;

% Simple fan stage on bypass stream
params.PR_fan        = 1.40;  % Keep at 1.40 (empirically better for this model)
params.eta_fan       = 0.90;

% F404-like total mass flow and bypass ratio (lifted toward ~75 kN class)
params.mdot_core_nom = 52.0;       % [kg/s] core stream
params.mdot_fan_nom  = 22.0;       % [kg/s] bypass stream
params.mdot_core     = params.mdot_core_nom;
params.mdot_fan      = params.mdot_fan_nom;
params.mdot          = params.mdot_core + params.mdot_fan;
% Design (reference) mass flows for inlet model
params.mdot_design_core  = 50.0;   % [kg/s]
params.mdot_design_fan   = 25.0;   % [kg/s]
params.mdot_design_total = 75.0;   % [kg/s] total design inlet flow
params.rho_des           = atm.p0 / (const.R * atm.T0);  % ISA SL density
params.M_des             = 0.90;      % design inlet Mach number for capture model
params.BPR_nom       = params.mdot_fan_nom / params.mdot_core_nom;
params.rho_ref       = atm.p0 / (const.R * atm.T0);
params.T_ref         = atm.T0;
params.V_ref         = 0.0;

%% F404-like calibration and scheduling parameters

% --- Thrust base scale (global) - physics-only baseline, no empirical boost
params.thrust_scale_dry = 1.0;  % physics-only baseline
params.thrust_scale_ab  = 1.0;  % physics-only baseline

% --- Legacy Mach/PLA thrust scale (disabled here; fitted tables set below)
% params.thrust_scale_M_tab      = [0.01 0.4 0.6 0.9 1.2 1.6];
% params.thrust_scale_dry_tab    = [1 1 1 1 1 1];
% params.thrust_scale_ab_tab     = [1 1 1 1 1 1];

% --- Inlet / ram drag model (unchanged)
params.A_capture        = 0.38;
params.M_inlet_tab      = [0.0 0.6 0.9 1.2 1.6];
params.eta_inlet_tab    = [0.995 0.985 0.970 0.950 0.935];
params.CD_inlet         = 0.020;
params.A_inlet_ref      = 0.40;

% --- Compressor map-lite modifiers: tuned to prevent stall at off-design points
params.alt_ref          = 0.0;
params.M_ref            = 0.0;
params.PR_comp_ref      = 27.0;
params.eta_comp_ref     = 0.88;
params.PR_M_slope       = 0.35;     % Reduced to prevent mass-flow starvation at mid-power
params.PR_alt_slope     = 0.002;    % PR decreases with altitude (positive slope for subtraction)
params.eta_M_slope      = 0.03;     % Efficiency decreases at high Mach
params.eta_alt_slope    = 0.0015;   % Efficiency decreases at altitude

% --- PLA + Tt4 schedule (dry and AB)
params.pla_breaks_dry   = [0.30 0.50 0.70 0.87 1.00];
% Softer mid-throttle temperature to fix PLA=0.6 TSFC spike
params.Tt4_dry_table    = [1100 1275 1400 1625 1650];  % Recommended fix per diagnostics
params.pla_breaks_ab    = [0.87 1.00 1.10 1.20 1.30];
params.Tt4_ab_table     = [1650 1750 1850 1950 2000];  % Reduced AB temps for realistic thrust

% --- Nozzle area & Cd laws
params.PLA_idle         = 0.30;
params.PLA_irt          = 0.87;
params.PLA_max_ab       = 1.30;
params.A8_idle          = 0.34;
params.A8_dry           = 0.38;
params.A8_ab            = 0.40;
params.A9_idle          = params.A8_idle * 1.50;
params.A9_dry           = params.A8_dry  * 1.55;
params.A9_ab            = params.A8_ab   * 1.60;
% Extended nozzle schedule for better interpolation
params.PLA_noz_schedule = [0.30 0.50 0.70 0.87 1.00];
params.A8_noz_schedule  = [0.360 0.375 0.385 0.395 0.400];
params.A9_noz_schedule  = [0.540 0.581 0.597 0.612 0.620];
params.M_noz_tab        = [0.0 0.6 0.9 1.2 1.6];
params.A8_M_scale_tab   = [1.00 1.00 1.00 0.98 0.95];       % Throat: slight contraction at high Mach
params.A9_M_scale_tab   = [1.00 1.00 1.00 1.10 1.25];       % Exit: expand in supersonic for better thrust
params.PLA_noz_tab      = [0.30 0.60 0.87 1.00 1.30];
params.Cd_noz_tab       = [0.94 0.96 0.98 0.99 0.99];  % Increased to boost exit velocity
params.nozzle_type      = 'convergent-divergent';            % CD nozzle for proper supersonic thrust

% -------------------------------------------------------------------------
%  Thrust scaling vs Mach and PLA (from TM-4140 fit)
% -------------------------------------------------------------------------
params.thrust_scale_M_tab    = [0         0.6         0.9         1.2         1.6];
% Tuned thrust scaling (less aggressive at mid-Mach to avoid negative thrust at MIL)
params.thrust_scale_dry_tab  = [1.00      1.00        0.92        0.78        0.65];
params.thrust_scale_ab_tab   = [1.00      1.00        0.95        0.82        0.75];

% PLA-dependent dry scaling (boost at mid-PLA to ensure positive thrust)
params.thrust_scale_dry_pla_tab  = [0.30 0.55 0.70 0.87 1.00];
% Increased PLA thrust scaling to prevent TSFC spike at mid-power
params.thrust_scale_dry_pla_vals = [1.00 1.10 1.20 1.00 1.00];

% Simple AB PLA scaling: mild boost as you go to full PLA in AB
params.thrust_scale_ab_pla_tab   = [0.87 1.00 1.15 1.30];
params.thrust_scale_ab_pla_vals  = [1.00 1.03 1.06 1.08];

% --- TSFC scaling: NEUTRAL (we are not fitting TSFC yet)
params.pla_tsfc_dry_tab = [0.30 0.50 0.70 0.87 1.00];
params.tsfc_scale_dry   = [1 1 1 1 1];
params.pla_tsfc_ab_tab  = [0.87 1.00 1.20 1.30];
params.tsfc_scale_ab    = [1 1 1 1];
params.tsfc_scale       = 1.0;

% --- Altitude-dependent thrust correction: NEUTRAL
params.alt_thrust_corr_tab  = [0, 3048, 6096, 9144, 12192];        % 0–40 kft
% Mild thrust reduction with altitude (prevent thrust rising with alt at high Mach)
params.alt_thrust_corr_vals = [1.00 0.98 0.95 0.90 0.85];

% --- Mach-dependent thrust correction: NEUTRAL
params.mach_thrust_corr_tab  = [0.4 0.8 0.9 1.2 1.6];
params.mach_thrust_corr_vals = [1 1 1 1 1];

% --- PLA-dependent thrust correction: NEUTRAL
params.pla_thrust_corr_tab  = [0.54 0.67 0.77 1.0];  % Normalized PLA values
params.pla_thrust_corr_vals = [1 1 1 1];  % Correction multipliers

% --- PLA-based mass-flow scaling: reduce flow at low PLA
params.mdot_pla_tab    = [0.30 0.50 0.70 0.87 1.00];
params.mdot_pla_scale  = [0.65 0.75 0.88 0.95 1.00];  % reduce flow at low PLA for better idle/cruise accuracy

% --- Bleed / cooling fractions (keep as-is)
params.bleed_pla_tab  = [0.30 0.70 0.87 1.00 1.30];
params.bleed_frac_tab = [0.06 0.05 0.04 0.04 0.04];
params.cool_pla_tab   = [0.30 0.70 0.87 1.00 1.30];
params.cool_frac_tab  = [0.025 0.025 0.02 0.02 0.02];

%% ------------------------------------------------------------------------
% 5. SCHEDULES (PLA / optional AB)
% -------------------------------------------------------------------------
schedules = struct();
n = numel(time);
schedules.PLA = linspace(0.3, 1.3, n)';               % ramp throttle into AB regime
schedules.AB  = zeros(n,1);                           % AB off initially
schedules.AB(time >= 0.5*time(end)) = 1.0;            % AB on second half

% Optionally apply auto-fitted thrust correction tables if present
% fitted_corr_file = fullfile(fileparts(mfilename('fullpath')),'fitted_thrust_corrections.m');
% if exist(fitted_corr_file,'file')
%     run(fitted_corr_file);
% end

%% ------------------------------------------------------------------------
% 6. PACK
% -------------------------------------------------------------------------
in = struct();
in.time      = time;
in.atm       = atm;
in.params    = params;
in.schedules = schedules;
in.const     = const;

end
