function in = load_inputs(cfg, varargin)
%LOAD_INPUTS Gather baseline conditions.
% Usage:
%   in = load_inputs(cfg)                        % use hard-coded ISA SLS defaults
%   in = load_inputs(cfg,'mat','data/baseline.mat')  % load from MAT-file with struct 'in'
%
% Expected MAT-file schema:
%   in.atm.T0, in.atm.p0, in.atm.M0
%   in.params (fields may override cfg.params)
%   in.time (optional). If absent, uses cfg.dt:cfg.t_end

p = inputParser;
addParameter(p,'mat','',@(s)ischar(s) || isstring(s));
parse(p,varargin{:});
matfile = string(p.Results.mat);

if strlength(matfile) > 0 && isfile(matfile)
    S = load(matfile);
    if isfield(S,'in')
        in = S.in;
    else
        error('MAT-file must contain struct ''in''.');
    end
else
    in = inputs_F404_defaults(cfg);
end

% Fill time base if missing
if ~isfield(in,'time') || isempty(in.time)
    t = 0:cfg.dt:cfg.t_end;
    in.time = t(:);
else
    in.time = in.time(:);
end
N = numel(in.time);

% Normalize atmosphere fields to support trajectory-driven profiles
if ~isfield(in,'atm')
    in.atm = struct();
end
in.atm.alt = ensure_profile_field(in.atm, 'alt', zeros(N,1), N);
in.atm.M0  = ensure_profile_field(in.atm, 'M0', zeros(N,1), N);
in.atm.T0  = ensure_profile_field(in.atm, 'T0', NaN(N,1), N);
in.atm.p0  = ensure_profile_field(in.atm, 'p0', NaN(N,1), N);
if ~isfield(in.atm,'use_standard_atm')
    in.atm.use_standard_atm = true;
end

% Make sure required params exist; fall back to cfg.params
req = {'PR_c','eta_c','Tt4','eta_t','p_drop_comb','mdot'};
for k = 1:numel(req)
    fld = req{k};
    if ~isfield(in.params, fld)
        in.params.(fld) = cfg.params.(fld);
    end
end

% Default throttle schedule if absent
if ~isfield(in,'schedules') || ~isfield(in.schedules,'PLA')
    in.schedules.PLA = ones(N,1);
else
    in.schedules.PLA = ensure_schedule_vector(in.schedules.PLA, N, 'PLA');
end
if ~isfield(in,'schedules') || ~isfield(in.schedules,'AB')
    in.schedules.AB = zeros(N,1);
else
    in.schedules.AB = ensure_schedule_vector(in.schedules.AB, N, 'AB');
end

end

function vec = ensure_profile_field(atm, name, default_val, N)
if isfield(atm,name) && ~isempty(atm.(name))
    data = atm.(name);
else
    data = default_val;
end
vec = expand_to_length(data, N);
end

function vec = ensure_schedule_vector(data, N, label)
vec = expand_to_length(data, N);
if ~isnumeric(vec)
    error('Schedule %s must be numeric.', label);
end
end

function vec = expand_to_length(data, N)
if isnumeric(data) || islogical(data)
    vec = data(:);
    if numel(vec) == 1
        vec = repmat(vec, N, 1);
    elseif numel(vec) ~= N
        error('Input profile must have length %d, got %d.', N, numel(vec));
    end
elseif iscell(data)
    if numel(data) ~= N
        error('Cell profile must have length %d.', N);
    end
    vec = reshape(data, N, 1);
else
    error('Unsupported profile data type.');
end
end
