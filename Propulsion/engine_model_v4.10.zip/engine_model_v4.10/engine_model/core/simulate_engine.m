function results = simulate_engine(cfg, in)
%SIMULATE_ENGINE Iterate over time/operating points and call solve_cycle.
% Inputs:
%   cfg : configuration struct (dt, tolerances, constants, etc.)
%   in  : input struct with time base, atmosphere profiles, params, schedules
% Outputs:
%   results : struct with time histories of station properties and performance

t = in.time;
N = numel(t);

% Preallocate common states
Tt3 = nan(N,1); Tt4 = nan(N,1); Tt2 = nan(N,1);
Pt2 = nan(N,1); Pt3 = nan(N,1); Pt4 = nan(N,1);
eta_c = nan(N,1); eta_t = nan(N,1);
wc = nan(N,1); wt = nan(N,1);
OPR = nan(N,1); f = nan(N,1);
Thrust = nan(N,1); TSFC = nan(N,1);
Thrust_gross = nan(N,1); Ram_drag = nan(N,1);
PLA_log = nan(N,1); AB_log = nan(N,1); Tt4_cmd_log = nan(N,1);
alt_log = nan(N,1); mach_log = nan(N,1); T0_log = nan(N,1); p0_log = nan(N,1);

state = struct();

dt_cfg = getfieldwithdefault(cfg, 'dt', 0);
if dt_cfg <= 0 && N > 1
    dt = t(2) - t(1);
elseif dt_cfg > 0
    dt = dt_cfg;
else
    dt = 0.1;
end

PLA_state = in.schedules.PLA(1);
AB_state  = in.schedules.AB(1);
tau_PLA = getfieldwithdefault(in.params,'PLA_tau',0.7);
tau_AB  = getfieldwithdefault(in.params,'AB_tau',0.3);

for k = 1:N
    PLA_cmd = in.schedules.PLA(k);
    AB_cmd  = in.schedules.AB(k);
    alpha_PLA = min(max(dt / max(tau_PLA, 1e-6), 0), 1);
    alpha_AB  = min(max(dt / max(tau_AB,  1e-6), 0), 1);
    PLA_state = PLA_state + alpha_PLA * (PLA_cmd - PLA_state);
    AB_state  = AB_state  + alpha_AB  * (AB_cmd  - AB_state);

    op = struct();
    op.PLA = PLA_state;
    op.AB  = AB_state;

    atm_k = slice_atmosphere(in.atm, k);
    op.atm = atm_k;
    op.T0  = getfieldwithdefault(atm_k,'T0',NaN);
    op.p0  = getfieldwithdefault(atm_k,'p0',NaN);
    op.M0  = getfieldwithdefault(atm_k,'M0',NaN);

    op.params = in.params;

    out = solve_cycle(cfg, op, state);
    perf = out.metrics;

    % Collect
    Tt2(k) = out.Tt2; Tt3(k) = out.Tt3; Tt4(k) = out.Tt4;
    Pt2(k) = out.Pt2; Pt3(k) = out.Pt3; Pt4(k) = out.Pt4;
    eta_c(k) = out.eta_c; eta_t(k) = out.eta_t;
    wc(k) = out.wc; wt(k) = out.wt;
    OPR(k) = perf.OPR;
    f(k) = perf.f;
    Thrust(k) = perf.Thrust; TSFC(k) = perf.TSFC;
    Thrust_gross(k) = getfieldwithdefault(perf,'Thrust_gross',perf.Thrust);
    Ram_drag(k) = getfieldwithdefault(perf,'Ram_drag',NaN);
    PLA_log(k) = perf.PLA;
    AB_log(k)  = perf.AB;
    Tt4_cmd_log(k) = perf.Tt4_cmd;
    alt_log(k) = getfieldwithdefault(atm_k,'alt',NaN);
    mach_log(k)= getfieldwithdefault(atm_k,'M0',NaN);
    T0_log(k)  = op.T0;
    p0_log(k)  = op.p0;

    state = out.state;
end

% Pack
results = struct();
results.time = t;
results.Tt2 = Tt2; results.Tt3 = Tt3; results.Tt4 = Tt4;
results.Pt2 = Pt2; results.Pt3 = Pt3; results.Pt4 = Pt4;
results.eta_c = eta_c; results.eta_t = eta_t;
results.wc = wc; results.wt = wt;
results.OPR = OPR; results.f = f;
results.Thrust = Thrust; results.TSFC = TSFC;
results.Thrust_gross = Thrust_gross; results.Ram_drag = Ram_drag;
results.PLA = PLA_log; results.AB = AB_log; results.Tt4_cmd = Tt4_cmd_log;
results.alt = alt_log; results.M0 = mach_log; results.T0 = T0_log; results.p0 = p0_log;

end

function atm_k = slice_atmosphere(atm_all, idx)
if ~isstruct(atm_all)
    error('Atmosphere input must be a struct.');
end
fields = fieldnames(atm_all);
atm_k = struct();
for i = 1:numel(fields)
    name = fields{i};
    atm_k.(name) = extract_profile_value(atm_all.(name), idx);
end
end

function val = extract_profile_value(data, idx)
if isnumeric(data) || islogical(data)
    data = data(:);
    if isempty(data)
        val = NaN;
    elseif numel(data) == 1
        val = data;
    else
        val = data(min(idx, numel(data)));
    end
elseif iscell(data)
    val = data{min(idx, numel(data))};
else
    val = data;
end
end

function val = getfieldwithdefault(s, name, default)
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    entry = s.(name);
    if isnumeric(entry) && numel(entry) > 1
        val = entry(1);
    else
        val = entry;
    end
else
    val = default;
end
end
