function validate_inputs(in)
%VALIDATE_INPUTS Basic integrity checks.
assert(isfield(in,'atm') && isfield(in.atm,'T0') && isfield(in.atm,'p0'), 'Missing atmosphere.');
assert(isfield(in,'time') && numel(in.time)>0, 'Missing time vector.');
assert(isfield(in,'params'), 'Missing params.');
fields = {'PR_c','eta_c','Tt4','eta_t','p_drop_comb','mdot'};
for k=1:numel(fields)
    assert(isfield(in.params,fields{k}), 'Missing params.%s', fields{k});
end
assert(all(in.params.p_drop_comb>=0 & in.params.p_drop_comb<1), 'p_drop_comb must be in [0,1).');
end
