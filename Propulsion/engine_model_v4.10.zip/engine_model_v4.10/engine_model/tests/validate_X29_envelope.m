% VALIDATE_X29_ENVELOPE - Validate F404-GE-400 model for X-29 trajectory simulation
% X-29 Flight Envelope: 0-50,000 ft altitude, 0-1.6 Mach
clear; clc; close all;

project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

fprintf('=== F404-GE-400 Validation for X-29 Trajectory Simulation ===\n\n');

%% Load empirical data
csv_path = fullfile(project_root, 'F404_GE400_TM4140_net_thrust.csv');
empirical = readtable(csv_path);
empirical = empirical(~isnan(empirical.alt_ft), :);

% X-29 operational envelope: 0-50,000 ft (0-15.24 km)
alt_limit_ft = 50000;
x29_data = empirical(empirical.alt_ft <= alt_limit_ft, :);

fprintf('X-29 Flight Envelope Data Points: %d\n', height(x29_data));
fprintf('Altitude range: %.0f - %.0f ft (%.1f - %.1f km)\n', ...
    min(x29_data.alt_ft), max(x29_data.alt_ft), ...
    min(x29_data.alt_ft)*0.3048/1000, max(x29_data.alt_ft)*0.3048/1000);
fprintf('Mach range: %.1f - %.1f\n\n', min(x29_data.Mach), max(x29_data.Mach));

% Convert PLA from degrees to non-dimensional
PLA_deg = x29_data.PLA_deg;
PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg);
AB_fuel_flow = x29_data.afterburnerFuelFlow_Lbm_s;
AB_cmd = double(AB_fuel_flow > 0.01);

%% Load X-29 trajectory-optimized configuration
cfg = config_model();
in = inputs_F404_X29_trajectory(cfg);

N = height(x29_data);
model_thrust = zeros(N, 1);
model_tsfc = zeros(N, 1);
converged = true(N, 1);

fprintf('Running simulation on %d points...\n', N);
tic;
for i = 1:N
    alt_ft = x29_data.alt_ft(i);
    M0 = x29_data.Mach(i);
    PLA = PLA_nondim(i);
    AB = AB_cmd(i);

    % Get atmospheric conditions
    alt_m = alt_ft * 0.3048;
    [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);
    rho0 = p0 / (287.0 * T0);

    % Setup operating point
    op = struct();
    op.params = in.params;
    op.atm = struct('T0', T0, 'p0', p0, 'rho0', rho0, 'alt', alt_m);
    op.M0 = M0;
    op.PLA = PLA;
    op.AB = AB;

    % Solve cycle
    try
        cycle = solve_cycle(cfg, op);
        model_thrust(i) = cycle.Thrust;
        model_tsfc(i) = cycle.TSFC;
    catch ME
        warning('Point %d failed: %s', i, ME.message);
        model_thrust(i) = NaN;
        model_tsfc(i) = NaN;
        converged(i) = false;
    end

    if mod(i, 10) == 0
        fprintf('  Progress: %d/%d points (%.1f%%)\n', i, N, 100*i/N);
    end
end
elapsed = toc;
fprintf('Simulation complete: %.2f seconds (%.3f ms/point)\n\n', elapsed, 1000*elapsed/N);

%% Calculate validation metrics
empirical_thrust = x29_data.net_thrust_N;
valid = converged & ~isnan(empirical_thrust) & ~isnan(model_thrust);

thrust_error = model_thrust(valid) - empirical_thrust(valid);
thrust_error_percent = 100 * thrust_error ./ empirical_thrust(valid);

RMSE = sqrt(mean(thrust_error.^2));
MAE = mean(abs(thrust_error));
MAPE = mean(abs(thrust_error_percent));
max_abs_error = max(abs(thrust_error));
max_abs_error_pct = max(abs(thrust_error_percent));
R2 = 1 - sum(thrust_error.^2) / sum((empirical_thrust(valid) - mean(empirical_thrust(valid))).^2);

fprintf('=== VALIDATION RESULTS ===\n');
fprintf('Valid points: %d / %d (%.1f%%)\n', sum(valid), N, 100*sum(valid)/N);
fprintf('RMSE:         %.2f N (%.2f kN)\n', RMSE, RMSE/1000);
fprintf('MAE:          %.2f N (%.2f kN)\n', MAE, MAE/1000);
fprintf('MAPE:         %.2f %%\n', MAPE);
fprintf('Max Error:    %.2f N (%.2f %%)\n', max_abs_error, max_abs_error_pct);
fprintf('R²:           %.4f\n\n', R2);

% Assess quality
if MAPE < 10.0
    fprintf('✅ EXCELLENT: MAPE < 10%% - High-fidelity trajectory simulation ready\n');
elseif MAPE < 15.0
    fprintf('✅ GOOD: MAPE < 15%% - Suitable for trajectory optimization\n');
elseif MAPE < 25.0
    fprintf('✅ ACCEPTABLE: MAPE < 25%% - Usable for mission planning\n');
elseif MAPE < 50.0
    fprintf('⚠️  FAIR: MAPE < 50%% - Qualitative trends only\n');
else
    fprintf('❌ POOR: MAPE > 50%% - Further calibration needed\n');
end

%% Breakdown by flight condition
fprintf('\n=== Performance by Altitude and Mach ===\n');
fprintf('%-15s %-10s %-10s %-10s %-10s\n', 'Condition', 'Points', 'MAPE(%)', 'Max Err(kN)', 'Status');
fprintf('%s\n', repmat('-', 1, 65));

alts_ft = unique(x29_data.alt_ft);
machs = unique(x29_data.Mach);

for a = 1:numel(alts_ft)
    for m = 1:numel(machs)
        idx = valid & x29_data.alt_ft == alts_ft(a) & x29_data.Mach == machs(m);
        if sum(idx) > 0
            mape_cond = mean(abs(100 * (model_thrust(idx) - empirical_thrust(idx)) ./ empirical_thrust(idx)));
            max_err_kN = max(abs(model_thrust(idx) - empirical_thrust(idx))) / 1000;

            status = '✅';
            if mape_cond > 25, status = '⚠️'; end
            if mape_cond > 50, status = '❌'; end

            fprintf('%-6.0f ft M=%-4.1f %-10d %-10.2f %-10.2f %s\n', ...
                alts_ft(a), machs(m), sum(idx), mape_cond, max_err_kN, status);
        end
    end
end

%% Breakdown by power setting
fprintf('\n=== Performance by Power Setting ===\n');
dry_idx = valid & AB_cmd == 0;
ab_idx = valid & AB_cmd > 0;

if sum(dry_idx) > 0
    mape_dry = mean(abs(100 * (model_thrust(dry_idx) - empirical_thrust(dry_idx)) ./ empirical_thrust(dry_idx)));
    fprintf('DRY (Military):    MAPE = %.2f %% (%d points)\n', mape_dry, sum(dry_idx));
end
if sum(ab_idx) > 0
    mape_ab = mean(abs(100 * (model_thrust(ab_idx) - empirical_thrust(ab_idx)) ./ empirical_thrust(ab_idx)));
    fprintf('AFTERBURNING:      MAPE = %.2f %% (%d points)\n', mape_ab, sum(ab_idx));
end

%% Create validation plots
fig = figure('Position', [100, 100, 1400, 900]);

% Thrust comparison
subplot(2,3,1)
scatter(empirical_thrust(valid)/1000, model_thrust(valid)/1000, 60, 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot([0 90], [0 90], 'r--', 'LineWidth', 2);
xlabel('Empirical Thrust (kN)', 'FontSize', 11);
ylabel('Model Thrust (kN)', 'FontSize', 11);
title(sprintf('Model vs Empirical\nMAPE = %.2f%%, R² = %.3f', MAPE, R2), 'FontSize', 12, 'FontWeight', 'bold');
grid on;
axis equal tight;
xlim([0 max(empirical_thrust(valid)/1000)*1.1]);
ylim([0 max(empirical_thrust(valid)/1000)*1.1]);
legend('Data', 'Perfect', 'Location', 'northwest');

% Error distribution
subplot(2,3,2)
histogram(thrust_error_percent, 25, 'FaceColor', [0.3 0.6 0.9], 'EdgeColor', 'none', 'FaceAlpha', 0.7);
hold on;
xline(0, 'r--', 'LineWidth', 2);
xline(-15, 'g--', 'LineWidth', 1.5);
xline(15, 'g--', 'LineWidth', 1.5);
xlabel('Error (%)', 'FontSize', 11);
ylabel('Frequency', 'FontSize', 11);
title(sprintf('Error Distribution\nMean = %.1f%%, Std = %.1f%%', mean(thrust_error_percent), std(thrust_error_percent)), 'FontSize', 12, 'FontWeight', 'bold');
grid on;

% Error vs altitude
subplot(2,3,3)
alts_m = x29_data.alt_ft(valid) * 0.3048 / 1000;
scatter(alts_m, thrust_error_percent, 60, x29_data.Mach(valid), 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot([0 16], [0 0], 'r--', 'LineWidth', 1.5);
plot([0 16], [-15 -15], 'g:', 'LineWidth', 1);
plot([0 16], [15 15], 'g:', 'LineWidth', 1);
xlabel('Altitude (km)', 'FontSize', 11);
ylabel('Error (%)', 'FontSize', 11);
title('Error vs Altitude (colored by Mach)', 'FontSize', 12, 'FontWeight', 'bold');
colorbar;
colormap(jet);
caxis([0 1.6]);
grid on;
xlim([0 16]);

% Error vs Mach
subplot(2,3,4)
machs_all = x29_data.Mach(valid);
scatter(machs_all, thrust_error_percent, 60, alts_m, 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot([0 1.7], [0 0], 'r--', 'LineWidth', 1.5);
plot([0 1.7], [-15 -15], 'g:', 'LineWidth', 1);
plot([0 1.7], [15 15], 'g:', 'LineWidth', 1);
xlabel('Mach Number', 'FontSize', 11);
ylabel('Error (%)', 'FontSize', 11);
title('Error vs Mach (colored by Alt)', 'FontSize', 12, 'FontWeight', 'bold');
colorbar;
colormap(jet);
grid on;
xlim([0 1.7]);

% Error vs PLA
subplot(2,3,5)
scatter(PLA_nondim(valid), thrust_error_percent, 60, AB_cmd(valid), 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot([0.3 1.3], [0 0], 'r--', 'LineWidth', 1.5);
plot([0.3 1.3], [-15 -15], 'g:', 'LineWidth', 1);
plot([0.3 1.3], [15 15], 'g:', 'LineWidth', 1);
xline(0.87, 'k--', 'IRT', 'LineWidth', 1, 'LabelHorizontalAlignment', 'center');
xline(1.00, 'k--', 'MIL', 'LineWidth', 1, 'LabelHorizontalAlignment', 'center');
xlabel('PLA (non-dimensional)', 'FontSize', 11);
ylabel('Error (%)', 'FontSize', 11);
title('Error vs Throttle (blue=dry, yellow=AB)', 'FontSize', 12, 'FontWeight', 'bold');
colormap(jet);
grid on;
xlim([0.25 1.35]);

% Absolute error map (Altitude vs Mach)
subplot(2,3,6)
[M_grid, Alt_grid] = meshgrid(unique(machs_all), unique(alts_m));
Error_grid = NaN(size(M_grid));
for i = 1:numel(M_grid)
    idx_match = valid & abs(x29_data.Mach - M_grid(i)) < 0.05 & abs(alts_m - Alt_grid(i)) < 0.5;
    if sum(idx_match) > 0
        Error_grid(i) = mean(abs(thrust_error_percent(idx_match)));
    end
end
contourf(M_grid, Alt_grid, Error_grid, 15, 'LineColor', 'none');
hold on;
scatter(machs_all, alts_m, 30, 'k', 'filled', 'MarkerFaceAlpha', 0.3);
xlabel('Mach Number', 'FontSize', 11);
ylabel('Altitude (km)', 'FontSize', 11);
title('MAPE Heat Map (%)', 'FontSize', 12, 'FontWeight', 'bold');
colorbar;
colormap(jet);
grid on;

sgtitle('X-29 F404-GE-400 Validation Results', 'FontSize', 14, 'FontWeight', 'bold');

% Save plot
output_dir = fullfile(project_root, 'engine_model', 'data', 'sweep_results');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end
saveas(fig, fullfile(output_dir, 'X29_validation_results.png'));
fprintf('\nSaved validation plot: X29_validation_results.png\n');

%% Generate thrust tables for trajectory simulation
fprintf('\n=== Thrust Tables for X-29 Trajectory Simulation ===\n');

% Generate clean lookup tables
alt_grid_km = [0, 3, 6, 9, 12, 15];
mach_grid = [0.0, 0.3, 0.6, 0.9, 1.2, 1.5];
pla_grid = [0.30, 0.50, 0.70, 0.87, 1.00, 1.10, 1.20, 1.30];

fprintf('\nGenerating thrust lookup tables...\n');
fprintf('Altitude grid: [%s] km\n', sprintf('%.0f ', alt_grid_km));
fprintf('Mach grid:     [%s]\n', sprintf('%.1f ', mach_grid));
fprintf('PLA grid:      [%s]\n\n', sprintf('%.2f ', pla_grid));

thrust_table = zeros(length(alt_grid_km), length(mach_grid), length(pla_grid));
tsfc_table = zeros(length(alt_grid_km), length(mach_grid), length(pla_grid));

for i_alt = 1:length(alt_grid_km)
    for i_mach = 1:length(mach_grid)
        for i_pla = 1:length(pla_grid)
            alt_m = alt_grid_km(i_alt) * 1000;
            M0 = mach_grid(i_mach);
            PLA = pla_grid(i_pla);
            AB = double(PLA > 0.87);  % AB on above IRT

            [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);

            op = struct();
            op.params = in.params;
            op.atm = struct('T0', T0, 'p0', p0, 'rho0', p0/(287*T0), 'alt', alt_m);
            op.M0 = M0;
            op.PLA = PLA;
            op.AB = AB;

            try
                cycle = solve_cycle(cfg, op);
                thrust_table(i_alt, i_mach, i_pla) = cycle.Thrust;
                tsfc_table(i_alt, i_mach, i_pla) = cycle.TSFC;
            catch
                thrust_table(i_alt, i_mach, i_pla) = NaN;
                tsfc_table(i_alt, i_mach, i_pla) = NaN;
            end
        end
    end
end

% Save lookup tables
save(fullfile(output_dir, 'X29_thrust_tables.mat'), ...
    'thrust_table', 'tsfc_table', 'alt_grid_km', 'mach_grid', 'pla_grid', ...
    'MAPE', 'RMSE', 'R2');

fprintf('Saved thrust lookup tables: X29_thrust_tables.mat\n');
fprintf('\nUsage in trajectory simulation:\n');
fprintf('  load(''X29_thrust_tables.mat'');\n');
fprintf('  thrust_N = interpn(alt_grid_km, mach_grid, pla_grid, thrust_table, alt_km, mach, pla);\n');

%% Summary
fprintf('\n=== VALIDATION SUMMARY ===\n');
fprintf('Configuration:  F404-GE-400 for X-29 Trajectory Simulation\n');
fprintf('Data Source:    NASA TM-4140\n');
fprintf('Flight Envelope: 0-%.0f ft (0-%.1f km), Mach 0-%.1f\n', ...
    max(x29_data.alt_ft), max(x29_data.alt_ft)*0.3048/1000, max(x29_data.Mach));
fprintf('Validation Points: %d\n', sum(valid));
fprintf('MAPE:           %.2f %%\n', MAPE);
fprintf('R²:             %.4f\n', R2);

if MAPE < 15 && R2 > 0.90
    fprintf('\n✅ MODEL VALIDATED FOR X-29 TRAJECTORY SIMULATION\n');
else
    fprintf('\n⚠️  MODEL NEEDS FURTHER CALIBRATION\n');
end

fprintf('\n=== END OF VALIDATION ===\n');

%% Helper function
function PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg)
    % Convert PLA from degrees (0-130) to non-dimensional (0.30-1.30)
    % Based on F404 FADEC scheduling
    PLA_breakpoints = [0, 70, 87, 109, 130];
    nondim_values   = [0, 0.30, 0.87, 1.09, 1.30];
    PLA_nondim = interp1(PLA_breakpoints, nondim_values, PLA_deg, 'linear', 'extrap');
end
