% GENERATE_PERFORMANCE_maps - Create comprehensive performance visualizations
% Generates altitude and Mach sweeps with detailed performance maps
clear; clc; close all;

project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

fprintf('=== Generating F404 Performance Maps ===\n\n');

%% High-resolution sweep grid
alt_vec_m = linspace(0, 15200, 20);  % 20 altitude points
mach_vec = linspace(0.0, 1.6, 25);    % 25 Mach points
alt_vec_km = alt_vec_m / 1000;

PLA_cases = [0.30, 0.87, 1.00, 1.30];
PLA_names = {'Idle', 'IRT (87%)', 'MIL (100%)', 'MAX AB'};
AB_cases = [0, 0, 0, 1];

n_alt = length(alt_vec_m);
n_mach = length(mach_vec);
n_pla = length(PLA_cases);

fprintf('Grid: %d altitudes x %d Mach x %d power = %d points\n\n', ...
    n_alt, n_mach, n_pla, n_alt*n_mach*n_pla);

%% Setup
cfg = config_model();
in = inputs_F404_calibrated(cfg);

%% Storage arrays
thrust = NaN(n_alt, n_mach, n_pla);
tsfc = NaN(n_alt, n_mach, n_pla);
fuel_flow = NaN(n_alt, n_mach, n_pla);

%% Run sweep
fprintf('Computing performance maps...\n');
tic;
for ip = 1:n_pla
    fprintf('  %s...', PLA_names{ip});
    for ia = 1:n_alt
        [~,~,~,~,~,~,~,~,p0,T0] = standard_atmosphere(alt_vec_m(ia));
        for im = 1:n_mach
            op = struct();
            op.params = in.params;
            op.atm = struct('T0',T0, 'p0',p0, 'rho0',p0/(287*T0));
            op.M0 = mach_vec(im);
            op.alt = alt_vec_m(ia);
            op.PLA = PLA_cases(ip);
            op.AB = AB_cases(ip);

            try
                cycle = solve_cycle(cfg, op);
                thrust(ia,im,ip) = cycle.Thrust;
                tsfc(ia,im,ip) = cycle.TSFC;
                fuel_flow(ia,im,ip) = cycle.Thrust * cycle.TSFC;
            catch
                % Leave as NaN
            end
        end
    end
    fprintf(' done\n');
end
elapsed = toc;
fprintf('Completed in %.1f seconds\n\n', elapsed);

%% Output directory
output_dir = fullfile(project_root, 'engine_model', 'data', 'performance_maps');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

%% Save summary
fprintf('Performance at Design Point (M=1.4 @ 12.2 km, MAX AB):\n');
[~, ia] = min(abs(alt_vec_m - 12200));
[~, im] = min(abs(mach_vec - 1.4));
fprintf('  Thrust: %.2f kN\n', thrust(ia,im,4)/1000);
fprintf('  TSFC: %.2e kg/N/s\n', tsfc(ia,im,4));
fprintf('  Fuel Flow: %.2f kg/s\n\n', fuel_flow(ia,im,4));

%% Save data
perf_data = struct();
perf_data.altitude_m = alt_vec_m;
perf_data.altitude_km = alt_vec_km;
perf_data.mach = mach_vec;
perf_data.PLA = PLA_cases;
perf_data.thrust = thrust;
perf_data.tsfc = tsfc;
perf_data.fuel_flow = fuel_flow;

save(fullfile(output_dir, 'performance_data.mat'), 'perf_data');
fprintf('Saved: performance_data.mat\n');
fprintf('Data saved to: %s\n', output_dir);
