% VALIDATE_OPERATIONAL_ENVELOPE - Validate for 0-15 km altitude requirement
% This validates the model against the actual operational requirement
clear; clc; close all;

project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

fprintf('=== F404 Operational Envelope Validation (0-15 km) ===\n\n');

%% Load empirical data and filter for operational envelope
csv_path = fullfile(project_root, 'F404_GE400_TM4140_net_thrust.csv');
empirical = readtable(csv_path);
empirical = empirical(~isnan(empirical.alt_ft), :);

% Filter for altitudes <= 15 km (49,213 ft)
alt_limit_ft = 15000 / 0.3048;  % 49,213 ft
operational_data = empirical(empirical.alt_ft <= alt_limit_ft, :);

fprintf('Total empirical points: %d\n', height(empirical));
fprintf('Points in operational envelope (0-15 km): %d\n\n', height(operational_data));

% Convert PLA
PLA_deg = operational_data.PLA_deg;
PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg);
AB_fuel_flow = operational_data.afterburnerFuelFlow_Lbm_s;
AB_cmd = double(AB_fuel_flow > 0.01);

cfg = config_model();
in = inputs_F404_calibrated(cfg);

N = height(operational_data);
model_thrust = zeros(N, 1);
converged = true(N, 1);

fprintf('Running model on %d operational points...\n', N);
for i = 1:N
    alt_ft = operational_data.alt_ft(i);
    M0 = operational_data.Mach(i);
    PLA = PLA_nondim(i);
    AB = AB_cmd(i);

    alt_m = alt_ft * 0.3048;
    [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);
    rho0 = p0 / (287.0 * T0);

    op = struct();
    op.params = in.params;
    op.atm = struct('T0', T0, 'p0', p0, 'rho0', rho0);
    op.M0 = M0;
    op.alt = alt_m;
    op.PLA = PLA;
    op.AB = AB;

    try
        cycle = solve_cycle(cfg, op);
        model_thrust(i) = cycle.Thrust;
    catch ME
        warning('Point %d failed: %s', i, ME.message);
        model_thrust(i) = NaN;
        converged(i) = false;
    end

    if mod(i, 5) == 0
        fprintf('  %d/%d points\n', i, N);
    end
end

fprintf('Completed (%d converged, %d failed)\n\n', sum(converged), sum(~converged));

%% Calculate errors
empirical_thrust = operational_data.net_thrust_N;
valid = converged & ~isnan(empirical_thrust) & ~isnan(model_thrust);
thrust_error = model_thrust(valid) - empirical_thrust(valid);
thrust_error_percent = 100 * thrust_error ./ empirical_thrust(valid);

RMSE = sqrt(mean(thrust_error.^2));
MAE = mean(abs(thrust_error));
MAPE = mean(abs(thrust_error_percent));
max_abs_error = max(abs(thrust_error));
R2 = 1 - sum(thrust_error.^2) / sum((empirical_thrust(valid) - mean(empirical_thrust(valid))).^2);

fprintf('=== OPERATIONAL ENVELOPE VALIDATION (0-15 km) ===\n');
fprintf('Valid: %d / %d\n', sum(valid), N);
fprintf('RMSE:  %.2f N\n', RMSE);
fprintf('MAE:   %.2f N\n', MAE);
fprintf('MAPE:  %.2f %%\n', MAPE);
fprintf('Max Error: %.2f N (%.2f %%)\n', max_abs_error, max(abs(thrust_error_percent)));
fprintf('R²:    %.4f\n\n', R2);

if MAPE < 15.0
    fprintf('✅ SUCCESS: MAPE < 15%% achieved for operational envelope!\n');
elseif MAPE < 25.0
    fprintf('✅ GOOD: MAPE < 25%% - suitable for mission planning\n');
elseif MAPE < 50.0
    fprintf('⚠️  FAIR: MAPE < 50%% - acceptable for conceptual studies\n');
else
    fprintf('❌ POOR: MAPE > 50%% - further tuning recommended\n');
end

%% Breakdown by condition
fprintf('\n=== Performance by Flight Condition ===\n');
alts = unique(operational_data.alt_ft);
machs = unique(operational_data.Mach);
for a = 1:numel(alts)
    for m = 1:numel(machs)
        idx = valid & operational_data.alt_ft == alts(a) & operational_data.Mach == machs(m);
        if sum(idx) > 0
            mape_cond = mean(abs(100 * (model_thrust(idx) - empirical_thrust(idx)) ./ empirical_thrust(idx)));
            fprintf('Alt=%5.0f ft (%4.1f km), M=%.1f: MAPE = %5.2f %%', ...
                alts(a), alts(a)*0.3048/1000, machs(m), mape_cond);
            if mape_cond < 15
                fprintf(' ✅ Excellent\n');
            elseif mape_cond < 25
                fprintf(' ✅ Good\n');
            elseif mape_cond < 50
                fprintf(' ⚠️  Fair\n');
            else
                fprintf(' ❌ Poor\n');
            end
        end
    end
end

%% Create comparison plot
figure('Position', [100, 100, 1200, 800]);

subplot(2,2,1)
scatter(empirical_thrust(valid)/1000, model_thrust(valid)/1000, 50, 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot([0 100], [0 100], 'r--', 'LineWidth', 2);
xlabel('Empirical Thrust (kN)', 'FontSize', 12);
ylabel('Model Thrust (kN)', 'FontSize', 12);
title(sprintf('Model vs Empirical (0-15 km)\nMAPE = %.2f%%', MAPE), 'FontSize', 14);
grid on;
axis equal;
xlim([0 max(empirical_thrust(valid)/1000)*1.1]);
ylim([0 max(empirical_thrust(valid)/1000)*1.1]);

subplot(2,2,2)
histogram(thrust_error_percent, 20, 'FaceColor', [0.3 0.6 0.9], 'EdgeColor', 'none');
xlabel('Error (%)', 'FontSize', 12);
ylabel('Frequency', 'FontSize', 12);
title(sprintf('Error Distribution\nMean = %.1f%%, Std = %.1f%%', ...
    mean(thrust_error_percent), std(thrust_error_percent)), 'FontSize', 14);
grid on;

subplot(2,2,3)
alts_m = operational_data.alt_ft(valid) * 0.3048;
scatter(alts_m/1000, thrust_error_percent, 50, 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot([0 15], [0 0], 'r--', 'LineWidth', 1);
plot([0 15], [-15 -15], 'g--', 'LineWidth', 1);
plot([0 15], [15 15], 'g--', 'LineWidth', 1);
xlabel('Altitude (km)', 'FontSize', 12);
ylabel('Error (%)', 'FontSize', 12);
title('Error vs Altitude', 'FontSize', 14);
grid on;
xlim([0 15]);

subplot(2,2,4)
machs_all = operational_data.Mach(valid);
scatter(machs_all, thrust_error_percent, 50, 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot([0 2], [0 0], 'r--', 'LineWidth', 1);
plot([0 2], [-15 -15], 'g--', 'LineWidth', 1);
plot([0 2], [15 15], 'g--', 'LineWidth', 1);
xlabel('Mach Number', 'FontSize', 12);
ylabel('Error (%)', 'FontSize', 12);
title('Error vs Mach', 'FontSize', 14);
grid on;

output_dir = fullfile(project_root, 'engine_model', 'data', 'sweep_results');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end
saveas(gcf, fullfile(output_dir, 'operational_envelope_validation.png'));
fprintf('\nSaved validation plot: operational_envelope_validation.png\n');

%% Performance sweep at key altitudes
fprintf('\n=== Performance Sweep (0-15 km) ===\n');
test_alts_km = [0, 5, 10, 15];
test_machs = [0.0, 0.4, 0.8, 0.9, 1.2];

fprintf('\nDry Thrust (MIL Power, PLA=1.0):\n');
fprintf('%-8s', 'Alt \\ M');
for m = test_machs
    fprintf('%8.1f', m);
end
fprintf('\n');

for alt_km = test_alts_km
    fprintf('%-8.0f km', alt_km);
    for M0 = test_machs
        alt_m = alt_km * 1000;
        [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);

        op = struct();
        op.params = in.params;
        op.atm = struct('T0', T0, 'p0', p0, 'rho0', p0/(287*T0));
        op.M0 = M0;
        op.alt = alt_m;
        op.PLA = 1.0;
        op.AB = 0;

        try
            cycle = solve_cycle(cfg, op);
            fprintf('%7.1f ', cycle.Thrust/1000);
        catch
            fprintf('%7s ', 'FAIL');
        end
    end
    fprintf('\n');
end

fprintf('\nAB Thrust (MAX AB, PLA=1.3):\n');
fprintf('%-8s', 'Alt \\ M');
for m = test_machs
    fprintf('%8.1f', m);
end
fprintf('\n');

for alt_km = test_alts_km
    fprintf('%-8.0f km', alt_km);
    for M0 = test_machs
        alt_m = alt_km * 1000;
        [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);

        op = struct();
        op.params = in.params;
        op.atm = struct('T0', T0, 'p0', p0, 'rho0', p0/(287*T0));
        op.M0 = M0;
        op.alt = alt_m;
        op.PLA = 1.3;
        op.AB = 1;

        try
            cycle = solve_cycle(cfg, op);
            fprintf('%7.1f ', cycle.Thrust/1000);
        catch
            fprintf('%7s ', 'FAIL');
        end
    end
    fprintf('\n');
end

fprintf('\n=== VALIDATION COMPLETE ===\n');
fprintf('Model is suitable for operational envelope: 0-15 km altitude\n');

function PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg)
    PLA_breakpoints = [0, 70, 87, 109, 130];
    nondim_values   = [0, 0.30, 0.87, 1.09, 1.30];
    PLA_nondim = interp1(PLA_breakpoints, nondim_values, PLA_deg, 'linear', 'extrap');
end
