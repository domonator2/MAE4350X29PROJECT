% VALIDATE_WITH_LOOKUP Validate using exact same setup as lookup table creation
%
% This ensures consistent baseline between calibration and validation

clear; clc; close all;

project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

csv_path = fullfile(project_root, 'F404_GE400_TM4140_net_thrust.csv');
empirical = readtable(csv_path);
empirical = empirical(~isnan(empirical.alt_ft), :);

fprintf('=== F404 Validation with Lookup Table ===\n');
fprintf('Loaded %d test points\n\n', height(empirical));

PLA_deg = empirical.PLA_deg;
PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg);
AB_fuel_flow = empirical.afterburnerFuelFlow_Lbm_s;
AB_cmd = double(AB_fuel_flow > 0.01);

cfg = config_model();
in = inputs_F404_defaults(cfg);

N = height(empirical);
model_thrust = zeros(N, 1);

fprintf('Running model with lookup correction...\n');

for i = 1:N
    alt_ft = empirical.alt_ft(i);
    M0 = empirical.Mach(i);
    PLA = PLA_nondim(i);
    AB = AB_cmd(i);

    alt_m = alt_ft * 0.3048;
    [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);
    rho0 = p0 / (287.0 * T0);

    op = struct();
    op.params = in.params;

    % Use EXACT same settings as lookup table creation
    op.params.Tt4_idle = 1350;
    op.params.Tt4_MIL = 1700;
    op.params.Tt4_MAX = 2100;

    % Disable ALL other corrections (match lookup calibration baseline)
    op.params.thrust_scale_dry_pla_vals = ones(size(op.params.thrust_scale_dry_pla_vals));
    op.params.thrust_scale_ab_pla_vals = ones(size(op.params.thrust_scale_ab_pla_vals));
    op.params.alt_thrust_corr_vals = ones(size(op.params.alt_thrust_corr_vals));
    op.params.mach_thrust_corr_vals = ones(size(op.params.mach_thrust_corr_vals));
    op.params.thrust_scale_dry = 1.0;
    op.params.thrust_scale_ab = 1.0;
    op.params.use_2d_correction = false;

    % Enable lookup correction
    op.params.use_lookup_correction = true;

    op.atm = struct('T0', T0, 'p0', p0, 'rho0', rho0);
    op.M0 = M0;
    op.alt = alt_m;
    op.PLA = PLA;
    op.AB = AB;

    try
        cycle = solve_cycle(cfg, op);
        model_thrust(i) = cycle.Thrust;
    catch ME
        warning('Point %d failed: %s', i, ME.message);
        model_thrust(i) = NaN;
    end

    if mod(i, 10) == 0
        fprintf('  %d/%d points\n', i, N);
    end
end

fprintf('Completed\n\n');

empirical_thrust = empirical.net_thrust_N;

% Compute errors
valid = ~isnan(empirical_thrust) & ~isnan(model_thrust);
thrust_error = model_thrust(valid) - empirical_thrust(valid);
thrust_error_percent = 100 * thrust_error ./ empirical_thrust(valid);

RMSE = sqrt(mean(thrust_error.^2));
MAE = mean(abs(thrust_error));
MAPE = mean(abs(thrust_error_percent));
max_abs_error = max(abs(thrust_error));
R2 = 1 - sum(thrust_error.^2) / sum((empirical_thrust(valid) - mean(empirical_thrust(valid))).^2);

fprintf('=== Validation Results ===\n');
fprintf('Valid points: %d / %d\n', sum(valid), N);
fprintf('RMSE:  %.2f N\n', RMSE);
fprintf('MAE:   %.2f N\n', MAE);
fprintf('MAPE:  %.2f %%\n', MAPE);
fprintf('Max Error: %.2f N (%.2f %%)\n', max_abs_error, max(abs(thrust_error_percent)));
fprintf('R²:    %.4f\n', R2);

% Breakdown by flight condition
fprintf('\n=== Error by Flight Condition ===\n');
alts = unique(empirical.alt_ft);
machs = unique(empirical.Mach);
for a = 1:numel(alts)
    for m = 1:numel(machs)
        idx = valid & empirical.alt_ft == alts(a) & empirical.Mach == machs(m);
        if sum(idx) > 0
            err = model_thrust(idx) - empirical_thrust(idx);
            mape_cond = mean(abs(100 * err ./ empirical_thrust(idx)));
            fprintf('Alt=%5.0f ft, M=%.1f: MAPE = %5.2f %%\n', alts(a), machs(m), mape_cond);
        end
    end
end

function PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg)
    PLA_breakpoints = [0, 70, 87, 109, 130];
    nondim_values   = [0, 0.30, 0.87, 1.09, 1.30];
    PLA_nondim = interp1(PLA_breakpoints, nondim_values, PLA_deg, 'linear', 'extrap');
end
