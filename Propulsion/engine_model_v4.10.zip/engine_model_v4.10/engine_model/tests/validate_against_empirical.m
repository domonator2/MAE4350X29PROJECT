% VALIDATE_AGAINST_EMPIRICAL Compare model predictions to F404 empirical data
%
% This script:
%   1. Loads empirical data from F404_GE400_TM4140_net_thrust.csv
%   2. Runs the engine model at each test condition
%   3. Compares predicted vs empirical thrust
%   4. Computes error metrics (RMSE, MAE, MAPE, max error)
%   5. Generates detailed comparison table and visualizations

clear; clc; close all;

% Setup environment
project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

% Load empirical data
csv_path = fullfile(project_root, 'F404_GE400_TM4140_net_thrust.csv');
empirical = readtable(csv_path);

% Remove empty rows
empirical = empirical(~isnan(empirical.alt_ft), :);

fprintf('=== F404 Model Validation Against Empirical Data ===\n');
fprintf('Loaded %d test points from: %s\n\n', height(empirical), csv_path);

% Initialize model
cfg = config_model();
in = inputs_F404_defaults(cfg);

% Convert PLA from degrees to nondimensional (0-1.3 scale)
% Assuming: 0 deg = 0.0, 70 deg = 0.3 (idle), 87 deg = 0.87, 109 deg = 1.09, 130 deg = 1.3
PLA_deg = empirical.PLA_deg;
PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg);

% Determine AB command based on actual afterburner fuel flow
% AB is engaged when afterburner fuel flow > 0 (more accurate than PLA threshold)
% MATLAB modifies column name "afterburner fuel flow, lbm/s" to camelCase identifier
AB_fuel_flow = empirical.afterburnerFuelFlow_Lbm_s;
AB_cmd = double(AB_fuel_flow > 0.01);  % threshold to avoid numerical noise

% Initialize results storage
N = height(empirical);
model_thrust = zeros(N, 1);
model_tsfc = zeros(N, 1);
converged = true(N, 1);

% Run model for each test point
fprintf('Running model for %d test points...\n', N);
for i = 1:N
    % Extract flight condition
    alt_ft = empirical.alt_ft(i);
    M0 = empirical.Mach(i);
    PLA = PLA_nondim(i);
    AB = AB_cmd(i);

    % Convert altitude to meters
    alt_m = alt_ft * 0.3048;

    % Get atmospheric conditions
    % standard_atmosphere outputs: [a, rho, mu, nu, theta, delta, sigma, z, P, T]
    [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);
    rho0 = p0 / (287.0 * T0);  % Compute density from ideal gas law

    % Setup operating point
    op = struct();
    op.params = in.params;
    op.atm = struct('T0', T0, 'p0', p0, 'rho0', rho0);
    op.M0 = M0;
    op.alt = alt_m;
    op.PLA = PLA;
    op.AB = AB;

    % Run cycle analysis
    try
        cycle = solve_cycle(cfg, op);
        model_thrust(i) = cycle.Thrust;
        model_tsfc(i) = cycle.TSFC;
        converged(i) = true;
    catch ME
        warning('Point %d failed to converge: %s', i, ME.message);
        model_thrust(i) = NaN;
        model_tsfc(i) = NaN;
        converged(i) = false;
    end

    if mod(i, 10) == 0
        fprintf('  Completed %d/%d points\n', i, N);
    end
end

fprintf('Completed all points (%d converged, %d failed)\n\n', sum(converged), sum(~converged));

% Extract empirical thrust
empirical_thrust = empirical.net_thrust_N;

% Compute errors (only for converged points)
valid = converged & ~isnan(empirical_thrust) & ~isnan(model_thrust);
thrust_error = model_thrust(valid) - empirical_thrust(valid);
thrust_error_percent = 100 * thrust_error ./ empirical_thrust(valid);

% Error metrics
RMSE = sqrt(mean(thrust_error.^2));
MAE = mean(abs(thrust_error));
MAPE = mean(abs(thrust_error_percent));
max_abs_error = max(abs(thrust_error));
max_percent_error = max(abs(thrust_error_percent));
R2 = 1 - sum(thrust_error.^2) / sum((empirical_thrust(valid) - mean(empirical_thrust(valid))).^2);

% Print error summary
fprintf('=== Error Metrics (Net Thrust) ===\n');
fprintf('Valid points: %d / %d\n', sum(valid), N);
fprintf('RMSE:              %.2f N\n', RMSE);
fprintf('MAE:               %.2f N\n', MAE);
fprintf('MAPE:              %.2f %%\n', MAPE);
fprintf('Max Absolute Error: %.2f N (%.2f %%)\n', max_abs_error, max_percent_error);
fprintf('R-squared:         %.4f\n', R2);
fprintf('==================================\n\n');

% Breakdown by method (Wind Tunnel vs Analytical Prediction)
methods = unique(empirical.method);
for m = 1:numel(methods)
    method = methods{m};
    idx = valid & strcmp(empirical.method, method);
    if sum(idx) > 0
        err = model_thrust(idx) - empirical_thrust(idx);
        rmse_method = sqrt(mean(err.^2));
        mape_method = mean(abs(100 * err ./ empirical_thrust(idx)));
        fprintf('%s: RMSE = %.2f N, MAPE = %.2f %%, N = %d\n', ...
            method, rmse_method, mape_method, sum(idx));
    end
end
fprintf('\n');

% Breakdown by flight condition
fprintf('=== Error by Flight Condition ===\n');
alts = unique(empirical.alt_ft);
machs = unique(empirical.Mach);
for a = 1:numel(alts)
    for m = 1:numel(machs)
        idx = valid & empirical.alt_ft == alts(a) & empirical.Mach == machs(m);
        if sum(idx) > 0
            err = model_thrust(idx) - empirical_thrust(idx);
            rmse_cond = sqrt(mean(err.^2));
            mape_cond = mean(abs(100 * err ./ empirical_thrust(idx)));
            fprintf('Alt=%5.0f ft, M=%.1f: RMSE = %6.2f N, MAPE = %5.2f %%, N = %2d\n', ...
                alts(a), machs(m), rmse_cond, mape_cond, sum(idx));
        end
    end
end
fprintf('==================================\n\n');

% Create detailed comparison table
comparison = table( ...
    empirical.alt_ft, ...
    empirical.Mach, ...
    empirical.PLA_deg, ...
    PLA_nondim, ...
    AB_cmd, ...
    empirical.method, ...
    empirical_thrust, ...
    model_thrust, ...
    model_thrust - empirical_thrust, ...
    100 * (model_thrust - empirical_thrust) ./ empirical_thrust, ...
    converged, ...
    'VariableNames', {'Alt_ft', 'Mach', 'PLA_deg', 'PLA_nondim', 'AB', 'Method', ...
                      'Empirical_N', 'Model_N', 'Error_N', 'Error_pct', 'Converged'});

% Save results
output_dir = fullfile(project_root, 'engine_model', 'data');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

comparison_file = fullfile(output_dir, 'model_vs_empirical_comparison.csv');
writetable(comparison, comparison_file);
fprintf('Saved detailed comparison to: %s\n', comparison_file);

% Save error summary
summary_file = fullfile(output_dir, 'validation_summary.txt');
fid = fopen(summary_file, 'w');
fprintf(fid, '=== F404 Model Validation Summary ===\n');
fprintf(fid, 'Date: %s\n\n', datestr(now));
fprintf(fid, 'Valid points: %d / %d\n', sum(valid), N);
fprintf(fid, 'RMSE:              %.2f N\n', RMSE);
fprintf(fid, 'MAE:               %.2f N\n', MAE);
fprintf(fid, 'MAPE:              %.2f %%\n', MAPE);
fprintf(fid, 'Max Absolute Error: %.2f N (%.2f %%)\n', max_abs_error, max_percent_error);
fprintf(fid, 'R-squared:         %.4f\n', R2);
fclose(fid);
fprintf('Saved error summary to: %s\n\n', summary_file);

% Generate visualizations
generate_validation_plots(empirical, model_thrust, empirical_thrust, valid, output_dir);

fprintf('=== Validation Complete ===\n');

%% Helper Functions

function PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg)
    % Convert PLA from degrees to nondimensional scale
    % F404 throttle mapping (corrected):
    % 0° = cutoff, 70° = idle (0.30), 87° = MIL (0.87), 109° = 1.09, 130° = MAX AB (1.30)
    % Use piecewise linear interpolation based on F404 actual schedule
    PLA_breakpoints = [0, 70, 87, 109, 130];
    nondim_values   = [0, 0.30, 0.87, 1.09, 1.30];
    PLA_nondim = interp1(PLA_breakpoints, nondim_values, PLA_deg, 'linear', 'extrap');
end

function generate_validation_plots(empirical, model_thrust, empirical_thrust, valid, output_dir)
    % Generate validation plots

    % 1. Parity plot
    figure('Position', [100, 100, 800, 600]);
    scatter(empirical_thrust(valid)/1000, model_thrust(valid)/1000, 50, 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    plot([0 70], [0 70], 'k--', 'LineWidth', 1.5);
    xlabel('Empirical Thrust (kN)', 'FontSize', 12);
    ylabel('Model Thrust (kN)', 'FontSize', 12);
    title('F404 Model vs Empirical: Thrust Parity Plot', 'FontSize', 14);
    grid on;
    axis equal;
    max_thrust = max([empirical_thrust(valid); model_thrust(valid)])/1000;
    if max_thrust > 0
        xlim([0 max_thrust*1.1]);
        ylim([0 max_thrust*1.1]);
    end

    % Add R^2 and RMSE to plot
    err = model_thrust(valid) - empirical_thrust(valid);
    R2 = 1 - sum(err.^2) / sum((empirical_thrust(valid) - mean(empirical_thrust(valid))).^2);
    RMSE = sqrt(mean(err.^2));
    text(0.05, 0.95, sprintf('R^2 = %.4f\nRMSE = %.2f N', R2, RMSE), ...
        'Units', 'normalized', 'FontSize', 11, 'VerticalAlignment', 'top', ...
        'BackgroundColor', 'white', 'EdgeColor', 'black');

    saveas(gcf, fullfile(output_dir, 'thrust_parity_plot.png'));
    fprintf('Saved parity plot to: %s\n', fullfile(output_dir, 'thrust_parity_plot.png'));

    % 2. Error vs PLA
    figure('Position', [100, 100, 1000, 600]);
    error_pct = 100 * (model_thrust(valid) - empirical_thrust(valid)) ./ empirical_thrust(valid);
    scatter(empirical.PLA_deg(valid), error_pct, 50, 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    plot([60 140], [0 0], 'k--', 'LineWidth', 1.5);
    xlabel('PLA (degrees)', 'FontSize', 12);
    ylabel('Error (%)', 'FontSize', 12);
    title('Thrust Error vs PLA', 'FontSize', 14);
    grid on;

    saveas(gcf, fullfile(output_dir, 'error_vs_PLA.png'));
    fprintf('Saved error vs PLA plot to: %s\n', fullfile(output_dir, 'error_vs_PLA.png'));

    % 3. Error distribution
    figure('Position', [100, 100, 800, 600]);
    histogram(error_pct, 20, 'FaceColor', [0.3 0.6 0.9], 'EdgeColor', 'k');
    xlabel('Error (%)', 'FontSize', 12);
    ylabel('Frequency', 'FontSize', 12);
    title('Thrust Error Distribution', 'FontSize', 14);
    grid on;

    saveas(gcf, fullfile(output_dir, 'error_distribution.png'));
    fprintf('Saved error distribution plot to: %s\n', fullfile(output_dir, 'error_distribution.png'));
end
