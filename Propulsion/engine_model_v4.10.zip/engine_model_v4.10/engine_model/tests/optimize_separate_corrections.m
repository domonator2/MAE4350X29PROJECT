% OPTIMIZE_SEPARATE_CORRECTIONS - Auto-tune separate dry/AB corrections
% This script optimizes the 8 correction parameters to minimize MAPE

clear; clc;
fprintf('=== Optimizing Separate Dry/AB Corrections ===\n\n');

% Add paths
project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

% Load empirical data
csv_path = fullfile(project_root, 'F404_GE400_TM4140_net_thrust.csv');
empirical = readtable(csv_path);
empirical = empirical(~isnan(empirical.alt_ft), :);

% Convert PLA
PLA_deg = empirical.PLA_deg;
PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg);
AB_fuel_flow = empirical.afterburnerFuelFlow_Lbm_s;
AB_cmd = double(AB_fuel_flow > 0.01);

N_points = height(empirical);
fprintf('Loaded %d empirical data points\n\n', N_points);

% Get baseline config
cfg = config_model();

% Define optimization parameters (8 total)
% x(1): dry PLA scaling at MIL (currently 2.8)
% x(2): AB altitude corr at 10k ft (currently 0.38)
% x(3): AB altitude corr at 30k ft (currently 0.20)
% x(4): AB altitude corr at 40k ft (currently 0.14)
% x(5): dry altitude corr at 10k ft (currently 1.2)
% x(6): dry altitude corr at 30k ft (currently 1.3)
% x(7): dry altitude corr at 40k ft (currently 1.4)
% x(8): AB PLA scaling at max AB (currently 1.25)

% Initial guess (current values)
x0 = [2.8, 0.38, 0.20, 0.14, 1.2, 1.3, 1.4, 1.25];

% Bounds
lb = [1.0, 0.05, 0.02, 0.01, 1.0, 1.0, 1.0, 0.5];  % Lower bounds
ub = [6.0, 0.80, 0.50, 0.40, 2.0, 2.0, 2.0, 2.0];  % Upper bounds

fprintf('Starting optimization...\n');
fprintf('Initial MAPE: ');

% Calculate initial MAPE
initial_mape = evaluate_corrections(x0, empirical, PLA_nondim, AB_cmd, cfg);
fprintf('%.2f %%\n\n', initial_mape);

% Optimization options
options = optimoptions('fmincon', ...
    'Display', 'iter', ...
    'MaxIterations', 100, ...
    'MaxFunctionEvaluations', 1000, ...
    'OptimalityTolerance', 1e-4, ...
    'StepTolerance', 1e-6, ...
    'Algorithm', 'interior-point');

% Run optimization
tic;
[x_opt, fval, exitflag] = fmincon(@(x) evaluate_corrections(x, empirical, PLA_nondim, AB_cmd, cfg), ...
    x0, [], [], [], [], lb, ub, [], options);
elapsed = toc;

fprintf('\n=== Optimization Complete ===\n');
fprintf('Time: %.1f seconds\n', elapsed);
fprintf('Exit flag: %d\n', exitflag);
fprintf('Final MAPE: %.2f %%\n\n', fval);

fprintf('=== Optimized Parameters ===\n');
fprintf('Dry PLA scaling at MIL:        %.3f (was %.3f)\n', x_opt(1), x0(1));
fprintf('AB alt corr at 10k ft:         %.3f (was %.3f)\n', x_opt(2), x0(2));
fprintf('AB alt corr at 30k ft:         %.3f (was %.3f)\n', x_opt(3), x0(3));
fprintf('AB alt corr at 40k ft:         %.3f (was %.3f)\n', x_opt(4), x0(4));
fprintf('Dry alt corr at 10k ft:        %.3f (was %.3f)\n', x_opt(5), x0(5));
fprintf('Dry alt corr at 30k ft:        %.3f (was %.3f)\n', x_opt(6), x0(6));
fprintf('Dry alt corr at 40k ft:        %.3f (was %.3f)\n', x_opt(7), x0(7));
fprintf('AB PLA scaling at MAX AB:      %.3f (was %.3f)\n', x_opt(8), x0(8));

% Apply optimized parameters and validate
fprintf('\n=== Applying Optimized Parameters ===\n');
apply_optimized_corrections(x_opt);
fprintf('Updated inputs_F404_defaults.m\n');

fprintf('\nRun validate_against_empirical.m to verify results.\n');

%% Helper Functions

function mape = evaluate_corrections(x, empirical, PLA_nondim, AB_cmd, cfg)
    % Evaluate MAPE for given correction parameters

    % Create temporary params with these corrections
    in = inputs_F404_defaults(cfg);

    % Apply parameters
    in.params.thrust_scale_dry_pla_vals(5) = x(1);  % MIL power scaling
    in.params.alt_thrust_corr_ab_vals = [1.0, x(2), 0.2, x(3), x(4)];  % AB altitude (5 points)
    in.params.alt_thrust_corr_dry_vals = [1.0, x(5), 1.25, x(6), x(7)];  % Dry altitude (5 points)
    in.params.thrust_scale_ab_pla_vals(4) = x(8);  % MAX AB PLA scaling

    N = height(empirical);
    model_thrust = zeros(N, 1);

    for i = 1:N
        alt_ft = empirical.alt_ft(i);
        M0 = empirical.Mach(i);
        PLA = PLA_nondim(i);
        AB = AB_cmd(i);

        alt_m = alt_ft * 0.3048;
        [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);

        op = struct();
        op.params = in.params;
        op.atm = struct('T0', T0, 'p0', p0, 'rho0', p0/(287.0*T0));
        op.M0 = M0;
        op.alt = alt_m;
        op.PLA = PLA;
        op.AB = AB;

        try
            cycle = solve_cycle(cfg, op);
            model_thrust(i) = cycle.Thrust;
        catch
            model_thrust(i) = NaN;
        end
    end

    empirical_thrust = empirical.net_thrust_N;
    valid = ~isnan(empirical_thrust) & ~isnan(model_thrust);

    if sum(valid) < 10
        mape = 1000;  % Penalty for too many failures
        return;
    end

    thrust_error_percent = 100 * abs(model_thrust(valid) - empirical_thrust(valid)) ./ empirical_thrust(valid);
    mape = mean(thrust_error_percent);
end

function apply_optimized_corrections(x)
    % Write optimized parameters to inputs file

    file_path = fullfile(fileparts(fileparts(mfilename('fullpath'))), 'data', 'inputs_F404_defaults.m');
    content = fileread(file_path);

    % Update dry PLA scaling at MIL
    pattern = 'params.thrust_scale_dry_pla_vals = \[0\.5, 1\.0, 1\.5, 2\.5, [\d.]+\];';
    replacement = sprintf('params.thrust_scale_dry_pla_vals = [0.5, 1.0, 1.5, 2.5, %.3f];', x(1));
    content = regexprep(content, pattern, replacement);

    % Update AB altitude corrections
    pattern = 'params.alt_thrust_corr_ab_vals = \[[\d., ]+\];  % STRONG';
    replacement = sprintf('params.alt_thrust_corr_ab_vals = [1.0, %.3f, 0.20, %.3f, %.3f];  % OPTIMIZED', x(2), x(3), x(4));
    content = regexprep(content, pattern, replacement);

    % Update dry altitude corrections
    pattern = 'params.alt_thrust_corr_dry_vals = \[[\d., ]+\];  % Moderate';
    replacement = sprintf('params.alt_thrust_corr_dry_vals = [1.0, %.3f, 1.25, %.3f, %.3f];  % OPTIMIZED', x(5), x(6), x(7));
    content = regexprep(content, pattern, replacement);

    % Update AB PLA scaling at MAX
    pattern = 'params.thrust_scale_ab_pla_vals = \[2\.5, 2\.0, 1\.5, [\d.]+\];';
    replacement = sprintf('params.thrust_scale_ab_pla_vals = [2.5, 2.0, 1.5, %.3f];', x(8));
    content = regexprep(content, pattern, replacement);

    % Write back
    fid = fopen(file_path, 'w');
    fprintf(fid, '%s', content);
    fclose(fid);
end

function PLA_nondim = convert_PLA_deg_to_nondim(PLA_deg)
    PLA_breakpoints = [0, 70, 87, 109, 130];
    nondim_values   = [0, 0.30, 0.87, 1.09, 1.30];
    PLA_nondim = interp1(PLA_breakpoints, nondim_values, PLA_deg, 'linear', 'extrap');
end
