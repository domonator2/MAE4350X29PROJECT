% VALIDATE_FULL_ENVELOPE - Comprehensive validation over 0-15.2 km, M=0-1.6
% Checks thrust and TSFC validity across the complete operational envelope
clear; clc; close all;

project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

fprintf('=== F404 Full Envelope Validation (0-15.2 km, M=0-1.6) ===\n\n');

%% Define envelope grid
alt_grid_km  = [0, 2.5, 5, 7.5, 10, 12.5, 15.2];  % km
alt_grid_m   = alt_grid_km * 1000;  % meters
mach_grid    = [0.0, 0.3, 0.6, 0.9, 1.2, 1.6];
PLA_grid     = [0.3, 0.87, 1.0, 1.3];  % Idle, IRT, MIL, MAX AB
PLA_names    = {'Idle', 'IRT', 'MIL', 'MAX AB'};
AB_grid      = [0, 0, 0, 1];  % AB only at MAX

n_alt  = length(alt_grid_m);
n_mach = length(mach_grid);
n_pla  = length(PLA_grid);
n_total = n_alt * n_mach * n_pla;

fprintf('Grid: %d altitudes × %d Mach × %d power settings = %d points\n\n', ...
    n_alt, n_mach, n_pla, n_total);

%% Setup
cfg = config_model();
in = inputs_F404_calibrated(cfg);

%% Run envelope sweep
thrust = NaN(n_alt, n_mach, n_pla);
tsfc   = NaN(n_alt, n_mach, n_pla);
converged = false(n_alt, n_mach, n_pla);

fprintf('Running envelope sweep...\n');
tic;
n_computed = 0;
n_failed = 0;

for ip = 1:n_pla
    PLA = PLA_grid(ip);
    AB = AB_grid(ip);
    fprintf('\n%s (PLA=%.2f, AB=%d):\n', PLA_names{ip}, PLA, AB);

    for ia = 1:n_alt
        alt_m = alt_grid_m(ia);
        [~,~,~,~,~,~,~,~,p0,T0] = standard_atmosphere(alt_m);

        for im = 1:n_mach
            M0 = mach_grid(im);

            % Setup operating point
            op = struct();
            op.params = in.params;
            op.atm = struct('T0',T0, 'p0',p0, 'rho0',p0/(287*T0));
            op.M0 = M0;
            op.alt = alt_m;
            op.PLA = PLA;
            op.AB = AB;

            % Run cycle
            try
                cycle = solve_cycle(cfg, op);

                % Check validity
                if ~isfinite(cycle.Thrust) || cycle.Thrust < 0
                    error('Invalid thrust: %.2f', cycle.Thrust);
                end
                if ~isfinite(cycle.TSFC) || cycle.TSFC <= 0
                    error('Invalid TSFC: %.2e', cycle.TSFC);
                end

                thrust(ia, im, ip) = cycle.Thrust;
                tsfc(ia, im, ip) = cycle.TSFC;
                converged(ia, im, ip) = true;
                n_computed = n_computed + 1;

            catch ME
                n_failed = n_failed + 1;
                if n_failed <= 5
                    fprintf('  FAILED: Alt=%.1f km, M=%.1f: %s\n', ...
                        alt_m/1000, M0, ME.message);
                end
            end
        end
    end

    fprintf('  Completed: %d converged, %d failed\n', ...
        sum(sum(converged(:,:,ip))), sum(sum(~converged(:,:,ip))));
end

elapsed = toc;
fprintf('\n=== Sweep Complete ===\n');
fprintf('Time: %.1f seconds\n', elapsed);
fprintf('Total: %d computed, %d failed (%.1f%% success)\n', ...
    n_computed, n_failed, 100*n_computed/n_total);

%% Validity checks
fprintf('\n=== VALIDITY CHECKS ===\n\n');

% Check thrust range
thrust_kN = thrust / 1000;
thrust_min = min(thrust_kN(converged));
thrust_max = max(thrust_kN(converged));
fprintf('Thrust range: %.1f to %.1f kN\n', thrust_min, thrust_max);

if thrust_min < 0 || thrust_max > 200
    fprintf('  ❌ WARNING: Thrust outside expected range [0, 200] kN\n');
else
    fprintf('  ✅ Thrust within reasonable bounds\n');
end

% Check TSFC range
tsfc_min = min(tsfc(converged));
tsfc_max = max(tsfc(converged));
fprintf('TSFC range: %.2e to %.2e kg/N/s\n', tsfc_min, tsfc_max);

% Expected TSFC for jet engines: ~1e-5 to ~1e-4 kg/N/s
if tsfc_min < 1e-6 || tsfc_max > 2e-4
    fprintf('  ❌ WARNING: TSFC outside expected range [1e-6, 2e-4]\n');
else
    fprintf('  ✅ TSFC within reasonable bounds\n');
end

% Check for NaNs
n_nan_thrust = sum(isnan(thrust(:)));
n_nan_tsfc = sum(isnan(tsfc(:)));
fprintf('\nNaN count: %d thrust, %d TSFC (out of %d)\n', ...
    n_nan_thrust, n_nan_tsfc, n_total);

if n_nan_thrust > 0 || n_nan_tsfc > 0
    fprintf('  ⚠️  Some points did not converge\n');
else
    fprintf('  ✅ All points converged\n');
end

%% Performance at design point
fprintf('\n=== DESIGN POINT: M=1.4 @ 12.2 km ===\n');
[~, idx_alt] = min(abs(alt_grid_m - 12200));
[~, idx_mach] = min(abs(mach_grid - 1.4));

if idx_mach > length(mach_grid)
    % Interpolate to M=1.4
    fprintf('  (Interpolating to M=1.4 from M=%.1f and M=%.1f)\n', ...
        mach_grid(end-1), mach_grid(end));

    for ip = 1:n_pla
        if converged(idx_alt, end-1, ip) && converged(idx_alt, end, ip)
            T_interp = interp1([mach_grid(end-1), mach_grid(end)], ...
                [thrust(idx_alt,end-1,ip), thrust(idx_alt,end,ip)], 1.4);
            TSFC_interp = interp1([mach_grid(end-1), mach_grid(end)], ...
                [tsfc(idx_alt,end-1,ip), tsfc(idx_alt,end,ip)], 1.4);
            fprintf('  %s: Thrust = %.2f kN, TSFC = %.2e kg/N/s\n', ...
                PLA_names{ip}, T_interp/1000, TSFC_interp);
        end
    end
else
    for ip = 1:n_pla
        if converged(idx_alt, idx_mach, ip)
            fprintf('  %s: Thrust = %.2f kN, TSFC = %.2e kg/N/s\n', ...
                PLA_names{ip}, thrust(idx_alt,idx_mach,ip)/1000, tsfc(idx_alt,idx_mach,ip));
        end
    end
end

%% Create validation plots
fprintf('\n=== Generating Plots ===\n');
output_dir = fullfile(project_root, 'engine_model', 'data', 'sweep_results');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

% Plot 1: Thrust vs Altitude (MIL power)
figure('Position', [100, 100, 1200, 500]);
subplot(1,2,1)
colors = lines(n_mach);
for im = 1:n_mach
    plot(alt_grid_km, thrust(:,im,3)/1000, '-o', 'LineWidth', 2, ...
        'Color', colors(im,:), 'DisplayName', sprintf('M=%.1f', mach_grid(im)));
    hold on;
end
xlabel('Altitude (km)', 'FontSize', 12);
ylabel('Thrust (kN)', 'FontSize', 12);
title('Dry Thrust vs Altitude (MIL Power)', 'FontSize', 14);
legend('Location', 'best');
grid on;

% Plot 2: TSFC vs Altitude (MIL power)
subplot(1,2,2)
for im = 1:n_mach
    plot(alt_grid_km, tsfc(:,im,3)*1e5, '-o', 'LineWidth', 2, ...
        'Color', colors(im,:), 'DisplayName', sprintf('M=%.1f', mach_grid(im)));
    hold on;
end
xlabel('Altitude (km)', 'FontSize', 12);
ylabel('TSFC (×10^{-5} kg/N/s)', 'FontSize', 12);
title('TSFC vs Altitude (MIL Power)', 'FontSize', 14);
legend('Location', 'best');
grid on;
saveas(gcf, fullfile(output_dir, 'full_envelope_altitude.png'));
fprintf('Saved: full_envelope_altitude.png\n');

% Plot 3: Thrust vs Mach (at design altitude 12.2 km)
figure('Position', [100, 100, 1200, 500]);
[~, idx_12km] = min(abs(alt_grid_m - 12200));
subplot(1,2,1)
plot(mach_grid, thrust(idx_12km,:,3)/1000, '-o', 'LineWidth', 2, 'DisplayName', 'Dry (MIL)');
hold on;
plot(mach_grid, thrust(idx_12km,:,4)/1000, '-s', 'LineWidth', 2, 'DisplayName', 'AB (MAX)');
xlabel('Mach Number', 'FontSize', 12);
ylabel('Thrust (kN)', 'FontSize', 12);
title('Thrust vs Mach at 12.2 km', 'FontSize', 14);
legend('Location', 'best');
grid on;

% Plot 4: TSFC vs Mach (at design altitude)
subplot(1,2,2)
plot(mach_grid, tsfc(idx_12km,:,3)*1e5, '-o', 'LineWidth', 2, 'DisplayName', 'Dry (MIL)');
hold on;
plot(mach_grid, tsfc(idx_12km,:,4)*1e5, '-s', 'LineWidth', 2, 'DisplayName', 'AB (MAX)');
xlabel('Mach Number', 'FontSize', 12);
ylabel('TSFC (×10^{-5} kg/N/s)', 'FontSize', 12);
title('TSFC vs Mach at 12.2 km', 'FontSize', 14);
legend('Location', 'best');
grid on;
saveas(gcf, fullfile(output_dir, 'full_envelope_mach.png'));
fprintf('Saved: full_envelope_mach.png\n');

% Plot 5: 3D surface - Thrust at MIL power
figure('Position', [100, 100, 1000, 700]);
[M_grid, Alt_grid] = meshgrid(mach_grid, alt_grid_km);
surf(M_grid, Alt_grid, thrust(:,:,3)/1000);
xlabel('Mach Number', 'FontSize', 12);
ylabel('Altitude (km)', 'FontSize', 12);
zlabel('Thrust (kN)', 'FontSize', 12);
title('Dry Thrust Surface (MIL Power)', 'FontSize', 14);
colorbar;
view(45, 30);
shading interp;
saveas(gcf, fullfile(output_dir, 'full_envelope_thrust_surface.png'));
fprintf('Saved: full_envelope_thrust_surface.png\n');

%% Save results to CSV
results_table = table();
for ip = 1:n_pla
    for ia = 1:n_alt
        for im = 1:n_mach
            row = table();
            row.PowerSetting = {PLA_names{ip}};
            row.PLA = PLA_grid(ip);
            row.AB = AB_grid(ip);
            row.Altitude_km = alt_grid_km(ia);
            row.Altitude_m = alt_grid_m(ia);
            row.Mach = mach_grid(im);
            row.Thrust_N = thrust(ia, im, ip);
            row.Thrust_kN = thrust(ia, im, ip) / 1000;
            row.TSFC_kg_per_N_s = tsfc(ia, im, ip);
            row.Converged = converged(ia, im, ip);
            results_table = [results_table; row];
        end
    end
end

csv_file = fullfile(output_dir, 'full_envelope_results.csv');
writetable(results_table, csv_file);
fprintf('Saved: full_envelope_results.csv\n');

%% Summary
fprintf('\n=== ENVELOPE VALIDATION SUMMARY ===\n');
fprintf('Grid: 0-15.2 km altitude, M=0-1.6\n');
fprintf('Success rate: %.1f%% (%d/%d points)\n', 100*n_computed/n_total, n_computed, n_total);
fprintf('\nThrust: %.1f to %.1f kN (valid range)\n', thrust_min, thrust_max);
fprintf('TSFC: %.2e to %.2e kg/N/s (valid range)\n', tsfc_min, tsfc_max);

if n_computed == n_total
    fprintf('\n✅ ALL POINTS CONVERGED - Envelope is fully operational!\n');
elseif n_computed >= 0.95*n_total
    fprintf('\n✅ >95%% CONVERGED - Envelope is operational with minor gaps\n');
elseif n_computed >= 0.80*n_total
    fprintf('\n⚠️  80-95%% CONVERGED - Some issues at extreme conditions\n');
else
    fprintf('\n❌ <80%% CONVERGED - Significant convergence issues\n');
end

fprintf('\nResults saved to: %s\n', output_dir);
