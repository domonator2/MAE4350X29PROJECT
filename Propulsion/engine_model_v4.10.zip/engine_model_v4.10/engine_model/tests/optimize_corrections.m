% OPTIMIZE_CORRECTIONS - Automatically optimize thrust correction factors
% Uses MATLAB's optimization toolbox to minimize MAPE against empirical data
clear; clc;

% Setup
project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

% Load empirical data
csv_path = fullfile(project_root, 'F404_GE400_TM4140_net_thrust.csv');
empirical = readtable(csv_path);
empirical = empirical(~isnan(empirical.alt_ft), :);

fprintf('=== Automated Correction Factor Optimization ===\n');
fprintf('Empirical data points: %d\n\n', height(empirical));

% Define optimization parameters:
% x = [Tt4_idle, Tt4_MIL,
%      thrust_scale_dry_pla(1:5), thrust_scale_ab_pla(1:4),
%      alt_corr(1:5), mach_corr(1:5),
%      mdot_pla_scale(1:5)]
% Total: 2 + 5 + 4 + 5 + 5 + 5 = 26 parameters

% Initial guess (current values)
x0 = [
    1350;  % Tt4_idle
    1600;  % Tt4_MIL
    3.00; 2.50; 2.00; 1.50; 1.30;  % thrust_scale_dry_pla_vals
    1.30; 1.35; 1.40; 1.45;        % thrust_scale_ab_pla_vals
    1.00; 1.00; 1.10; 1.00; 0.50;  % alt_thrust_corr_vals
    0.65; 1.00; 1.15; 1.30; 0.95;  % mach_thrust_corr_vals
    0.85; 0.90; 0.95; 0.98; 1.00   % mdot_pla_scale
];

% Bounds
lb = [
    900;   % Tt4_idle min
    1400;  % Tt4_MIL min
    0.5; 0.5; 0.5; 0.5; 0.5;   % thrust_scale_dry_pla_vals min
    0.5; 0.5; 0.5; 0.5;         % thrust_scale_ab_pla_vals min
    0.3; 0.3; 0.3; 0.3; 0.3;    % alt_thrust_corr_vals min
    0.3; 0.3; 0.3; 0.3; 0.3;    % mach_thrust_corr_vals min
    0.50; 0.50; 0.50; 0.50; 0.50  % mdot_pla_scale min
];

ub = [
    1500;  % Tt4_idle max
    1700;  % Tt4_MIL max
    5.0; 5.0; 5.0; 5.0; 5.0;    % thrust_scale_dry_pla_vals max
    3.0; 3.0; 3.0; 3.0;          % thrust_scale_ab_pla_vals max
    2.0; 2.0; 2.0; 2.0; 2.0;     % alt_thrust_corr_vals max
    2.0; 2.0; 2.0; 2.0; 2.0;     % mach_thrust_corr_vals max
    1.00; 1.00; 1.00; 1.00; 1.00   % mdot_pla_scale max
];

% Optimization options
options = optimoptions('fmincon', ...
    'Display', 'iter', ...
    'MaxIterations', 100, ...
    'MaxFunctionEvaluations', 5000, ...
    'OptimalityTolerance', 1e-4, ...
    'StepTolerance', 1e-6, ...
    'Algorithm', 'sqp');

fprintf('Starting optimization...\n');
fprintf('Initial MAPE: %.2f%%\n\n', objective_function(x0, empirical));

% Run optimization
tic;
[x_opt, fval, exitflag, output] = fmincon(@(x) objective_function(x, empirical), ...
    x0, [], [], [], [], lb, ub, [], options);
opt_time = toc;

fprintf('\n=== Optimization Complete ===\n');
fprintf('Exit flag: %d\n', exitflag);
fprintf('Iterations: %d\n', output.iterations);
fprintf('Function evaluations: %d\n', output.funcCount);
fprintf('Time elapsed: %.1f seconds\n', opt_time);
fprintf('Final MAPE: %.2f%%\n\n', fval);

% Extract optimized parameters
Tt4_idle_opt = x_opt(1);
Tt4_MIL_opt = x_opt(2);
thrust_dry_pla_opt = x_opt(3:7);
thrust_ab_pla_opt = x_opt(8:11);
alt_corr_opt = x_opt(12:16);
mach_corr_opt = x_opt(17:21);
mdot_pla_opt = x_opt(22:26);

% Display optimized values
fprintf('=== Optimized Parameters ===\n\n');
fprintf('Temperature Schedule:\n');
fprintf('  Tt4_idle: %.1f K (was %.1f K)\n', Tt4_idle_opt, x0(1));
fprintf('  Tt4_MIL:  %.1f K (was %.1f K)\n', Tt4_MIL_opt, x0(2));

fprintf('\nDry Thrust PLA Scaling [0.30, 0.55, 0.70, 0.87, 1.00]:\n');
fprintf('  [%.2f, %.2f, %.2f, %.2f, %.2f]\n', thrust_dry_pla_opt);

fprintf('\nAB Thrust PLA Scaling [0.87, 1.00, 1.15, 1.30]:\n');
fprintf('  [%.2f, %.2f, %.2f, %.2f]\n', thrust_ab_pla_opt);

fprintf('\nAltitude Corrections [0, 10k, 20k, 30k, 40k ft]:\n');
fprintf('  [%.2f, %.2f, %.2f, %.2f, %.2f]\n', alt_corr_opt);

fprintf('\nMach Corrections [0.4, 0.8, 0.9, 1.2, 1.6]:\n');
fprintf('  [%.2f, %.2f, %.2f, %.2f, %.2f]\n', mach_corr_opt);

fprintf('\nMass Flow PLA Scaling [0.30, 0.50, 0.70, 0.87, 1.00]:\n');
fprintf('  [%.2f, %.2f, %.2f, %.2f, %.2f]\n', mdot_pla_opt);

% Generate MATLAB code to paste into inputs_F404_defaults.m
fprintf('\n=== MATLAB Code (paste into inputs_F404_defaults.m) ===\n');
fprintf('params.Tt4_idle = %.1f;  %% Optimized\n', Tt4_idle_opt);
fprintf('params.Tt4_MIL  = %.1f;  %% Optimized\n', Tt4_MIL_opt);
fprintf('params.thrust_scale_dry_pla_vals = [%.2f %.2f %.2f %.2f %.2f];  %% Optimized\n', thrust_dry_pla_opt);
fprintf('params.thrust_scale_ab_pla_vals  = [%.2f %.2f %.2f %.2f];  %% Optimized\n', thrust_ab_pla_opt);
fprintf('params.alt_thrust_corr_vals = [%.2f %.2f %.2f %.2f %.2f];  %% Optimized\n', alt_corr_opt);
fprintf('params.mach_thrust_corr_vals = [%.2f %.2f %.2f %.2f %.2f];  %% Optimized\n', mach_corr_opt);
fprintf('params.mdot_pla_scale = [%.2f %.2f %.2f %.2f %.2f];  %% Optimized\n', mdot_pla_opt);

% Run final validation with optimized parameters
fprintf('\n=== Running final validation ===\n');
[mape, errors_by_condition] = run_validation(x_opt, empirical);
fprintf('Overall MAPE: %.2f%%\n\n', mape);

fprintf('Error by condition:\n');
for i = 1:size(errors_by_condition, 1)
    fprintf('  %s: %.2f%%\n', errors_by_condition{i,1}, errors_by_condition{i,2});
end

fprintf('\n=== Optimization Complete ===\n');

%% Objective Function
function mape = objective_function(x, empirical)
    % Compute MAPE for given parameters
    cfg = config_model();
    in = inputs_F404_defaults(cfg);

    % Update parameters
    in.params.Tt4_idle = x(1);
    in.params.Tt4_MIL  = x(2);
    in.params.Tt4_dry_table = [x(1) 1450 1550 1625 1650];  % Update table with new idle temp
    in.params.thrust_scale_dry_pla_vals = x(3:7)';
    in.params.thrust_scale_ab_pla_vals  = x(8:11)';
    in.params.alt_thrust_corr_vals = x(12:16)';
    in.params.mach_thrust_corr_vals = x(17:21)';
    in.params.mdot_pla_scale = x(22:26)';

    % Run model for all points
    N = height(empirical);
    model_thrust = zeros(N, 1);

    for i = 1:N
        alt_ft = empirical.alt_ft(i);
        M0 = empirical.Mach(i);
        PLA_deg = empirical.PLA_deg(i);

        % Convert PLA
        PLA_breakpoints = [0, 70, 87, 109, 130];
        nondim_values   = [0, 0.30, 0.87, 1.09, 1.30];
        PLA = interp1(PLA_breakpoints, nondim_values, PLA_deg, 'linear', 'extrap');

        % AB detection
        AB_fuel = empirical.afterburnerFuelFlow_Lbm_s(i);
        AB = double(AB_fuel > 0.01);

        % Atmosphere
        alt_m = alt_ft * 0.3048;
        [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);
        rho0 = p0 / (287.0 * T0);

        % Run cycle
        op = struct();
        op.params = in.params;
        op.atm = struct('T0', T0, 'p0', p0, 'rho0', rho0);
        op.M0 = M0;
        op.alt = alt_m;
        op.PLA = PLA;
        op.AB = AB;

        try
            cycle = solve_cycle(cfg, op);
            model_thrust(i) = cycle.Thrust;
        catch
            model_thrust(i) = NaN;
        end
    end

    % Compute MAPE
    empirical_thrust = empirical.net_thrust_N;
    valid = ~isnan(model_thrust) & ~isnan(empirical_thrust);
    errors = abs(model_thrust(valid) - empirical_thrust(valid)) ./ empirical_thrust(valid);
    mape = mean(errors) * 100;
end

%% Validation Function
function [mape, errors_by_condition] = run_validation(x, empirical)
    cfg = config_model();
    in = inputs_F404_defaults(cfg);

    % Update parameters
    in.params.Tt4_idle = x(1);
    in.params.Tt4_MIL  = x(2);
    in.params.Tt4_dry_table = [x(1) 1450 1550 1625 1650];
    in.params.thrust_scale_dry_pla_vals = x(3:7)';
    in.params.thrust_scale_ab_pla_vals  = x(8:11)';
    in.params.alt_thrust_corr_vals = x(12:16)';
    in.params.mach_thrust_corr_vals = x(17:21)';
    in.params.mdot_pla_scale = x(22:26)';

    % Run model
    N = height(empirical);
    model_thrust = zeros(N, 1);

    for i = 1:N
        alt_ft = empirical.alt_ft(i);
        M0 = empirical.Mach(i);
        PLA_deg = empirical.PLA_deg(i);

        PLA_breakpoints = [0, 70, 87, 109, 130];
        nondim_values   = [0, 0.30, 0.87, 1.09, 1.30];
        PLA = interp1(PLA_breakpoints, nondim_values, PLA_deg, 'linear', 'extrap');

        AB_fuel = empirical.afterburnerFuelFlow_Lbm_s(i);
        AB = double(AB_fuel > 0.01);

        alt_m = alt_ft * 0.3048;
        [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);
        rho0 = p0 / (287.0 * T0);

        op = struct();
        op.params = in.params;
        op.atm = struct('T0', T0, 'p0', p0, 'rho0', rho0);
        op.M0 = M0;
        op.alt = alt_m;
        op.PLA = PLA;
        op.AB = AB;

        try
            cycle = solve_cycle(cfg, op);
            model_thrust(i) = cycle.Thrust;
        catch
            model_thrust(i) = NaN;
        end
    end

    % Overall MAPE
    empirical_thrust = empirical.net_thrust_N;
    valid = ~isnan(model_thrust) & ~isnan(empirical_thrust);
    errors = abs(model_thrust(valid) - empirical_thrust(valid)) ./ empirical_thrust(valid);
    mape = mean(errors) * 100;

    % Errors by condition
    alts = unique(empirical.alt_ft);
    machs = unique(empirical.Mach);
    errors_by_condition = cell(0, 2);

    for a = 1:numel(alts)
        for m = 1:numel(machs)
            idx = valid & empirical.alt_ft == alts(a) & empirical.Mach == machs(m);
            if sum(idx) > 0
                err = mean(abs(model_thrust(idx) - empirical_thrust(idx)) ./ empirical_thrust(idx)) * 100;
                condition_name = sprintf('Alt=%5.0f ft, M=%.1f', alts(a), machs(m));
                errors_by_condition{end+1, 1} = condition_name;
                errors_by_condition{end, 2} = err;
            end
        end
    end
end
