% SWEEP_ALTITUDE_MACH Comprehensive altitude and Mach number sweep
% Validates F404-GE-400 performance across operational envelope

clear; clc; close all;

project_root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(genpath(fullfile(project_root, 'engine_model')));

fprintf('=== F404-GE-400 Altitude/Mach Performance Sweep ===\n\n');

% Define sweep ranges (F404 operational envelope)
altitudes_ft = [0, 10000, 20000, 30000, 40000, 50000];  % Sea level to 50k ft
altitudes_m = altitudes_ft * 0.3048;

machs = [0.0, 0.4, 0.6, 0.8, 0.9, 1.0, 1.2, 1.4, 1.6];  % Subsonic to supersonic

% Power settings
PLA_settings = [0.30, 0.87, 1.00, 1.30];  % Idle, Intermediate, MIL, MAX AB
PLA_names = {'Idle', 'Intermediate', 'MIL (Dry)', 'MAX AB'};
AB_settings = [0, 0, 0, 1];  % AB only at MAX

cfg = config_model();
in = inputs_F404_defaults(cfg);

n_alt = length(altitudes_ft);
n_mach = length(machs);
n_pla = length(PLA_settings);

% Storage arrays
thrust = zeros(n_alt, n_mach, n_pla);
tsfc = zeros(n_alt, n_mach, n_pla);
converged = true(n_alt, n_mach, n_pla);

fprintf('Running %d test points...\n', n_alt * n_mach * n_pla);
tic;

for ip = 1:n_pla
    PLA = PLA_settings(ip);
    AB = AB_settings(ip);
    fprintf('\n%s (PLA=%.2f, AB=%.0f):\n', PLA_names{ip}, PLA, AB);

    for ia = 1:n_alt
        alt_m = altitudes_m(ia);
        alt_ft = altitudes_ft(ia);

        for im = 1:n_mach
            M0 = machs(im);

            % Get atmospheric conditions
            [~, ~, ~, ~, ~, ~, ~, ~, p0, T0] = standard_atmosphere(alt_m);
            rho0 = p0 / (287.0 * T0);

            % Setup operating point
            op = struct();
            op.params = in.params;
            op.atm = struct('T0', T0, 'p0', p0, 'rho0', rho0);
            op.M0 = M0;
            op.alt = alt_m;
            op.PLA = PLA;
            op.AB = AB;

            % Run cycle
            try
                cycle = solve_cycle(cfg, op);
                thrust(ia, im, ip) = cycle.Thrust;
                tsfc(ia, im, ip) = cycle.TSFC;
            catch ME
                warning('Failed at Alt=%d ft, M=%.1f: %s', alt_ft, M0, ME.message);
                thrust(ia, im, ip) = NaN;
                tsfc(ia, im, ip) = NaN;
                converged(ia, im, ip) = false;
            end
        end

        fprintf('  %5d ft: ', alt_ft);
        fprintf('%6.1f ', thrust(ia, :, ip)/1000);
        fprintf('kN\n');
    end
end

elapsed = toc;
fprintf('\nCompleted in %.1f seconds (%.0f converged)\n', elapsed, sum(converged(:)));

%% Compare against F404-GE-400 specifications
fprintf('\n=== F404-GE-400 Performance Validation ===\n\n');

% Known F404-GE-400 performance (from GE specs and NASA TM-4140)
fprintf('Sea Level Static (M=0.0):\n');
fprintf('  Model Idle:   %.1f kN (Expected: ~10 kN)\n', thrust(1,1,1)/1000);
fprintf('  Model MIL:    %.1f kN (Expected: 40-50 kN)\n', thrust(1,1,3)/1000);
fprintf('  Model MAX AB: %.1f kN (Expected: ~75 kN)\n', thrust(1,1,4)/1000);

fprintf('\n10,000 ft, M=0.8:\n');
fprintf('  Model MIL:    %.1f kN (Expected: 32-35 kN)\n', thrust(2,4,3)/1000);
fprintf('  Model MAX AB: %.1f kN (Expected: 55-62 kN)\n', thrust(2,4,4)/1000);

fprintf('\n30,000 ft, M=0.9:\n');
fprintf('  Model MIL:    %.1f kN (Expected: 18-22 kN)\n', thrust(4,5,3)/1000);
fprintf('  Model MAX AB: %.1f kN (Expected: 32-36 kN)\n', thrust(4,5,4)/1000);

fprintf('\n40,000 ft, M=1.6:\n');
fprintf('  Model MIL:    %.1f kN (Expected: 15-20 kN)\n', thrust(5,9,3)/1000);
fprintf('  Model MAX AB: %.1f kN (Expected: 35-43 kN)\n', thrust(5,9,4)/1000);

%% Generate performance plots
output_dir = fullfile(project_root, 'engine_model', 'data', 'sweep_results');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

% Plot 1: Thrust vs Mach at different altitudes (MIL power)
figure('Position', [100, 100, 1000, 600]);
colors = lines(n_alt);
for ia = 1:n_alt
    plot(machs, thrust(ia, :, 3)/1000, '-o', 'LineWidth', 2, ...
        'Color', colors(ia,:), 'DisplayName', sprintf('%d ft', altitudes_ft(ia)));
    hold on;
end
xlabel('Mach Number', 'FontSize', 12);
ylabel('Thrust (kN)', 'FontSize', 12);
title('F404-GE-400 Dry Thrust (MIL Power) vs Mach', 'FontSize', 14);
legend('Location', 'best');
grid on;
saveas(gcf, fullfile(output_dir, 'thrust_vs_mach_dry.png'));
fprintf('\nSaved: thrust_vs_mach_dry.png\n');

% Plot 2: Thrust vs Mach at different altitudes (MAX AB)
figure('Position', [100, 100, 1000, 600]);
for ia = 1:n_alt
    plot(machs, thrust(ia, :, 4)/1000, '-s', 'LineWidth', 2, ...
        'Color', colors(ia,:), 'DisplayName', sprintf('%d ft', altitudes_ft(ia)));
    hold on;
end
xlabel('Mach Number', 'FontSize', 12);
ylabel('Thrust (kN)', 'FontSize', 12);
title('F404-GE-400 Afterburning Thrust (MAX AB) vs Mach', 'FontSize', 14);
legend('Location', 'best');
grid on;
saveas(gcf, fullfile(output_dir, 'thrust_vs_mach_ab.png'));
fprintf('Saved: thrust_vs_mach_ab.png\n');

% Plot 3: Thrust vs Altitude at different Mach numbers (MIL)
figure('Position', [100, 100, 1000, 600]);
mach_indices = [1, 4, 5, 7, 9];  % M=0, 0.8, 0.9, 1.2, 1.6
mach_labels = {'M=0.0', 'M=0.8', 'M=0.9', 'M=1.2', 'M=1.6'};
for i = 1:length(mach_indices)
    im = mach_indices(i);
    plot(altitudes_ft, thrust(:, im, 3)/1000, '-o', 'LineWidth', 2, ...
        'DisplayName', mach_labels{i});
    hold on;
end
xlabel('Altitude (ft)', 'FontSize', 12);
ylabel('Thrust (kN)', 'FontSize', 12);
title('F404-GE-400 Dry Thrust (MIL) vs Altitude', 'FontSize', 14);
legend('Location', 'best');
grid on;
saveas(gcf, fullfile(output_dir, 'thrust_vs_altitude_dry.png'));
fprintf('Saved: thrust_vs_altitude_dry.png\n');

% Plot 4: Thrust vs Altitude at different Mach numbers (MAX AB)
figure('Position', [100, 100, 1000, 600]);
for i = 1:length(mach_indices)
    im = mach_indices(i);
    plot(altitudes_ft, thrust(:, im, 4)/1000, '-s', 'LineWidth', 2, ...
        'DisplayName', mach_labels{i});
    hold on;
end
xlabel('Altitude (ft)', 'FontSize', 12);
ylabel('Thrust (kN)', 'FontSize', 12);
title('F404-GE-400 Afterburning Thrust (MAX AB) vs Altitude', 'FontSize', 14);
legend('Location', 'best');
grid on;
saveas(gcf, fullfile(output_dir, 'thrust_vs_altitude_ab.png'));
fprintf('Saved: thrust_vs_altitude_ab.png\n');

% Plot 5: TSFC vs Mach (MIL power)
figure('Position', [100, 100, 1000, 600]);
for ia = 1:n_alt
    plot(machs, tsfc(ia, :, 3)*1e5, '-o', 'LineWidth', 2, ...
        'Color', colors(ia,:), 'DisplayName', sprintf('%d ft', altitudes_ft(ia)));
    hold on;
end
xlabel('Mach Number', 'FontSize', 12);
ylabel('TSFC (×10^{-5} kg/N/s)', 'FontSize', 12);
title('F404-GE-400 TSFC (MIL Power) vs Mach', 'FontSize', 14);
legend('Location', 'best');
grid on;
saveas(gcf, fullfile(output_dir, 'tsfc_vs_mach_dry.png'));
fprintf('Saved: tsfc_vs_mach_dry.png\n');

% Plot 6: 3D surface plot - Dry thrust
figure('Position', [100, 100, 1000, 700]);
[M_grid, Alt_grid] = meshgrid(machs, altitudes_ft);
surf(M_grid, Alt_grid, thrust(:,:,3)/1000);
xlabel('Mach Number', 'FontSize', 12);
ylabel('Altitude (ft)', 'FontSize', 12);
zlabel('Thrust (kN)', 'FontSize', 12);
title('F404-GE-400 Dry Thrust Surface (MIL Power)', 'FontSize', 14);
colorbar;
view(45, 30);
shading interp;
saveas(gcf, fullfile(output_dir, 'thrust_surface_dry.png'));
fprintf('Saved: thrust_surface_dry.png\n');

% Plot 7: 3D surface plot - AB thrust
figure('Position', [100, 100, 1000, 700]);
surf(M_grid, Alt_grid, thrust(:,:,4)/1000);
xlabel('Mach Number', 'FontSize', 12);
ylabel('Altitude (ft)', 'FontSize', 12);
zlabel('Thrust (kN)', 'FontSize', 12);
title('F404-GE-400 Afterburning Thrust Surface (MAX AB)', 'FontSize', 14);
colorbar;
view(45, 30);
shading interp;
saveas(gcf, fullfile(output_dir, 'thrust_surface_ab.png'));
fprintf('Saved: thrust_surface_ab.png\n');

%% Save data to CSV
results_table = table();
for ip = 1:n_pla
    for ia = 1:n_alt
        for im = 1:n_mach
            row = table();
            row.PowerSetting = {PLA_names{ip}};
            row.PLA = PLA_settings(ip);
            row.AB = AB_settings(ip);
            row.Altitude_ft = altitudes_ft(ia);
            row.Mach = machs(im);
            row.Thrust_N = thrust(ia, im, ip);
            row.Thrust_kN = thrust(ia, im, ip) / 1000;
            row.TSFC_kg_per_N_s = tsfc(ia, im, ip);
            row.Converged = converged(ia, im, ip);
            results_table = [results_table; row];
        end
    end
end

csv_file = fullfile(output_dir, 'f404_sweep_results.csv');
writetable(results_table, csv_file);
fprintf('Saved: f404_sweep_results.csv\n');

fprintf('\n=== Sweep Complete ===\n');
fprintf('Results saved to: %s\n', output_dir);
