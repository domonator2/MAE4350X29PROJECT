function aug = augmentor_model(cfg, inlet)
%AUGMENTOR_MODEL Simple temperature-rise model for an afterburner/augmentor.
%   Adds heat after the turbine using a commanded temperature rise and
%   burner efficiency, while applying a duct pressure loss.

const = cfg.const;
cp_ref = getfieldwithdefault(const,'cp', 1004.5);
LHV    = getfieldwithdefault(const,'LHV', 43e6);

Tt5 = getfieldwithdefault(inlet,'Tt5', NaN);
Pt5 = getfieldwithdefault(inlet,'Pt5', NaN);
mdot_core = getfieldwithdefault(inlet,'mdot_core', NaN);
AB_cmd = getfieldwithdefault(inlet,'AB', 0.0);
params = getfieldwithdefault(inlet,'params', struct());

AB_cmd = max(min(AB_cmd, 1.0), 0.0);
dTt_ab_max = getfieldwithdefault(params,'dTt_ab_max', 0.0);
dTt_ab_cmd = AB_cmd * max(dTt_ab_max, 0.0);
Tt9 = Tt5 + dTt_ab_cmd;

T_avg = 0.5 * (Tt5 + Tt9);
cp_hot = cp_ref * (1.0 + 0.15 * ((T_avg - 288.15)/1000));
cp_hot = max(cp_ref, cp_hot);

eta_ab = getfieldwithdefault(params,'eta_burner_ab', 0.85);
eta_ab = max(min(eta_ab, 1.0), 0.4);

mdot_fuel_ab = mdot_core * cp_hot * dTt_ab_cmd / max(eta_ab * LHV, 1e-6);
if isnan(mdot_core)
    mdot_fuel_ab = NaN;
end

p_drop_ab = getfieldwithdefault(params,'p_drop_ab', 0.05);
p_drop_ab = max(min(p_drop_ab, 0.2), 0.0);
Pt9 = Pt5 * (1 - p_drop_ab);

aug = struct();
aug.Tt9 = Tt9;
aug.Pt9 = Pt9;
aug.mdot_fuel_ab = mdot_fuel_ab;
aug.dTt_ab_cmd = dTt_ab_cmd;
aug.cp_hot = cp_hot;
aug.eta_ab = eta_ab;
end

function val = getfieldwithdefault(s, name, default)
if isstruct(s) && isfield(s, name)
    val = s.(name);
else
    val = default;
end
end
