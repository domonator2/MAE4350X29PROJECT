function beta_BL = inlet_blockage_factor(M0, alpha)
%INLET_BLOCKAGE_FACTOR   Boundary-layer / distortion blockage fraction.
%
% Inputs:
%   M0    : freestream Mach number
%   alpha : angle of attack [deg] (optional, can be empty)
%
% Output:
%   beta_BL : fractional blockage (0..0.15 typically).
%             Effective mdot_capture = mdot_ideal * (1 - beta_BL).
%
% Notes:
%   - This is a simple heuristic model; tune breakpoints using F404 data.
%   - For a clean F/A-18-type inlet, 2–6% blockage over most of the
%     subsonic/transonic envelope is reasonable; higher at extreme AoA/M.

    if nargin < 2 || isempty(alpha)
        alpha = 0;
    end

    % Clamp inputs
    M0    = max(0.0, min(2.0, M0));
    alpha = max(-20.0, min(20.0, alpha));

    % --- Mach-based component ---
    % Baseline blockage vs Mach (no AoA):
    % M = 0.0   -> 1% loss
    % M = 0.9   -> 3% loss
    % M = 1.6   -> 6% loss
    M_grid   = [0.0  0.3  0.6  0.9  1.2  1.6  2.0];
    beta_M   = [0.01 0.015 0.02 0.03 0.04 0.06 0.07];
    beta_M0  = interp1(M_grid, beta_M, M0, 'linear', 'extrap');

    % --- AoA-based component ---
    % Extra blockage at higher alpha (symmetric for +/- alpha).
    alpha_abs = abs(alpha);
    a_grid    = [0   5   10  15  20];
    beta_a    = [0   0.005 0.01 0.02 0.03];   % +0–3% for extreme AoA
    beta_alpha = interp1(a_grid, beta_a, alpha_abs, 'linear', 'extrap');

    % Combine, but cap to something sane
    beta_BL = beta_M0 + beta_alpha;
    beta_BL = min(max(beta_BL, 0.0), 0.15);   % 0–15% cap
end
