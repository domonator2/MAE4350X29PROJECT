function geom = resolve_nozzle_geometry(PLA, AB, params)
%RESOLVE_NOZZLE_GEOMETRY  Returns nozzle throat/exit areas and type.
%
% Inputs:
%   PLA    : power lever angle, nondimensional [0..1.3]
%   AB     : afterburner command [0..1]
%   params : struct with nominal areas, e.g.
%              A8_idle
%              A8_MIL
%              A8_AB
%              A9_idle
%              A9_MIL
%              A9_AB
%              nozzle_type_dry  ('convergent' or 'convergent-divergent')
%              nozzle_type_AB   ('convergent' or 'convergent-divergent')
%
% Output:
%   geom : struct with
%            A8          : throat area [m^2]
%            A9          : exit area   [m^2]
%            nozzle_type : string

    % Clamp inputs
    PLA = max(0.0, min(1.3, PLA));
    AB  = max(0.0, min(1.0, AB));

    % Defaults (replace with TM-88273-derived values when available)
    if nargin < 3 || isempty(params)
        params = struct();
    end

    % NOTE: These are illustrative placeholders.
    % When available, these should come from TM-88273 / GE test data.
    % For now, use input parameters as primary source (backward compatibility).
    
    % Check if params has any explicit area definitions (from old system)
    if isfield(params,'A8_idle') && ~isempty(params.A8_idle)
        % Use params if they exist (old-style, for backward compatibility)
        A8_idle = params.A8_idle;
        A8_MIL  = getfield_opt(params,'A8_dry', getfield_opt(params, 'A8_MIL', params.A8_idle * 1.133));
        A8_AB   = getfield_opt(params,'A8_ab',  A8_MIL * 1.176);
        A9_idle = params.A9_idle;
        A9_MIL  = getfield_opt(params,'A9_dry', getfield_opt(params, 'A9_MIL', params.A9_idle * 1.125));
        A9_AB   = getfield_opt(params,'A9_ab',  A9_MIL * 1.333);
    else
        % Use new defaults (TM-88273 placeholders, to be tuned)
        A8_idle = getfield_opt(params,'A8_idle', 0.015);  % m^2
        A8_MIL  = getfield_opt(params,'A8_MIL',  0.017);  % m^2
        A8_AB   = getfield_opt(params,'A8_AB',   0.020);  % m^2
        A9_idle = getfield_opt(params,'A9_idle', 0.016);  % m^2
        A9_MIL  = getfield_opt(params,'A9_MIL',  0.018);  % m^2
        A9_AB   = getfield_opt(params,'A9_AB',   0.024);  % m^2
    end

    nozzle_type_dry = getfield_opt(params,'nozzle_type_dry','convergent');
    nozzle_type_AB  = getfield_opt(params,'nozzle_type_AB', 'convergent-divergent');

    % PLA breakpoints
    PLA_idle = 0.30;
    PLA_MIL  = 1.00;
    PLA_MAX  = 1.30;

    % ---- Dry schedule (AB=0) ----
    if PLA <= PLA_idle
        A8_dry = A8_idle;
        A9_dry = A9_idle;
    elseif PLA < PLA_MIL
        xi = (PLA - PLA_idle) / (PLA_MIL - PLA_idle);
        A8_dry = A8_idle + xi * (A8_MIL - A8_idle);
        A9_dry = A9_idle + xi * (A9_MIL - A9_idle);
    else
        A8_dry = A8_MIL;
        A9_dry = A9_MIL;
    end

    % ---- AB schedule (AB=1) ----
    if PLA <= PLA_MIL
        A8_ab = A8_MIL;
        A9_ab = A9_MIL;
    elseif PLA < PLA_MAX
        xi = (PLA - PLA_MIL) / (PLA_MAX - PLA_MIL);
        A8_ab = A8_MIL + xi * (A8_AB - A8_MIL);
        A9_ab = A9_MIL + xi * (A9_AB - A9_MIL);
    else
        A8_ab = A8_AB;
        A9_ab = A9_AB;
    end

    % ---- Blend dry/AB with AB command ----
    A8 = (1 - AB) * A8_dry + AB * A8_ab;
    A9 = (1 - AB) * A9_dry + AB * A9_ab;

    % Nozzle type: dry vs AB
    if AB < 0.5
        nozzle_type = nozzle_type_dry;
    else
        nozzle_type = nozzle_type_AB;
    end

    % Output struct
    geom = struct();
    geom.A8          = A8;
    geom.A9          = A9;
    geom.nozzle_type = nozzle_type;
end

function val = getfield_opt(s, name, default)
    if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
        val = s.(name);
    else
        val = default;
    end
end
