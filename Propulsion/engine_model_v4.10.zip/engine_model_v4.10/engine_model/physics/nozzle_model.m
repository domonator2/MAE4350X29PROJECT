function nozzle = nozzle_model(Pt_in, Tt_in, mdot_in, atm, params, const)
%NOZZLE_MODEL Variable-area convergent / convergent-divergent nozzle with full isentropic physics.
%
% Inputs:
%   Pt_in, Tt_in : total conditions at nozzle inlet (station 9)  [Pa, K]
%   mdot_in      : mass flow through nozzle                      [kg/s]
%   atm          : struct with fields:
%                    p0  : ambient static pressure               [Pa]
%                    T0  : ambient static temperature            [K]
%                    M0  : freestream Mach number                [-]
%   params       : struct with fields:
%                    A_nozzle      : throat area A8              [m^2]
%                    A_nozzle_exit : exit area A9                [m^2]
%                    Cd_noz        : discharge coefficient       [-]
%                    nozzle_type   : 'convergent' or 'convergent-divergent'
%   const        : struct with thermodynamic constants:
%                    R        : gas constant                     [J/(kg·K)]
%                    gamma    : ratio of specific heats (cold)
%                    gamma_hot: (optional) gamma for hot gas
%
% Outputs:
%   nozzle : struct with fields
%              Me            : exit Mach number
%              Te, Pe, rho_e : exit static T, p, rho
%              Ve            : exit velocity                     [m/s]
%              mdot          : mass flow used in thrust          [kg/s]
%              mdot_geom     : geometric capacity
%              mdot_total_in : commanded total mdot              [kg/s]
%              Fg            : gross thrust (momentum + pressure thrust) [N]
%              A_nozzle      : exit area used                    [m^2]
%              Cd_noz        : discharge coefficient used        [-]
%
% Physics:
%   - Full isentropic relations with NPR_crit logic
%   - Supports convergent and C-D nozzles with supersonic exit
%   - Gross thrust = mdot*(Ve - V0) + (Pe - p0)*Ae
%   - Properly distinguishes unchoked vs choked (sonic throat) flow

% ---------------------------
%  Extract constants
% ---------------------------
if isstruct(const) && isfield(const, 'const')
    const = const.const;
end

Rgas = getfield_opt(const, 'R', 287.0);

% Use hot-gas gamma if provided; otherwise default
if isfield(const, 'gamma_hot') && ~isempty(const.gamma_hot)
    gamma = const.gamma_hot;
else
    gamma = getfield_opt(const, 'gamma', 1.4);
end

% Ambient / freestream conditions
p0 = getfield_opt(atm, 'p0', 101325.0);
T0 = getfield_opt(atm, 'T0', 288.15);
M0 = getfield_opt(atm, 'M0', 0.0);

a0 = sqrt(gamma * Rgas * T0);
V0 = M0 * a0;  % flight speed for ram drag term

% Nozzle geometry & discharge coefficient
A8  = getfield_opt(params, 'A_nozzle',       0.05);  % throat
A9  = getfield_opt(params, 'A_nozzle_exit',  A8);    % exit
Cd  = getfield_opt(params, 'Cd_noz',         0.98);
type = getfield_opt(params, 'nozzle_type',   'convergent');

% Guard against nonsensical inputs
Pt_in = max(Pt_in, 1.0);
Tt_in = max(Tt_in, 1.0);
p0    = max(p0,    1.0);
A8    = max(A8,    1e-9);
A9    = max(A9,    1e-9);

% Effective total pressure accounting for losses
Pt_eff = Pt_in * Cd;

% ---------------------------
%  Critical pressure ratio
% ---------------------------
% NPR_crit = (Pt/P_s)_M=1 = ((gamma+1)/2)^(gamma/(gamma-1))
NPR_crit = ( (gamma + 1) / 2 )^( gamma / (gamma - 1) );
NPR      = Pt_eff / p0;

% Specific heat and related quantities
cp = gamma * Rgas / (gamma - 1);

% Initialize output struct
nozzle = struct();
nozzle.A_nozzle      = A9;
nozzle.Cd_noz        = Cd;
nozzle.mdot_total_in = mdot_in;
nozzle.mdot_geom     = mdot_in;
nozzle.mdot          = mdot_in;

% Short-circuit: no pressure ratio available
if NPR <= 1.001
    Me    = M0;
    Te    = T0;
    Pe    = p0;
    rho_e = Pe / (Rgas * Te);
    Ve    = M0 * sqrt(gamma * Rgas * Te);
    Ae    = A9;
    Fg    = mdot_in * (Ve - V0) + (Pe - p0) * Ae;
else
    % ---------------------------------------------------------
    %  CONVERGENT NOZZLE (exit at throat)
    % ---------------------------------------------------------
    if strcmpi(type, 'convergent') || A9 <= A8*(1 + 1e-3)
        Ae = A8;
        
        if NPR < NPR_crit
            % Unchoked: subsonic exit, Pe ~ p0
            Me = solve_m_from_pressure_ratio(NPR, gamma, 'sub');
        else
            % Choked at throat: M = 1.0
            Me = 1.0;
        end
        
        % Isentropic relations
        T_ratio = 1 + 0.5*(gamma - 1) * Me^2;
        Te      = Tt_in / T_ratio;
        Pe      = Pt_eff / T_ratio^(gamma/(gamma-1));
        rho_e   = Pe / (Rgas * Te);
        Ve      = sqrt(2 * cp * (Tt_in - Te));
        
    else
        % ---------------------------------------------------------
        %  CONVERGENT-DIVERGENT NOZZLE
        % ---------------------------------------------------------
        AR = A9 / A8;  % Area ratio Ae/At
        Ae = A9;
        
        if NPR < NPR_crit
            % Not choked: subsonic throughout
            Me = solve_m_from_pressure_ratio(NPR, gamma, 'sub');
            T_ratio = 1 + 0.5*(gamma - 1) * Me^2;
            Te      = Tt_in / T_ratio;
            Pe      = Pt_eff / T_ratio^(gamma/(gamma-1));
            rho_e   = Pe / (Rgas * Te);
            Ve      = sqrt(2 * cp * (Tt_in - Te));
        else
            % Choked at throat; exit can be supersonic if AR > 1
            if abs(AR - 1.0) < 1e-3
                % No divergent section
                Me = 1.0;
                T_ratio = 1 + 0.5*(gamma - 1) * Me^2;
                Te      = Tt_in / T_ratio;
                Pe      = Pt_eff / T_ratio^(gamma/(gamma-1));
                rho_e   = Pe / (Rgas * Te);
                Ve      = sqrt(2 * cp * (Tt_in - Te));
            else
                % Supersonic exit expansion
                Me = solve_m_from_area_ratio(AR, gamma, 'sup');
                T_ratio = 1 + 0.5*(gamma - 1) * Me^2;
                Te      = Tt_in / T_ratio;
                Pe      = Pt_eff / T_ratio^(gamma/(gamma-1));
                rho_e   = Pe / (Rgas * Te);
                Ve      = sqrt(2 * cp * (Tt_in - Te));
            end
        end
    end
    
    % Gross thrust: momentum + pressure thrust
    Fg = mdot_in * (Ve - V0) + (Pe - p0) * Ae;
end

% ---------------------------
%  Populate output
% ---------------------------
nozzle.Me    = Me;
nozzle.Te    = Te;
nozzle.Pe    = Pe;
nozzle.rho_e = rho_e;
nozzle.Ve    = Ve;
nozzle.Fg    = Fg;

end

% ========================================================================
%  Helper functions
% ========================================================================

function val = getfield_opt(s, name, default)
%GETFIELD_OPT Safe field extraction with default fallback.
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    val = s.(name);
else
    val = default;
end
end

function M = solve_m_from_pressure_ratio(NPR, gamma, branch)
%SOLVE_M_FROM_PRESSURE_RATIO Solve Pt/P = NPR for Mach number.
%   Pt/P = (1 + 0.5*(gamma-1)*M^2)^(gamma/(gamma-1))
%   branch = 'sub' (subsonic) or 'sup' (supersonic)

NPR = max(NPR, 1.0);

f = @(M) (1 + 0.5*(gamma-1)*M.^2).^(gamma/(gamma-1)) - NPR;

if strcmpi(branch, 'sub')
    M_low  = 1e-6;
    M_high = 0.9999;
else
    M_low  = 1.00001;
    M_high = 10.0;
end

% Bisection root finder
for k = 1:80
    M_mid = 0.5*(M_low + M_high);
    f_mid = f(M_mid);
    f_low = f(M_low);
    
    if f_low * f_mid <= 0
        M_high = M_mid;
    else
        M_low = M_mid;
    end
    
    if abs(M_high - M_low) < 1e-12
        break;
    end
end

M = 0.5*(M_low + M_high);
end

function M = solve_m_from_area_ratio(AR, gamma, branch)
%SOLVE_M_FROM_AREA_RATIO Solve A/A* = AR for Mach number.
%   A/A* = (1/M) * (2/(gamma+1) * (1 + 0.5*(gamma-1)*M^2))^((gamma+1)/(2*(gamma-1)))
%   branch = 'sub' (subsonic) or 'sup' (supersonic)

AR = max(AR, 1.0);

area_fun = @(M) (1./M) .* ...
    ((2/(gamma+1) .* (1 + 0.5*(gamma-1).*M.^2)).^((gamma+1)/(2*(gamma-1))));

f = @(M) area_fun(M) - AR;

if strcmpi(branch, 'sub')
    M_low  = 1e-6;
    M_high = 0.9999;
else
    M_low  = 1.00001;
    M_high = 15.0;
end

% Bisection
for k = 1:80
    M_mid = 0.5*(M_low + M_high);
    f_mid = f(M_mid);
    f_low = f(M_low);
    
    if f_low * f_mid <= 0
        M_high = M_mid;
    else
        M_low = M_mid;
    end
    
    if abs(M_high - M_low) < 1e-12
        break;
    end
end

M = 0.5*(M_low + M_high);
end
