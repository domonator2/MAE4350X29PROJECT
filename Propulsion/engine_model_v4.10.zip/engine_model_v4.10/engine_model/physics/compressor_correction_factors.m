function [PR_fac, eta_fac, Wc_fac] = compressor_correction_factors(M0)
%COMPRESSOR_CORRECTION_FACTORS  Mach-dependent modifiers for compressor.
%
% Inputs:
%   M0 : flight Mach number (freestream)
%
% Outputs:
%   PR_fac  : multiplier on nominal compressor pressure ratio
%   eta_fac : multiplier on nominal compressor efficiency
%   Wc_fac  : multiplier on nominal corrected mass flow
%
% Notes:
%   - Values are heuristic but consistent with Kurzke-style trends:
%       * Slight PR and eta degradation with Mach.
%       * Slight Wc increase at transonic Mach.
%   - Tune the arrays once you compare to NASA F404 data.

    M0 = max(0.0, min(1.8, M0));

    % Mach grid
    M_grid  = [0.0  0.3  0.6  0.9  1.2  1.6  1.8];

    % PR correction (slight drop with Mach)
    PR_tab  = [1.00 1.00 0.99 0.98 0.96 0.94 0.93];

    % Efficiency correction (even milder drop)
    eta_tab = [1.000 0.998 0.995 0.990 0.985 0.980 0.978];

    % Corrected mass flow (slight increase as inlet conditions change)
    Wc_tab  = [1.000 1.000 1.005 1.010 1.015 1.020 1.020];

    PR_fac  = interp1(M_grid, PR_tab,  M0, 'linear', 'extrap');
    eta_fac = interp1(M_grid, eta_tab, M0, 'linear', 'extrap');
    Wc_fac  = interp1(M_grid, Wc_tab,  M0, 'linear', 'extrap');
end
