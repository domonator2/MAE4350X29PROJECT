function comp = compressor_model(cfg, inlet, params)
%COMPRESSOR_MODEL Estimate exit state for a simple axial compressor lumped model.
% Inputs:
%   cfg     : config with constants (cp, gamma)
%   inlet   : struct with {Pt_in, Tt_in}
%   params  : struct with {PR, eta}  (overall pressure ratio and adiabatic eff)
% Outputs:
%   comp    : struct with fields {Pt_out, Tt_out, w_specific, eta, PR}

gamma = cfg.const.gamma;
cp    = cfg.const.cp;

PR   = params.PR;
eta  = params.eta;

Pt_in = inlet.Pt_in;  Tt_in = inlet.Tt_in;

Pt_out = Pt_in * PR;
Tt_out_s = Tt_in * PR^((gamma-1)/gamma);
Tt_out   = Tt_in + (Tt_out_s - Tt_in)/max(1e-9, eta);

w_specific = cp * (Tt_out - Tt_in);

comp = struct('Pt_out',Pt_out, 'Tt_out',Tt_out, ...
              'w_specific',w_specific, 'eta',eta, 'PR',PR);
end
