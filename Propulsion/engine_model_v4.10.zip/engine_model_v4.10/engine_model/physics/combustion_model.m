function comb = combustion_model(cfg, inlet, params)
%COMBUSTION_MODEL Perform energy balance and pressure loss for main combustor.
% Uses temperature-dependent cp/gamma and explicit burner efficiency.

const = cfg.const;
R     = const.R;
cp_ref = getfieldwithdefault(const,'cp', 1004.5);
LHV   = getfieldwithdefault(const,'LHV', 43e6);

Pt3 = inlet.Pt_in;
Tt3 = inlet.Tt_in;
mdot_air = getfieldwithdefault(inlet,'mdot_air', NaN);

Tt4_cmd = getfieldwithdefault(params,'Tt_out_target', Tt3);

% Temperature-dependent properties (very simple correlation)
T_avg = 0.5*(Tt3 + Tt4_cmd);
cp_hot = cp_ref * (1.0 + 0.15*((T_avg - 288.15)/1000));
cp_hot = max(cp_ref, cp_hot);
gamma_hot = cp_hot / max(cp_hot - R, eps);

eta_b = getfieldwithdefault(params,'eta_burner', ...
    getfieldwithdefault(const,'eta_b', 0.94));
eta_b = max(min(eta_b,1.0), 0.5);

delta_h = cp_hot * max(Tt4_cmd - Tt3, 0);
f = delta_h / max(eta_b * LHV, 1e-6);
f = max(f, 0);

if isnan(mdot_air)
    mdot_fuel = NaN;
else
    mdot_fuel = f * mdot_air;
end

pi_b = 1 - getfieldwithdefault(params,'p_drop_comb',0.05);
pi_b = max(min(pi_b,1.0), 0.5);

Tt4 = Tt4_cmd;
Pt4 = Pt3 * pi_b;

comb = struct();
comb.Pt_out = Pt4;
comb.Tt_out = Tt4;
comb.f      = f;
comb.eta_b  = eta_b;
comb.cp_hot = cp_hot;
comb.gamma_hot = gamma_hot;
comb.mdot_fuel = mdot_fuel;
comb.mdot_air_out = mdot_air * (1 + f);
end

function val = getfieldwithdefault(s, name, default)
if isstruct(s) && isfield(s, name)
    val = s.(name);
else
    val = default;
end
end
