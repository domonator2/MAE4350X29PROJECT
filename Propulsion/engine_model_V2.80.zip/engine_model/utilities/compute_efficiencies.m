function eff = compute_efficiencies(cfg, in)
%COMPUTE_EFFICIENCIES Reusable formulas for component efficiencies.
% Provides both isentropic and polytropic conversions for compressors/turbines.
% Use:
%   eff.eta_c_from_PR = eta_c(PR, Tt_in, Tt_out);
%   eff.eta_t_from_PR = eta_t(PR, Tt_in, Tt_out);

gamma = cfg.const.gamma;

eff = struct();

eff.eta_c = @(PR, Tt_in, Tt_out) ( (PR)^((gamma-1)/gamma) - 1 ) ./ max(1e-12, (Tt_out/Tt_in - 1) );
eff.eta_t = @(PR, Tt_in, Tt_out) ( 1 - (PR)^((1-gamma)/gamma) ) ./ max(1e-12, (1 - Tt_out/Tt_in) );

% Polytropic <-> Adiabatic conversions (compressor)
eff.eta_poly_c = @(eta_ad, PR) log(PR) ./ max(1e-12, log( 1 + eta_ad.*(PR.^((gamma-1)/gamma) - 1) ));
eff.eta_ad_from_poly_c = @(eta_poly, PR) ( (exp(log(PR)./max(1e-12,eta_poly))).^((gamma-1)/gamma) - 1 ) ./ max(1e-12, (PR.^((gamma-1)/gamma) - 1) );

% Polytropic <-> Adiabatic (turbine)
eff.eta_poly_t = @(eta_ad, PR) log(PR) ./ max(1e-12, log( 1 ./ (1 - (1-eta_ad).*(1 - PR.^((1-gamma)/gamma))) ));
eff.eta_ad_from_poly_t = @(eta_poly, PR) 1 - (1 - PR.^((1-gamma)/gamma)) ./ max(1e-12, (1 - (exp(log(PR)./max(1e-12,eta_poly))).^((1-gamma)/gamma)) );

end
