function [T, P, D] = standard_atmosphere(hcg)
%STANDARD_ATMOSPHERE ARDC 1959 standard atmosphere model.
% Adapted from Dr. Julio C. Benavides' implementation provided by the user.
% Inputs:
%   hcg : geometric altitude [m]
% Outputs:
%   T   : temperature [K]
%   P   : pressure [Pa]
%   D   : density [kg/m^3]

g  = 9.80665;   % [m/s^2]
R  = 287;       % [J/(kg*K)]
Re = 6378137;   % [m]

h = Re * hcg / (Re + hcg); % geopotential altitude [m]

if h <= 11000
    a = (216.66 - 288.16) / 11000;
    T = 288.16 + a * h;
    P = 101325 * (T / 288.16)^(-g / (a * R));
    D = P / (R * T);
    return;
elseif h <= 25000
    T = 216.66;
    P = 22650.1684742737 * exp(-g / (R * T) * (h - 11000));
    D = P / (R * T);
    return;
elseif h <= 47000
    a = (282.66 - 216.66) / (47000 - 25000);
    T = 216.66 + a * (h - 25000);
    P = 2493.58245271879 * (T / 216.66)^(-g / (a * R));
    D = P / (R * T);
    return;
elseif h <= 53000
    T = 282.66;
    P = 120.879682128688 * exp(-g / (R * T) * (h - 47000));
    D = P / (R * T);
    return;
elseif h <= 79000
    a = (165.66 - 282.66) / (79000 - 53000);
    T = 282.66 + a * (h - 53000);
    P = 58.5554504138705 * (T / 282.66)^(-g / (a * R));
    D = P / (R * T);
    return;
elseif h <= 90000
    T = 165.66;
    P = 1.01573256565262 * exp(-g / (R * T) * (h - 79000));
    D = P / (R * T);
    return;
elseif h <= 105000
    a = (225.66 - 165.66) / (105000 - 90000);
    T = 165.66 + a * (h - 90000);
    P = 0.105215646463089 * (T / 165.66)^(-g / (a * R));
    D = P / (R * T);
    return;
elseif h <= 500000
    a = (4 - 225.66) / (500000 - 105000);
    T = 225.66 + a * (h - 105000);
    P = 0.00751891790761519 * (T / 225.66)^(-g / (a * R));
    D = P / (R * T);
    return;
else
    T = 4;
    P = 0;
    D = 0;
    return;
end
end
