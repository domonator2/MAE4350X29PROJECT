function val_out = convert_units(val_in, from_unit, to_unit)
%CONVERT_UNITS Minimal unit converter for common propulsion units.
% Supports:
%   Temperature: K <-> C, K <-> R, C <-> F
%   Pressure: Pa <-> kPa <-> bar <-> psia
%   Mass flow: kg/s <-> lbm/s
%   Energy: J <-> MJ <-> BTU
%
% Example:
%   convert_units(101325,'Pa','bar')  % -> 1.01325

from = lower(strtrim(from_unit));
to   = lower(strtrim(to_unit));

if strcmp(from,to)
    val_out = val_in; return;
end

switch from
    % Temperature (handled specially due to offset)
    case {'k','kelvin'}
        switch to
            case {'c','celsius'}, val_out = val_in - 273.15;
            case {'r','rankine'}, val_out = val_in * 9/5;
            case {'f','fahrenheit'}, val_out = (val_in - 273.15)*9/5 + 32;
            otherwise, error('Unsupported to-unit for K: %s', to);
        end
    case {'c','celsius'}
        switch to
            case {'k','kelvin'}, val_out = val_in + 273.15;
            case {'f','fahrenheit'}, val_out = val_in*9/5 + 32;
            case {'r','rankine'}, val_out = (val_in + 273.15)*9/5;
            otherwise, error('Unsupported to-unit for C: %s', to);
        end
    case {'f','fahrenheit'}
        switch to
            case {'c','celsius'}, val_out = (val_in - 32)*5/9;
            case {'k','kelvin'},  val_out = (val_in - 32)*5/9 + 273.15;
            case {'r','rankine'}, val_out = val_in + 459.67;
            otherwise, error('Unsupported to-unit for F: %s', to);
        end
    case {'r','rankine'}
        switch to
            case {'k','kelvin'}, val_out = val_in * 5/9;
            case {'c','celsius'}, val_out = val_in * 5/9 - 273.15;
            case {'f','fahrenheit'}, val_out = val_in - 459.67;
            otherwise, error('Unsupported to-unit for R: %s', to);
        end

    % Pressure
    case {'pa'}
        switch to
            case {'kpa'},  val_out = val_in / 1e3;
            case {'bar'},  val_out = val_in / 1e5;
            case {'psia'}, val_out = val_in / 6894.75729;
            otherwise, error('Unsupported to-unit for Pa: %s', to);
        end
    case {'kpa'}
        switch to
            case {'pa'},   val_out = val_in * 1e3;
            case {'bar'},  val_out = val_in / 100;
            case {'psia'}, val_out = (val_in*1e3) / 6894.75729;
            otherwise, error('Unsupported to-unit for kPa: %s', to);
        end
    case {'bar'}
        switch to
            case {'pa'},   val_out = val_in * 1e5;
            case {'kpa'},  val_out = val_in * 100;
            case {'psia'}, val_out = (val_in*1e5) / 6894.75729;
            otherwise, error('Unsupported to-unit for bar: %s', to);
        end
    case {'psia'}
        switch to
            case {'pa'},  val_out = val_in * 6894.75729;
            case {'kpa'}, val_out = val_in * 6.89475729;
            case {'bar'}, val_out = val_in * 0.0689475729;
            otherwise, error('Unsupported to-unit for psia: %s', to);
        end

    % Mass flow
    case {'kg/s','kgps','kgpersec'}
        switch to
            case {'lbm/s','lbmps'}, val_out = val_in * 2.2046226218;
            otherwise, error('Unsupported to-unit for kg/s: %s', to);
        end
    case {'lbm/s','lbmps'}
        switch to
            case {'kg/s','kgps'}, val_out = val_in / 2.2046226218;
            otherwise, error('Unsupported to-unit for lbm/s: %s', to);
        end

    % Energy
    case {'j'}
        switch to
            case {'mj'},  val_out = val_in / 1e6;
            case {'btu'}, val_out = val_in / 1055.05585;
            otherwise, error('Unsupported to-unit for J: %s', to);
        end
    case {'mj'}
        switch to
            case {'j'},   val_out = val_in * 1e6;
            case {'btu'}, val_out = (val_in*1e6) / 1055.05585;
            otherwise, error('Unsupported to-unit for MJ: %s', to);
        end
    case {'btu'}
        switch to
            case {'j'},   val_out = val_in * 1055.05585;
            case {'mj'},  val_out = val_in * 1.05505585;
            otherwise, error('Unsupported to-unit for BTU: %s', to);
        end

    otherwise
        error('Unsupported from-unit: %s', from);
end
end
