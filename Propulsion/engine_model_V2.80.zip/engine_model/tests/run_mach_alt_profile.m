% RUN_MACH_ALT_PROFILE Ramp Mach and altitude to visualize model performance.
% Usage:
%   run('tests/run_mach_alt_profile.m');

clear; clc;

project_root = fileparts(fileparts(mfilename('fullpath')));
addpath(genpath(project_root));

cfg = config_model();
in = load_inputs(cfg);

N = numel(in.time);
mach_profile = linspace(0, 1.6, N).';
alt_profile_m = linspace(0, 15300, N).';

in.atm.M0 = mach_profile;
in.atm.alt = alt_profile_m;
in.atm.T0 = NaN(N,1);
in.atm.p0 = NaN(N,1);
in.atm.use_standard_atm = true(N,1);

results = simulate_engine(cfg, in);
plot_results(cfg, results);

out_path = fullfile(project_root, 'data', 'mach_alt_profile_results.mat');
save(out_path, 'cfg', 'in', 'results');
fprintf('Saved Mach/altitude profile results to %s\n', out_path);

summary_tbl = table(results.time(:), results.M0(:), results.alt(:), results.Thrust(:), results.TSFC(:), ...
    'VariableNames', {'time_s','Mach','alt_m','Thrust_N','TSFC_kg_per_N_s'});
writetable(summary_tbl, fullfile(project_root,'data','mach_alt_profile_summary.csv'));
