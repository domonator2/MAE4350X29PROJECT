# engine_model

MATLAB project skeleton for a modular gas turbine engine model.

## Structure
- `main/` – orchestration scripts (run_model, config, plotting)
- `core/` – simulation loop and cycle solver
- `physics/` – component models (compressor, combustor, turbine, etc.)
- `data/` – input data and baseline conditions
- `utilities/` – helpers (validation, unit conversions, efficiencies)
- `tests/` – unit and integration tests

## Quickstart (MATLAB)
```
cd engine_model
run('main/run_model.m')
```


## Step 3
Added `core/compute_outputs.m` and strengthened `core/solve_cycle.m` to produce summary metrics.


## Development Workflow

1. **Start with stable inputs**
   - Implement or adjust `data/load_inputs.m`. Commit baseline MAT files to `data/` when available.
   - Validate using `utilities/validate_inputs.m`.

2. **Unit-test each physics module**
   - Use `tests/test_compressor.m`, `tests/test_combustion.m`, and add more for turbines, nozzle, etc.
   - Run all tests via:
     ```matlab
     cd engine_model
     run('tests/run_unit_tests.m'); results = run_unit_tests();
     ```

3. **Integrate in `core/solve_cycle.m` then `core/simulate_engine.m`**
   - Keep the `cycle` struct clean (Pt*, Tt*, works, f). Avoid side effects.
   - Add off-design features later (maps, variable gamma).

4. **Plotting and reporting**
   - Extend `main/plot_results.m` once the loop produces stable traces.
   - Save runs via `cfg.save_path` for reproducibility.

5. **Commit frequently**
   - Use descriptive messages (e.g., `physics: add polytropic compressor option`).
   - Include test changes with code changes.

### Coding Style
- MATLAB help header at the top of each function describing inputs/outputs/assumptions.
- Use `cfg` and `in` structs—avoid hard-coded constants.
- Preallocate arrays in loops.
- Prefer clear names (`Pt3`, `Tt4`, `OPR`) and SI units internally.

