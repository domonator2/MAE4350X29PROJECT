% RUN_MODEL Orchestrate a simple end-to-end simulation.
% Usage: run('main/run_model.m');
clear; clc; close all;

% Workspace setup ----------------------------------------------------------------
[this_dir, project_root] = setup_environment();
add_project_paths(project_root);

% Load configuration & inputs -----------------------------------------------------
cfg = config_model();
in  = load_and_validate_inputs(cfg);

% Core simulation -----------------------------------------------------------------
results = simulate_engine(cfg, in);

% Quick text summary ---------------------------------------------------------------
print_run_summary(results);

% Plot results --------------------------------------------------------------------
if cfg.plotting.enable
    plot_results(cfg, results);
end

% Save run ------------------------------------------------------------------------
save_results(cfg, project_root, in, results);

%% Local helpers
function [this_dir, project_root] = setup_environment()
this_dir = fileparts(mfilename('fullpath'));
project_root = fileparts(this_dir);
end

function add_project_paths(project_root)
addpath(project_root);
subfolders = {'core','data','main','physics','tests','utilities'};
for k = 1:numel(subfolders)
    addpath(genpath(fullfile(project_root, subfolders{k})));
end
end

function in = load_and_validate_inputs(cfg)
in = load_inputs(cfg);
validate_inputs(in);
end

function save_results(cfg, project_root, in, results)
save_path = cfg.save_path;
if ~is_absolute_path(save_path)
    save_path = fullfile(project_root, save_path);
end

outdir = fileparts(save_path);
if ~isempty(outdir) && ~exist(outdir,'dir')
    mkdir(outdir);
end

try
    save(save_path, 'cfg', 'in', 'results');
    fprintf('Saved results to %s\n', save_path);
catch ME
    warning(ME.identifier, 'Could not save results: %s', ME.message);
end

write_readable_outputs(save_path, results);
end

function tf = is_absolute_path(p)
if isempty(p)
    tf = false; return;
end

if ispc
    tf = ~isempty(regexp(p,'^[A-Za-z]:','once')) || startsWith(p,'\\');
else
    tf = startsWith(p,'/');
end
end

function print_run_summary(results)
if ~isfield(results,'time') || ~isfield(results,'Thrust')
    return;
end

time = results.time(:);
thrust = results.Thrust(:);
tsfc = get_result_column(results,'TSFC',numel(time));

fprintf('\n=== Run Summary ===\n');
fprintf('Duration: %.2f s (%d steps)\n', time(end) - time(1), numel(time));

if ~all(isnan(thrust))
    valid_thrust = thrust(~isnan(thrust));
    final_idx = find(~isnan(thrust), 1, 'last');
    if isempty(final_idx)
        final_val = thrust(end);
    else
        final_val = thrust(final_idx);
    end
    fprintf('Thrust: final %.2f N | mean %.2f N | max %.2f N\n', ...
        final_val, mean(valid_thrust), max(valid_thrust));
else
    fprintf('Thrust: Not available (NaN).\n');
end

if ~all(isnan(tsfc))
    valid_tsfc = tsfc(~isnan(tsfc));
    final_idx = find(~isnan(tsfc), 1, 'last');
    if isempty(final_idx)
        final_tsfc = tsfc(end);
    else
        final_tsfc = tsfc(final_idx);
    end
    fprintf('TSFC: final %.4e kg/N/s | mean %.4e kg/N/s\n', ...
        final_tsfc, mean(valid_tsfc));
else
    fprintf('TSFC: Not available (NaN).\n');
end

if isfield(results,'PLA')
    fprintf('PLA range: %.2f to %.2f\n', min(results.PLA,[],'omitnan'), max(results.PLA,[],'omitnan'));
end
if isfield(results,'AB')
    fprintf('AB range: %.2f to %.2f\n', min(results.AB,[],'omitnan'), max(results.AB,[],'omitnan'));
end
if isfield(results,'alt')
    fprintf('Altitude range: %.0f m to %.0f m\n', min(results.alt,[],'omitnan'), max(results.alt,[],'omitnan'));
end
fprintf('===================\n\n');
end

function write_readable_outputs(save_path, results)
[folder, base, ~] = fileparts(save_path);
if isempty(folder)
    folder = pwd;
end

summary_csv = fullfile(folder, sprintf('%s_summary.csv', base));

if isfield(results,'time') && isfield(results,'Thrust')
    thrust = results.Thrust(:);
    nrows = numel(thrust);
    tsfc = get_result_column(results,'TSFC', nrows);
    pla  = get_result_column(results,'PLA', nrows);
    ab   = get_result_column(results,'AB', nrows);
    tt4cmd = get_result_column(results,'Tt4_cmd', nrows);
    alt = get_result_column(results,'alt', nrows);
    mach = get_result_column(results,'M0', nrows);
    T0 = get_result_column(results,'T0', nrows);
    p0 = get_result_column(results,'p0', nrows);
    summary_table = table(results.time(:), alt, mach, T0, p0, pla, ab, tt4cmd, thrust, tsfc, ...
        'VariableNames', {'time_s','alt_m','Mach','T0_K','p0_Pa','PLA','AB','Tt4_cmd_K','Thrust_N','TSFC_kg_per_N_s'});
    try
        writetable(summary_table, summary_csv);
        fprintf('Wrote readable summary to %s\n', summary_csv);
    catch ME
        warning(ME.identifier, 'Could not write summary CSV: %s', ME.message);
    end
end
end

function col = get_result_column(results, name, N)
if isfield(results, name)
    data = results.(name);
    if numel(data) == N
        col = data(:);
        return;
    end
end
col = nan(N,1);
end
