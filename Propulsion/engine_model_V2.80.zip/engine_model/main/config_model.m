function cfg = config_model()
%CONFIG_MODEL Define high-level options for the engine model run.
% Outputs:
%   cfg : struct of configuration parameters used across the project

% ----------------------------
% Simulation controls
% ----------------------------
cfg.dt        = 0.1;        % [s] time step
cfg.t_end     = 5.0;        % [s] end time
cfg.save_path = 'data/last_run.mat'; % where to save results

% ----------------------------
% Tolerances / solver
% ----------------------------
cfg.tol.abs   = 1e-6;
cfg.tol.rel   = 1e-6;
cfg.max_iter  = 50;         % generic iteration limit for cycle solves

% ----------------------------
% Feature toggles
% ----------------------------
cfg.features.enable_nozzle        = false;  % hook for later
cfg.features.variable_gamma       = false;  % hook for later
cfg.features.enable_afterburner   = false;  % hook for later

% ----------------------------
% Environment / constants
% ----------------------------
cfg.const.R        = 287.05;  % [J/(kg*K)] specific gas constant for air
cfg.const.cp       = 1004.5;  % [J/(kg*K)] cp (cold sections)
cfg.const.gamma    = 1.4;     % [-] gamma for cold stream

cfg.const.gamma_hot = 1.32;   % [-] representative hot-gas gamma
% ----------------------------
% Nominal component parameters (starter values; refined later)
% ----------------------------
cfg.params.PR_c   = 12.0;    % [-] overall compressor pressure ratio (core)
cfg.params.eta_c  = 0.86;    % [-] compressor polytropic/adiabatic eff (starter)
cfg.params.Tt4    = 1550.0;  % [K] burner exit total temperature (non-AB)
cfg.params.eta_t  = 0.90;    % [-] turbine efficiency
cfg.params.p_drop_comb = 0.05; % [-] combustor total pressure loss fraction
cfg.params.mdot   = 28.0;    % [kg/s] core mass flow (starter)

% ----------------------------
% Plotting
% ----------------------------
cfg.plotting.enable = true;

end


