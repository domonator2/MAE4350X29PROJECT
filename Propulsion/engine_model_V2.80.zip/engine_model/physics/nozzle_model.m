function nozzle = nozzle_model(Pt_in, Tt_in, mdot_in, atm, params, cfg)
%NOZZLE_MODEL Variable-area convergent / convergent-divergent nozzle.
%
% Inputs:
%   Pt_in, Tt_in : total conditions at nozzle inlet (station 9)
%   mdot_in      : mass flow through nozzle [kg/s]
%   atm          : struct with {p0, T0, M0}
%   params       : struct with {A_nozzle, A_nozzle_exit, A_throat, Cd_noz,
%                               nozzle_type, mdot_fan (optional)}
%   cfg          : either cfg.const struct or full cfg with cfg.const
%
% Outputs:
%   nozzle : struct with {Me, Te, Pe, Ve, rho_e, mdot, mdot_geom,
%                         mdot_total_in, Fg, A_nozzle, Cd_noz}

% -----------------------------
% Constants / freestream
% -----------------------------
if isstruct(cfg) && isfield(cfg,'const')
    const = cfg.const;
else
    const = cfg;
end

gamma_hot = getfieldwithdefault(const,'gamma_hot', const.gamma);
gamma_fs  = getfieldwithdefault(const,'gamma',      1.4);
R         = const.R;

p0 = getfieldwithdefault(atm,'p0',101325);
T0 = getfieldwithdefault(atm,'T0',288.15);
M0 = getfieldwithdefault(atm,'M0',0.0);
a0 = sqrt(gamma_fs * R * T0);
V0 = M0 * a0;

Pt9 = Pt_in;
Tt9 = Tt_in;
mdot = mdot_in;

% Geometry and type
A_exit   = getfieldwithdefault(params,'A_nozzle_exit', ...
           getfieldwithdefault(params,'A_exit', ...
           getfieldwithdefault(params,'A_nozzle', NaN)));
A_throat = getfieldwithdefault(params,'A_throat', ...
           getfieldwithdefault(params,'A_nozzle', A_exit));
Cd_noz   = getfieldwithdefault(params,'Cd_noz', 0.98);
noz_type = getfieldwithdefault(params,'nozzle_type','convergent');

A_exit   = max(A_exit,   0);
A_throat = max(A_throat, 0);

if ~isfinite(Pt9) || ~isfinite(Tt9) || Pt9 <= 0 || Tt9 <= 0 || ...
   ~isfinite(mdot) || mdot <= 0 || A_exit <= 0 || A_throat <= 0
    nozzle = empty_nozzle();
    nozzle.A_nozzle = A_exit;
    nozzle.Cd_noz   = Cd_noz;
    return;
end

% -----------------------------
% Choked mass-flow capacity at throat
% (standard choked-flow relation)
% -----------------------------
gamma = gamma_hot;
Rgas  = R;

crit_factor = (gamma+1)/2;
mdot_choked_geom = Cd_noz * A_throat * Pt9 / sqrt(Tt9) * ...
    sqrt(gamma/Rgas) * crit_factor^(-(gamma+1)/(2*(gamma-1)));

mdot_geom = mdot_choked_geom;
mdot_eff  = min(mdot, mdot_geom);   % enforce choked capacity

% -----------------------------
% Determine exit Mach / state
% -----------------------------
P_amb = p0;

% Critical pressure ratio for sonic at the throat
crit_PR = (2/(gamma+1))^(gamma/(gamma-1));   % (Pt/Ps)_crit

PR = Pt9 / max(P_amb,1e-6);   % total-to-ambient

Me  = NaN;
Te  = NaN;
Pe  = NaN;
rho_e = NaN;
Ve  = NaN;

Ae_At = max(A_exit / max(A_throat,1e-9), 1.0);

if strcmpi(noz_type,'convergent')
    % -------------------------
    % Simple convergent nozzle
    % -------------------------
    if PR <= 1/crit_PR
        % Unchoked: solve for Me so that Pe ~ P_amb
        % Pt/P = (1 + (gamma-1)/2 M^2)^(gamma/(gamma-1))
        Me = solve_M_from_pressure_ratio(PR, gamma);
    else
        % Choked at exit
        Me = 1.0;
    end

    T_ratio = 1 + 0.5*(gamma-1)*Me^2;
    Te = Tt9 / T_ratio;
    Pe = Pt9 / T_ratio^(gamma/(gamma-1));
    rho_e = Pe/(Rgas*Te);

    % Use mass-flow consistency: mdot_eff = rho_e * A_exit * Ve
    Ve = mdot_eff / (rho_e * A_exit);

else
    % -------------------------------------------
    % Convergent-divergent (variable-geometry)
    % -------------------------------------------
    if PR <= 1/crit_PR
        % Not enough pressure to choke: treat as convergent
        Me = solve_M_from_pressure_ratio(PR, gamma);
        T_ratio = 1 + 0.5*(gamma-1)*Me^2;
        Te = Tt9 / T_ratio;
        Pe = Pt9 / T_ratio^(gamma/(gamma-1));
        rho_e = Pe/(Rgas*Te);
        Ve = mdot_eff / (rho_e * A_exit);
    else
        % Throat is sonic; exit supersonic if Ae/At > 1.
        if Ae_At <= 1.0001
            Me = 1.0;
        else
            % Variable-geometry: compute ideal expansion area ratio for current pressure ratio
            % This adapts the effective exit area based on ambient pressure matching
            Ae_At_ideal = ideal_expansion_ratio(Pt9, P_amb, gamma);
            Ae_At_eff = min(Ae_At, Ae_At_ideal);  % cannot exceed geometric limit
            Ae_At_eff = max(Ae_At_eff, 1.0001);   % but maintain supersonic expansion
            
            Me = solve_supersonic_M_from_area(Ae_At_eff, gamma);
        end

        T_ratio = 1 + 0.5*(gamma-1)*Me^2;
        Te = Tt9 / T_ratio;
        Pe = Pt9 / T_ratio^(gamma/(gamma-1));
        rho_e = Pe/(Rgas*Te);
        Ve = Me * sqrt(gamma*Rgas*Te);
    end
end

% -----------------------------
% Thrust (gross) with pressure term
% -----------------------------
Fg = mdot_eff * (Ve - V0) + (Pe - P_amb) * A_exit;

% Guard against unphysical negative thrust when total pressure collapses
% to ambient or numerical noise drives Ve < V0.
if Pt9 <= P_amb
    Fg = 0.0;
end
Fg = max(Fg, 1.0);  % Minimum 1 N to avoid zero-thrust singularities

nozzle = struct( ...
    'Me',            Me, ...
    'Te',            Te, ...
    'Pe',            Pe, ...
    'Ve',            Ve, ...
    'rho_e',         rho_e, ...
    'mdot',          mdot_eff, ...
    'mdot_geom',     mdot_geom, ...
    'mdot_total_in', mdot, ...
    'Fg',            Fg, ...
    'A_nozzle',      A_exit, ...
    'Cd_noz',        Cd_noz);

end

% ============================
% Helpers
% ============================

function M = solve_M_from_pressure_ratio(PR, gamma)
% Solve Pt/P = PR for subsonic M
% Pt/P = (1 + (gamma-1)/2 M^2)^(gamma/(gamma-1))
target = 1/max(PR,1e-6);  % P/Pt
f = @(M) (1 + 0.5*(gamma-1).*M.^2).^(gamma/(gamma-1)) - 1/target;

M_lo = 0.0; M_hi = 1.0;
for k = 1:40
    M_mid = 0.5*(M_lo + M_hi);
    if f(M_mid) > 0
        M_hi = M_mid;
    else
        M_lo = M_mid;
    end
end
M = 0.5*(M_lo + M_hi);
end

function M = solve_supersonic_M_from_area(AeAt, gamma)
% Invert area-Mach relation for supersonic branch
area_ratio_from_M = @(M) ...
    (1./max(M,1e-6)) .* ((2./(gamma+1)) .* (1 + 0.5*(gamma-1).*M.^2)).^((gamma+1)./(2*(gamma-1)));

M_lo = 1.0001; M_hi = 8.0;
for k = 1:50
    M_mid = 0.5*(M_lo + M_hi);
    f_mid = area_ratio_from_M(M_mid) - AeAt;
    f_lo  = area_ratio_from_M(M_lo)  - AeAt;
    if f_mid == 0
        M_lo = M_mid; M_hi = M_mid;
    elseif sign(f_mid) == sign(f_lo)
        M_lo = M_mid;
    else
        M_hi = M_mid;
    end
end
M = 0.5*(M_lo + M_hi);
end

function nozzle = empty_nozzle()
    nozzle = struct( ...
        'Me', NaN, 'Te', NaN, 'Pe', NaN, 'Ve', NaN, ...
        'rho_e', NaN, 'mdot', NaN, 'mdot_geom', NaN, ...
        'mdot_total_in', NaN, 'Fg', NaN, 'A_nozzle', NaN, 'Cd_noz', NaN);
end

function val = getfieldwithdefault(s, name, default)
    if isstruct(s) && isfield(s, name)
        val = s.(name);
    else
        val = default;
    end
end

function Ae_At_ideal = ideal_expansion_ratio(Pt, Pamb, gamma)
% IDEAL_EXPANSION_RATIO Compute ideal exit-to-throat area ratio for isentropic expansion.
%
% For a given total pressure Pt, ambient pressure Pamb, and heat capacity ratio gamma,
% computes the ideal (isentropic, perfectly expanded) Ae/At ratio such that the exit
% static pressure matches ambient pressure.
%
% Formulation:
%   1. Pressure ratio: P_ratio = Pamb / Pt
%   2. Exit Mach for perfect expansion: solve from P_ratio = (1 + 0.5*(gamma-1)*Me^2)^(-gamma/(gamma-1))
%   3. Area ratio: Ae/At = (1/Me) * ((2/(gamma+1)) * (1 + 0.5*(gamma-1)*Me^2))^((gamma+1)/(2*(gamma-1)))

    % Clamp pressure ratio to physically valid range
    P_ratio = min(max(Pamb / max(Pt, 1e-6), 1e-6), 1.0);
    
    % Solve for exit Mach using isentropic relation
    % Pt / P = (1 + 0.5*(gamma-1)*M^2)^(gamma/(gamma-1))
    % P / Pt = 1 / (1 + 0.5*(gamma-1)*M^2)^(gamma/(gamma-1))
    
    % For Pe = Pamb:
    inv_T_ratio = P_ratio^((gamma-1)/gamma);
    Me_ideal_sq = max((inv_T_ratio - 1) / (0.5*(gamma-1)), 0);
    Me_ideal = sqrt(Me_ideal_sq);
    
    % Clamp to subsonic to avoid negative area ratios
    Me_ideal = max(Me_ideal, 1e-3);
    
    % Compute area ratio from area-Mach relation
    crit_factor = 2 / (gamma + 1);
    T_factor = crit_factor * (1 + 0.5*(gamma-1)*Me_ideal^2);
    exponent = (gamma + 1) / (2*(gamma - 1));
    
    Ae_At_ideal = (1.0 / Me_ideal) * (T_factor ^ exponent);
    
    % Clamp to reasonable bounds [0.5, 3.0] for physical plausibility
    Ae_At_ideal = min(max(Ae_At_ideal, 0.5), 3.0);
end
