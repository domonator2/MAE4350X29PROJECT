function turb = turbine_model(cfg, inlet, params)
%TURBINE_MODEL Compute turbine exit to deliver required specific work.
% Inputs:
%   cfg     : constants {cp, gamma}
%   inlet   : struct with {Pt_in, Tt_in}
%   params  : struct with {w_required, eta}  OR {PR, eta}
% Outputs:
%   turb    : struct with {Pt_out, Tt_out, w_specific, eta, mode}
%
% Mode A (power-balanced): if 'w_required' present, compute T drop to supply it.
% Mode B (pressure-ratio): if 'PR' present, compute exit state from PR.

cp    = cfg.const.cp;
% Use hot gas gamma if available, else standard 1.4
gamma = getfieldwithdefault(cfg.const,'gamma_hot', ...
        getfieldwithdefault(cfg.const,'gamma', 1.4));

Pt_in = inlet.Pt_in;  Tt_in = inlet.Tt_in;
eta_t = params.eta;

if isfield(params,'w_required')
    w_req    = params.w_required;
    Tt_out_s = Tt_in - w_req/cp;
    Tt_out   = Tt_in - eta_t*(Tt_in - Tt_out_s);
    
    % Infer equivalent PR from isentropic relation (for bookkeeping)
    tau        = Tt_out_s / Tt_in;
    PR_equiv   = tau.^(gamma/(gamma-1));
    Pt_out     = Pt_in * PR_equiv;
    mode       = 'power';
    w_specific = w_req;
else
    % Pressure-ratio driven expansion
    PR         = params.PR;
    Pt_out     = Pt_in / max(1e-9, PR);
    Tt_out_s   = Tt_in * (1/PR)^((gamma-1)/gamma);
    Tt_out     = Tt_in - eta_t*(Tt_in - Tt_out_s);
    w_specific = cp*(Tt_in - Tt_out);
    mode       = 'PR';
end

turb = struct('Pt_out',Pt_out, 'Tt_out',Tt_out, ...
              'w_specific',w_specific, 'eta',eta_t, 'mode',mode);
end

function val = getfieldwithdefault(s, name, default)
if isfield(s, name)
    val = s.(name);
else
    val = default;
end
end
