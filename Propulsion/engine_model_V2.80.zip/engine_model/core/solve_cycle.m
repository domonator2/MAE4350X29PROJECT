function out = solve_cycle(cfg, op, state_in)
%SOLVE_CYCLE Coordinate component models for one operating point.
% Inputs:
%   cfg      : configuration/constants for the solver
%   op       : operating point struct (PLA, AB, atm, params, optional state)
%   state_in : optional state struct carried across time steps
% Outputs:
%   out      : struct with station properties, metrics, and updated state

% -------------------------------------------------------------------------
% Resolve atmospheric conditions / freestream totals
% -------------------------------------------------------------------------
atm = resolve_atmosphere(op);
gamma = cfg.const.gamma;
R = cfg.const.R;

M0 = getfieldwithdefault(atm, 'M0', getfieldwithdefault(op, 'M0', 0));
T0 = getfieldwithdefault(atm, 'T0', getfieldwithdefault(op, 'T0', 288.15));
p0 = getfieldwithdefault(atm, 'p0', getfieldwithdefault(op, 'p0', 101325));
rho0 = getfieldwithdefault(atm,'rho0', p0/(R*T0));
a0 = sqrt(gamma * R * T0);
V0 = M0 * a0;

cycle = struct();
cycle.V0 = V0;
cycle.M0 = M0;
cycle.rho0 = rho0;
cycle.alt = getfieldwithdefault(atm,'alt',0);
cycle.q_inf = 0.5 * rho0 * V0.^2;
cycle.T0 = T0;
cycle.p0 = p0;
cycle.atm = atm;

% -------------------------------------------------------------------------
% Inlet capture, pressure recovery, and ram drag
% -------------------------------------------------------------------------
A_cap = getfieldwithdefault(op.params,'A_capture', ...
    getfieldwithdefault(op.params,'A_inlet_capture', NaN));
A_cap = max(A_cap, 0);

% Inlet pressure recovery: prefer table, otherwise default law
if isfield(op.params,'M_inlet_tab') && isfield(op.params,'eta_inlet_tab')
    M_tab   = op.params.M_inlet_tab;
    eta_tab = op.params.eta_inlet_tab;
    eta_inlet = interp1(M_tab, eta_tab, M0, 'pchip', 'extrap');
else
    eta_inlet = inlet_recovery_simple(M0);
end
eta_inlet = max(min(eta_inlet,1.0), 0.0);

% Design corrected flow condition
mdot_design_total = getfieldwithdefault(op.params,'mdot_design_total', ...
    getfieldwithdefault(op.params,'mdot_core_nom',0) + ...
    getfieldwithdefault(op.params,'mdot_fan_nom',0));
rho_des = getfieldwithdefault(op.params,'rho_des', 1.225);
M_des   = getfieldwithdefault(op.params,'M_des', 0.90);

% Prevent collapse of flow near static
M_eff = max(M0, 0.05);

% Keep mdot / (rho * M) approximately constant vs Mach/altitude
mdot_capture = mdot_design_total * (rho0/rho_des) * (M_eff/M_des);

% Optional geometric cap using inlet capture area
if A_cap > 0
    mdot_geom = rho0 * max(V0,0) * A_cap;
    mdot_capture = min(mdot_capture, mdot_geom);
end

% Only aerodynamic inlet/cowl drag; nozzle_model already accounts for
% freestream momentum through (Ve - V0).
Cd_inlet = getfieldwithdefault(op.params,'CD_inlet',0.0);
A_inlet_ref = getfieldwithdefault(op.params,'A_inlet_ref', A_cap);
D_inlet = Cd_inlet * cycle.q_inf * max(A_inlet_ref, 0);

cycle.mdot_capture   = mdot_capture;
cycle.ram_drag_inlet = D_inlet;
cycle.ram_drag       = D_inlet;
cycle.eta_inlet      = eta_inlet;
cycle.D_inlet        = D_inlet;

% Pass thermodynamic constants to mass-flow estimation (needed for corrected flow)
cycle.gamma = gamma;
cycle.R     = R;

cycle = estimate_mass_flows_and_maps(cycle, op);
cycle.PLA = getfieldwithdefault(op,'PLA',1.0);
cycle.AB_sched = getfieldwithdefault(op,'AB',0.0);
cycle.AB  = shape_ab_command(cycle.PLA, cycle.AB_sched, op.params);
cycle.AB_cmd = cycle.AB;

% % Apply PLA-based mass flow scaling (disabled for physics-only mode)
% PLA = cycle.PLA;
% if isfield(op.params,'mdot_pla_tab') && isfield(op.params,'mdot_pla_scale') && ...
%     ~isempty(op.params.mdot_pla_tab) && ~isempty(op.params.mdot_pla_scale)
%     mdot_scale = interp1(op.params.mdot_pla_tab, op.params.mdot_pla_scale, PLA, 'pchip', 'extrap');
%     cycle.mdot_core = cycle.mdot_core * mdot_scale;
%     cycle.mdot_fan = cycle.mdot_fan * mdot_scale;
% end

% Apply bleed and cooling fractions if defined
orig_mdot_core = cycle.mdot_core;
bleed_frac = 0.0;
cool_frac = 0.0;
if isfield(op.params,'bleed_pla_tab') && isfield(op.params,'bleed_frac_tab')
    bleed_frac = interp1(op.params.bleed_pla_tab, op.params.bleed_frac_tab, ...
        cycle.PLA, 'pchip', 'extrap');
end
if isfield(op.params,'cool_pla_tab') && isfield(op.params,'cool_frac_tab')
    cool_frac = interp1(op.params.cool_pla_tab, op.params.cool_frac_tab, ...
        cycle.PLA, 'pchip', 'extrap');
end
bleed_frac = max(min(bleed_frac, 0.15), 0.0);
cool_frac  = max(min(cool_frac,  0.10), 0.0);

mdot_bleed = orig_mdot_core * bleed_frac;
mdot_cool  = orig_mdot_core * cool_frac;
mdot_core_eff = max(orig_mdot_core - mdot_bleed - mdot_cool, 0);

cycle.mdot_core_nominal = orig_mdot_core;
cycle.mdot_bleed = mdot_bleed;
cycle.mdot_cool = mdot_cool;
cycle.mdot_core = mdot_core_eff;

cycle.Tt2 = T0 * (1 + (gamma - 1)/2 * M0.^2);
Pt2_ideal = p0 * (1 + (gamma - 1)/2 * M0.^2).^(gamma/(gamma-1));
cycle.Pt2 = cycle.eta_inlet * Pt2_ideal;
cycle.Tt_bypass = cycle.Tt2;

% -------------------------------------------------------------------------
% Compressor
% -------------------------------------------------------------------------
comp_in.Pt_in = cycle.Pt2;
comp_in.Tt_in = cycle.Tt2;
comp_params.PR  = getfieldwithdefault(cycle,'PR_comp_eff', getfieldwithdefault(op.params,'PR_c',12.0));
comp_params.eta = getfieldwithdefault(cycle,'eta_comp_eff', getfieldwithdefault(op.params,'eta_c',0.85));
comp = compressor_model(cfg, comp_in, comp_params);
cycle.Pt3 = comp.Pt_out;
cycle.Tt3 = comp.Tt_out;
cycle.wc  = comp.w_specific;

% -------------------------------------------------------------------------
% Combustor (PLA scheduled main burner only)
% -------------------------------------------------------------------------
PLA = cycle.PLA;
AB  = cycle.AB;

Tt4_cmd  = schedule_Tt4_main(PLA, op.params);

comb_in.Pt_in = cycle.Pt3;
comb_in.Tt_in = cycle.Tt3;
comb_in.mdot_air = cycle.mdot_core;
comb_params.Tt_out_target = Tt4_cmd;
comb_params.dp_frac       = op.params.p_drop_comb;
comb_params.eta_burner    = getfieldwithdefault(op.params,'eta_burner_main',0.98);
comb = combustion_model(cfg, comb_in, comb_params);
cycle.Pt4 = comb.Pt_out;
cycle.Tt4 = comb.Tt_out;
cycle.f   = comb.f;
cycle.Tt4_cmd = Tt4_cmd;
cycle.mdot_fuel_core = getfieldwithdefault(comb,'mdot_fuel', NaN);
cycle.mdot_fuel_main = cycle.mdot_fuel_core;
cycle.mdot_core_hot = getfieldwithdefault(comb,'mdot_air_out', cycle.mdot_core * (1 + cycle.f));
cycle.gamma_hot = getfieldwithdefault(comb,'gamma_hot', getfieldwithdefault(cfg.const,'gamma_hot', cfg.const.gamma));

% -------------------------------------------------------------------------
% Turbine (drive compressor work)
% -------------------------------------------------------------------------
turb_in.Pt_in = cycle.Pt4;
turb_in.Tt_in = cycle.Tt4;
turb_params.w_required = cycle.wc * (1 + cycle.f);
turb_params.eta        = op.params.eta_t;
turb = turbine_model(cfg, turb_in, turb_params);
cycle.Tt5 = turb.Tt_out;
cycle.Pt5 = turb.Pt_out;
cycle.wt_hot = turb.w_specific;
f_core = getfieldwithdefault(cycle,'f',0);
wt_mass_factor = 1 + max(f_core, 0);
if ~isfinite(wt_mass_factor) || wt_mass_factor <= 0
    wt_mass_factor = 1;
end
cycle.wt  = turb.w_specific / wt_mass_factor;
cycle.mdot_core_hot = getfieldwithdefault(cycle,'mdot_core_hot', cycle.mdot_core * (1 + cycle.f));

% -------------------------------------------------------------------------
% Augmentor (afterburner adds heat after turbine)
% -------------------------------------------------------------------------
aug_in.Tt5 = cycle.Tt5;
aug_in.Pt5 = cycle.Pt5;
aug_in.mdot_core = cycle.mdot_core_hot;
aug_in.AB        = cycle.AB;
aug_in.params    = op.params;
aug = augmentor_model(cfg, aug_in);
cycle.Tt9 = getfieldwithdefault(aug,'Tt9', cycle.Tt5);
cycle.Pt9 = getfieldwithdefault(aug,'Pt9', cycle.Pt5);
cycle.dTt_ab_cmd = getfieldwithdefault(aug,'dTt_ab_cmd', AB * getfieldwithdefault(op.params,'dTt_ab_max',0));
cycle.mdot_fuel_ab = getfieldwithdefault(aug,'mdot_fuel_ab', 0.0);
cycle.f_ab = cycle.mdot_fuel_ab / max(cycle.mdot_core, 1e-9);
cycle.mdot_core_aug = cycle.mdot_core_hot + cycle.mdot_fuel_ab;
cycle.mdot_fuel_total = cycle.mdot_fuel_core + cycle.mdot_fuel_ab;
if isfield(aug,'cp_hot')
    cp_hot = aug.cp_hot;
    gamma_hot_ab = cp_hot / max(cp_hot - cfg.const.R, eps);
    cycle.gamma_hot = gamma_hot_ab;
end

% -------------------------------------------------------------------------
% Fan / bypass duct (simple fan on bypass stream)
% -------------------------------------------------------------------------
if getfieldwithdefault(op.params,'PR_fan',1.0) > 1.0
    fan_in.Pt_in = cycle.Pt2;
    fan_in.Tt_in = cycle.Tt2;
    fan_params.PR  = getfieldwithdefault(op.params,'PR_fan',1.60);
    fan_params.eta = getfieldwithdefault(op.params,'eta_fan',0.90);
    fan = compressor_model(cfg, fan_in, fan_params);
    cycle.Tt_bypass = fan.Tt_out;
    cycle.Pt_bypass = fan.Pt_out;
else
    cycle.Tt_bypass = getfieldwithdefault(cycle,'Tt_bypass', cycle.Tt2);
    cycle.Pt_bypass = getfieldwithdefault(cycle,'Pt_bypass', cycle.Pt2);
end

% -------------------------------------------------------------------------
% Nozzle (optional – preserves legacy behavior if params missing)
% -------------------------------------------------------------------------
have_legacy_nozz = isfield(op,'params') && ...
    (isfield(op.params,'A_nozzle') || isfield(op.params,'A_nozzle_exit'));
have_table_nozz = isfield(op,'params') && ( ...
    isfield(op.params,'A8_idle') || isfield(op.params,'A8_dry') || isfield(op.params,'A8_ab'));

if have_legacy_nozz || have_table_nozz

    mdot_core = getfieldwithdefault(cycle,'mdot_core_aug', cycle.mdot_core);
    mdot_fan  = cycle.mdot_fan;
    mdot_total = mdot_core + mdot_fan;
    if mdot_total <= 0
        error('Total mass flow into mixer is non-positive.');
    end
    cycle.mdot_total = mdot_total;

    Tt_core = getfieldwithdefault(cycle,'Tt9', cycle.Tt5);
    Pt_core = getfieldwithdefault(cycle,'Pt9', cycle.Pt5);
    Tt_bypass = getfieldwithdefault(op.params,'Tt_bypass_mix', ...
        getfieldwithdefault(cycle,'Tt_bypass', cycle.Tt2));
    Pt_bypass = getfieldwithdefault(cycle,'Pt_bypass', cycle.Pt2);

    cycle.Tt5_core = Tt_core;
    cycle.Pt5_core = Pt_core;
    cycle.Tt5_bypass = Tt_bypass;
    cycle.Pt5_bypass = Pt_bypass;
    cycle.mdot_bypass = mdot_fan;

    Tt_mix = (mdot_core * cycle.Tt5_core + mdot_fan * cycle.Tt5_bypass) / mdot_total;
    Pt_mix_raw = (mdot_core * cycle.Pt5_core + mdot_fan * cycle.Pt5_bypass) / mdot_total;
    deltaP_mix = getfieldwithdefault(op.params,'deltaP_mix_frac',0.02);
    deltaP_mix = min(max(deltaP_mix,0.0),0.2);
    Pt_mix = Pt_mix_raw * (1 - deltaP_mix);

    cycle.Tt9_mix = Tt_mix;
    cycle.Pt9_mix = Pt_mix;
    cycle.mdot_mix = mdot_total;

    if isfield(cycle,'Tt9_mix') && isfield(cycle,'Pt9_mix') && isfield(cycle,'mdot_mix')
        nozzle_inputs.Pt_in   = cycle.Pt9_mix;
        nozzle_inputs.Tt_in   = cycle.Tt9_mix;
        nozzle_inputs.mdot_in = cycle.mdot_mix;
    else
        nozzle_inputs.Pt_in   = cycle.Pt9;
        nozzle_inputs.Tt_in   = cycle.Tt9;
        nozzle_inputs.mdot_in = mdot_total;
    end
    cycle.mdot = mdot_total;
    cycle.Tt9_in = nozzle_inputs.Tt_in;
    cycle.Pt9_in = nozzle_inputs.Pt_in;

    atm_for_noz = atm;
    if ~isfield(atm_for_noz,'p0')
        atm_for_noz.p0 = p0;
    end
    if ~isfield(atm_for_noz,'T0')
        atm_for_noz.T0 = T0;
    end

    [A8_cmd, A9_cmd, Cd_noz_cmd] = resolve_nozzle_geometry(cycle.PLA, cycle.AB, M0, op.params);
    cycle.A8_cmd = A8_cmd;
    cycle.A9_cmd = A9_cmd;
    cycle.Cd_noz = Cd_noz_cmd;

    noz_pars = struct( ...
        'A_nozzle',     A8_cmd, ...
        'A_nozzle_exit',A9_cmd, ...
        'Cd_noz',       Cd_noz_cmd, ...
        'nozzle_type',  getfieldwithdefault(op.params,'nozzle_type','convergent'), ...
        'mdot_fan',     0);

    const_hot = cfg.const;
    const_hot.gamma_hot = getfieldwithdefault(cycle,'gamma_hot', getfieldwithdefault(cfg.const,'gamma_hot', cfg.const.gamma));
    cycle.nozzle = nozzle_model( ...
        nozzle_inputs.Pt_in, ...
        nozzle_inputs.Tt_in, ...
        nozzle_inputs.mdot_in, ...
        atm_for_noz, ...
        noz_pars, ...
        const_hot);

    % Pure-physics nozzle thrust followed by empirical scaling
    cycle.Fg_unscaled = cycle.nozzle.Fg;
    scale = resolve_thrust_scale(cycle.PLA, cycle.AB_sched, cycle.AB, op.params, cycle.M0, cycle.alt);
    cycle.thrust_scale_lookup = scale;
    cycle.thrust_scale = scale;  % empirical thrust scaling
    cycle.tsfc_scale = resolve_tsfc_scale(cycle.PLA, cycle.AB_sched, cycle.AB, op.params);

    cycle.Fg        = cycle.Fg_unscaled * cycle.thrust_scale;
    cycle.Ve        = cycle.nozzle.Ve;
    cycle.mdot      = cycle.nozzle.mdot;
    cycle.mdot_geom = cycle.nozzle.mdot_geom;
else
    cycle.nozzle = struct('Fg',NaN,'Ve',NaN,'mdot',NaN);
    cycle.Fg_unscaled = cycle.nozzle.Fg;
    scale = resolve_thrust_scale(cycle.PLA, cycle.AB_sched, cycle.AB, op.params, cycle.M0, cycle.alt);
    cycle.thrust_scale_lookup = scale;
    cycle.thrust_scale = scale;
    cycle.tsfc_scale = 1.0;  % default if nozzle not solved
    cycle.Fg   = cycle.Fg_unscaled * cycle.thrust_scale;
    cycle.Ve   = cycle.nozzle.Ve;
    cycle.mdot = cycle.nozzle.mdot;
    cycle.mdot_geom = NaN;
end

% Nozzle_model already subtracts freestream momentum (Ve - V0 term), so the
% only additional drag we remove here is inlet/cowl aerodynamic drag.
ram_drag = getfieldwithdefault(cycle,'ram_drag', getfieldwithdefault(cycle,'D_inlet',0));
cycle.ram_drag = ram_drag;
cycle.Fn = cycle.Fg - ram_drag;
cycle.params = op.params;

% -------------------------------------------------------------------------
% Summaries / outputs
% -------------------------------------------------------------------------
sumo = compute_outputs(cfg, cycle);

out = struct();
out.Pt2 = cycle.Pt2; out.Pt3 = cycle.Pt3; out.Pt4 = cycle.Pt4;
out.Tt2 = cycle.Tt2; out.Tt3 = cycle.Tt3; out.Tt4 = cycle.Tt4;
out.eta_c = comp.eta; out.eta_t = turb.eta;
out.wc = cycle.wc; out.wt = cycle.wt;
out.metrics = sumo;
out.Thrust = sumo.Thrust; out.TSFC = sumo.TSFC;
if nargin < 3 || ~isstruct(state_in)
    out.state = struct();
else
    out.state = state_in;
end
out.Thrust_gross = sumo.Thrust_gross;
out.Thrust_net = sumo.Thrust_net;
out.ram_drag = sumo.Ram_drag;
end

function cycle = estimate_mass_flows_and_maps(cycle, op)
rho0 = getfieldwithdefault(cycle,'rho0',1.225);
V0   = getfieldwithdefault(cycle,'V0',0);
M0   = getfieldwithdefault(cycle,'M0',0);
alt  = getfieldwithdefault(cycle,'alt',0);
T0   = getfieldwithdefault(cycle,'T0',288.15);
p0   = getfieldwithdefault(cycle,'p0', rho0 * getfieldwithdefault(cycle,'R', 287.0) * T0);
gamma = getfieldwithdefault(cycle,'gamma', getfieldwithdefault(op,'gamma', 1.4));
R     = getfieldwithdefault(cycle,'R',     getfieldwithdefault(op,'R', 287.0));

mdot_core_nom = getfieldwithdefault(op.params,'mdot_core_nom', ...
    getfieldwithdefault(op.params,'mdot_core', NaN));
mdot_fan_nom  = getfieldwithdefault(op.params,'mdot_fan_nom', ...
    getfieldwithdefault(op.params,'mdot_fan', 0.0));

rho_ref = getfieldwithdefault(op.params,'rho_ref', 1.225);
T_ref   = getfieldwithdefault(op.params,'T_ref', 288.15);
Pt_ref  = getfieldwithdefault(op.params,'Pt_ref', rho_ref * R * T_ref);
Tt_ref  = getfieldwithdefault(op.params,'Tt_ref', T_ref);

if alt < 50 && abs(M0) < 1e-3
    mdot_core = mdot_core_nom;
    mdot_fan  = mdot_fan_nom;
else
    % Corrected mass flow using freestream totals (Mattingly-style)
    Tt0 = T0 * (1 + 0.5*(gamma - 1) * M0.^2);
    Pt0 = p0 * (1 + 0.5*(gamma - 1) * M0.^2).^(gamma/(gamma-1));
    Wc_ratio = (Pt0 / sqrt(max(Tt0, eps))) / (Pt_ref / sqrt(max(Tt_ref, eps)));
    Wc_ratio = max(min(Wc_ratio, 2.0), 0.5);  % clamp to avoid runaway growth

    % Target core + fan flows based on nominal corrected flow
    mdot_core_target = mdot_core_nom * Wc_ratio;
    mdot_fan_target  = mdot_fan_nom  * Wc_ratio;

    % Do not exceed inlet capture capability (smoothed)
    mdot_capture = getfieldwithdefault(cycle,'mdot_capture', mdot_core_nom + mdot_fan_nom);
    mdot_total_target = mdot_core_target + mdot_fan_target;

    % Smooth, bounded swallow scaling to avoid thrust collapse
    swallow_scale = mdot_capture / max(mdot_total_target, 1e-9);
    swallow_scale = max(min(swallow_scale, 1.05), 0.60);

    mdot_core = mdot_core_target * swallow_scale;
    mdot_fan  = mdot_fan_target  * swallow_scale;

    % Safety cap on growth (usually not binding once swallow_scale is applied)
    growth_cap = getfieldwithdefault(op.params,'mdot_growth_cap', 1.8);
    scale_cap  = min(1.0, growth_cap * mdot_core_nom / max(mdot_core, 1e-9));
    mdot_core  = mdot_core * scale_cap;
    mdot_fan   = mdot_fan  * scale_cap;
end

% Apply PLA-based mass-flow scaling (reduces low-power overprediction)
PLA = getfieldwithdefault(op,'PLA', NaN);
if isfinite(PLA) && isfield(op.params,'mdot_pla_tab') && isfield(op.params,'mdot_pla_scale')
    pla_tab = op.params.mdot_pla_tab;
    pla_vals = op.params.mdot_pla_scale;
    if numel(pla_tab) == numel(pla_vals) && numel(pla_tab) >= 2
        mdot_scale = interp1(pla_tab, pla_vals, PLA, 'pchip', 'extrap');
        mdot_core = mdot_core * mdot_scale;
        mdot_fan  = mdot_fan  * mdot_scale;
    end
end

cycle.mdot_core = mdot_core;
cycle.mdot_fan  = mdot_fan;
cycle.mdot_total = mdot_core + mdot_fan;

% Safety check: ensure mass flows are finite and positive
if ~isfinite(cycle.mdot_core) || cycle.mdot_core <= 0
    cycle.mdot_core = mdot_core_nom;
end
if ~isfinite(cycle.mdot_fan) || cycle.mdot_fan <= 0
    cycle.mdot_fan = mdot_fan_nom;
end
if ~isfinite(cycle.mdot_total) || cycle.mdot_total <= 0
    cycle.mdot_total = mdot_core_nom + mdot_fan_nom;
end

M_ref = getfieldwithdefault(op.params,'M_ref', 0.0);
alt_ref = getfieldwithdefault(op.params,'alt_ref', 0.0);
dM = max(M0 - M_ref, 0);
dalt = max(alt - alt_ref, 0) / 1e4;
PR_scale = 1.0 ...
    - getfieldwithdefault(op.params,'PR_M_slope',0)   * dM ...
    - getfieldwithdefault(op.params,'PR_alt_slope',0) * dalt;
eta_scale = 1.0 ...
    - getfieldwithdefault(op.params,'eta_M_slope',0)   * dM ...
    - getfieldwithdefault(op.params,'eta_alt_slope',0) * dalt;

PR_scale = max(PR_scale, 0.6);
eta_scale = max(eta_scale, 0.7);

PR_base = getfieldwithdefault(op.params,'PR_c', ...
    getfieldwithdefault(op.params,'PR_comp_ref', 10));
eta_base = getfieldwithdefault(op.params,'eta_c', ...
    getfieldwithdefault(op.params,'eta_comp_ref', 0.85));
cycle.PR_comp_eff = PR_base * PR_scale;
cycle.eta_comp_eff = eta_base * eta_scale;
end

function ab_cmd = shape_ab_command(PLA, AB_sched, params)
ab_cmd = max(AB_sched, 0);
if ab_cmd <= 0
    ab_cmd = 0;
    return;
end

pla_idle = getfieldwithdefault(params,'PLA_idle',0.3);
pla_ab  = getfieldwithdefault(params,'PLA_max_ab',1.3);
if pla_ab <= pla_idle
    gain = 0;
else
    gain = (PLA - pla_idle) / (pla_ab - pla_idle);
end
gain = min(max(gain, 0), 1);
ab_cmd = ab_cmd * gain;
end

function scale = resolve_tsfc_scale(PLA, AB_sched, AB_cmd, params)
dry_scale = lookup_tsfc_scale(params, 'tsfc_scale_dry', 'pla_tsfc_dry_tab', PLA);
ab_scale  = lookup_tsfc_scale(params, 'tsfc_scale_ab', 'pla_tsfc_ab_tab', PLA);
blend = min(max(AB_cmd, 0), 1);
scale = dry_scale + (ab_scale - dry_scale) * blend;
end

function scale = lookup_tsfc_scale(params, val_name, tab_name, PLA)
if isfield(params, val_name) && isfield(params, tab_name)
    pla_tab = params.(tab_name);
    vals    = params.(val_name);
    if numel(pla_tab) == numel(vals) && numel(pla_tab) >= 2
        scale = interp1(pla_tab, vals, PLA, 'pchip', 'extrap');
        return;
    end
end
scale = getfieldwithdefault(params,'tsfc_scale',1.0);
end

function scale = resolve_thrust_scale(PLA, AB_sched, AB_cmd, params, M0, alt)
% Base dry/AB scale from tables or constants
dry_scale = lookup_thrust_scale(params, 'thrust_scale_dry', 'thrust_scale_dry_tab', M0);
dry_scale = dry_scale * lookup_pla_scale(params, 'thrust_scale_dry_pla_tab', 'thrust_scale_dry_pla_vals', PLA);

ab_scale  = lookup_thrust_scale(params, 'thrust_scale_ab', 'thrust_scale_ab_tab', M0);
ab_scale  = ab_scale * lookup_pla_scale(params, 'thrust_scale_ab_pla_tab', 'thrust_scale_ab_pla_vals', PLA);

blend = min(max(AB_cmd, 0), 1);
scale = dry_scale + (ab_scale - dry_scale) * blend;

% Mach-dependent correction (bounded)
if isfield(params,'mach_thrust_corr_tab') && isfield(params,'mach_thrust_corr_vals')
    mach_tab  = params.mach_thrust_corr_tab;
    mach_vals = params.mach_thrust_corr_vals;
    if numel(mach_tab) == numel(mach_vals) && numel(mach_tab) >= 2
        mach_corr = interp1(mach_tab, mach_vals, M0, 'pchip', 'extrap');
        mach_corr = max(min(mach_corr, 1.30), 0.70);
        scale = scale * mach_corr;
    end
end

% Altitude-dependent correction (bounded)
if isfield(params,'alt_thrust_corr_tab') && isfield(params,'alt_thrust_corr_vals')
    alt_tab  = params.alt_thrust_corr_tab;
    alt_vals = params.alt_thrust_corr_vals;
    if numel(alt_tab) == numel(alt_vals) && numel(alt_tab) >= 2
        alt_corr = interp1(alt_tab, alt_vals, alt, 'pchip', 'extrap');
        alt_corr = max(min(alt_corr, 1.30), 0.70);
        scale = scale * alt_corr;
    end
end

% PLA-dependent correction (bounded)
if isfield(params,'pla_thrust_corr_tab') && isfield(params,'pla_thrust_corr_vals')
    pla_tab  = params.pla_thrust_corr_tab;
    pla_vals = params.pla_thrust_corr_vals;
    if numel(pla_tab) == numel(pla_vals) && numel(pla_tab) >= 2
        pla_corr = interp1(pla_tab, pla_vals, PLA, 'pchip', 'extrap');
        pla_corr = max(min(pla_corr, 1.30), 0.70);
        scale = scale * pla_corr;
    end
end

% Final safety clamp: allow stronger boost if needed
scale = max(min(scale, 2.0), 0.4);
end

function scale = lookup_thrust_scale(params, base_name, table_name, M0)
% Get base scale factor (global multiplier)
base_scale = getfieldwithdefault(params, base_name, 1.0);

% If Mach-dependent tables exist, use them INSTEAD OF base scale
% (for backward compatibility with existing table-based designs)
if isfield(params,'thrust_scale_M_tab') && isfield(params, table_name)
    M_tab = params.thrust_scale_M_tab;
    val_tab = params.(table_name);
    if numel(M_tab) == numel(val_tab) && numel(M_tab) >= 2
        scale = interp1(M_tab, val_tab, M0, 'pchip', 'extrap');
        return;  % Use table values directly, ignore base scale
    end
end

% No table found; use base scale
scale = base_scale;
end

function scale = lookup_pla_scale(params, tab_name, val_name, PLA)
if isfield(params, tab_name) && isfield(params, val_name)
    pla_tab = params.(tab_name);
    pla_vals = params.(val_name);
    if numel(pla_tab) == numel(pla_vals) && numel(pla_tab) >= 2
        scale = interp1(pla_tab, pla_vals, PLA, 'pchip', 'extrap');
        return;
    end
end
scale = 1.0;
end

function Tt4_cmd = schedule_Tt4_main(PLA, params)
pla = PLA;
% Use 5-point schedule from params for better fidelity at low power
dry_breaks = getfieldwithdefault(params,'pla_breaks_dry', [0.30 0.50 0.70 0.87 1.00]);
dry_vals = getfieldwithdefault(params,'Tt4_dry_table', ...
    [1100 1400 1550 1670 1670]);
pla_clamped = min(max(pla, min(dry_breaks)), max(dry_breaks));
Tt4_cmd = interp1(dry_breaks, dry_vals, pla_clamped, 'pchip', 'extrap');
Tt4_max = getfieldwithdefault(params,'Tt4_main_max', max(dry_vals));
Tt4_cmd = min(Tt4_cmd, Tt4_max);
end

function [A8_eff, A9_eff, Cd_noz] = resolve_nozzle_geometry(PLA, AB, M0, params)
pla = PLA;
pla_idle = getfieldwithdefault(params,'PLA_idle',0.3);
pla_irt  = getfieldwithdefault(params,'PLA_irt',0.9);
pla_ab   = getfieldwithdefault(params,'PLA_max_ab',1.3);

% Use extended nozzle schedule if available for better fidelity
if isfield(params,'PLA_noz_schedule') && isfield(params,'A8_noz_schedule') && isfield(params,'A9_noz_schedule')
    pla_noz_sched = params.PLA_noz_schedule;
    A8_noz_sched  = params.A8_noz_schedule;
    A9_noz_sched  = params.A9_noz_schedule;
    
    if numel(pla_noz_sched) == numel(A8_noz_sched) && numel(pla_noz_sched) == numel(A9_noz_sched)
        if AB <= 0.5
            A8_base = interp1(pla_noz_sched, A8_noz_sched, pla, 'pchip', 'extrap');
            A9_base = interp1(pla_noz_sched, A9_noz_sched, pla, 'pchip', 'extrap');
        else
            % For AB, interpolate from dry max toward AB values
            A8_dry = A8_noz_sched(end);
            A8_ab = getfieldwithdefault(params,'A8_ab', A8_dry * 1.05);
            A9_dry = A9_noz_sched(end);
            A9_ab = getfieldwithdefault(params,'A9_ab', A9_dry * 1.067);
            A8_base = A8_dry + (A8_ab - A8_dry) * min(max(AB - 0.5, 0) * 2, 1);
            A9_base = A9_dry + (A9_ab - A9_dry) * min(max(AB - 0.5, 0) * 2, 1);
        end
    else
        % Fallback to old method
        if AB <= 0.5
            A8_base = interp1([pla_idle pla_irt], ...
                [getfieldwithdefault(params,'A8_idle',NaN), getfieldwithdefault(params,'A8_dry',NaN)], ...
                pla, 'linear', 'extrap');
            A9_base = interp1([pla_idle pla_irt], ...
                [getfieldwithdefault(params,'A9_idle',NaN), getfieldwithdefault(params,'A9_dry',NaN)], ...
                pla, 'linear', 'extrap');
        else
            A8_base = interp1([pla_irt pla_ab], ...
                [getfieldwithdefault(params,'A8_dry',NaN), getfieldwithdefault(params,'A8_ab',NaN)], ...
                pla, 'linear', 'extrap');
            A9_base = interp1([pla_irt pla_ab], ...
                [getfieldwithdefault(params,'A9_dry',NaN), getfieldwithdefault(params,'A9_ab',NaN)], ...
                pla, 'linear', 'extrap');
        end
    end
else
    % Fallback to original 2-point method
    if AB <= 0.5
        A8_base = interp1([pla_idle pla_irt], ...
            [getfieldwithdefault(params,'A8_idle',NaN), getfieldwithdefault(params,'A8_dry',NaN)], ...
            pla, 'linear', 'extrap');
        A9_base = interp1([pla_idle pla_irt], ...
            [getfieldwithdefault(params,'A9_idle',NaN), getfieldwithdefault(params,'A9_dry',NaN)], ...
            pla, 'linear', 'extrap');
    else
        A8_base = interp1([pla_irt pla_ab], ...
            [getfieldwithdefault(params,'A8_dry',NaN), getfieldwithdefault(params,'A8_ab',NaN)], ...
            pla, 'linear', 'extrap');
        A9_base = interp1([pla_irt pla_ab], ...
            [getfieldwithdefault(params,'A9_dry',NaN), getfieldwithdefault(params,'A9_ab',NaN)], ...
            pla, 'linear', 'extrap');
    end
end

M_tab = getfieldwithdefault(params,'M_noz_tab', [0 1]);
A8_scale = interp1(M_tab, getfieldwithdefault(params,'A8_M_scale_tab', ones(size(M_tab))), M0, 'pchip', 'extrap');
A9_scale = interp1(M_tab, getfieldwithdefault(params,'A9_M_scale_tab', ones(size(M_tab))), M0, 'pchip', 'extrap');

% NOTE: Physics-based area scaling removed - empirical approach is sufficient
% Original Mach-dependent scaling retained
A8_eff = A8_base * A8_scale;
A9_eff = A9_base * A9_scale;

PLA_noz_tab = getfieldwithdefault(params,'PLA_noz_tab', [0 1]);
Cd_noz_tab  = getfieldwithdefault(params,'Cd_noz_tab', ones(size(PLA_noz_tab)));
Cd_noz = interp1(PLA_noz_tab, Cd_noz_tab, pla, 'pchip', 'extrap');
end

function atm = resolve_atmosphere(op)
if isfield(op,'atm') && ~isempty(op.atm)
    atm = op.atm;
else
    atm = struct();
    fields = {'T0','p0','M0'};
    for k = 1:numel(fields)
        if isfield(op, fields{k})
            atm.(fields{k}) = op.(fields{k});
        end
    end
end

atm = collapse_scalar_fields(atm);

% If altitude provided (or user explicitly requests), compute ISA values
have_alt = isfield(atm,'alt');
force_std = isfield(atm,'use_standard_atm') && logical(atm.use_standard_atm);
use_standard = have_alt || force_std;

if use_standard
    alt_m = getfieldwithdefault(atm,'alt',0);
    try
        [Tstd, Pstd, Dstd] = standard_atmosphere(alt_m);
        if force_std || ~isfield(atm,'T0')
            atm.T0 = Tstd;
        end
        if force_std || ~isfield(atm,'p0')
            atm.p0 = Pstd;
        end
        atm.rho0 = Dstd;
    catch
        % If helper not available or fails, fall back silently
    end
end
end

function out = collapse_scalar_fields(in)
out = in;
if ~isstruct(in)
    return;
end

names = fieldnames(in);
for k = 1:numel(names)
    entry = in.(names{k});
    if isempty(entry)
        continue;
    end
    if isnumeric(entry) || islogical(entry)
        if numel(entry) > 1
            out.(names{k}) = entry(1);
        end
    elseif iscell(entry)
        out.(names{k}) = entry{1};
    end
end
end

function val = getfieldwithdefault(s, name, default)
if ~(isstruct(s) && isfield(s, name))
    val = default;
    return;
end

entry = s.(name);
if isempty(entry)
    val = default;
    return;
end

if isnumeric(entry) || islogical(entry)
    if numel(entry) == 1 || numel(default) == 1
        val = entry(1);
    else
        val = entry;
    end
elseif iscell(entry)
    if numel(entry) == 1 || numel(default) == 1
        val = entry{1};
    else
        val = entry;
    end
else
    val = entry;
end
end

function eta = inlet_recovery_simple(M0)
% Default inlet total-pressure recovery vs Mach (simple MIL-style law).
M = max(M0,0);
if M <= 0.2
    eta = 1.0;
elseif M <= 1.0
    % Drop to ~0.94 at M = 1
    eta = 1.0 - 0.075*(M - 0.2);
else
    % Additional losses in low supersonic; floor at 0.70
    eta = 0.94 - 0.45*(M - 1.0);
    eta = max(0.70, eta);
end
end



