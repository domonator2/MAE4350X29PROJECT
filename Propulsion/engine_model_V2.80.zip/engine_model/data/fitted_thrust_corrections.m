% Extended Mach table with denser points in critical 0.3-0.8 region
params.mach_thrust_corr_tab  = [0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.6];
params.mach_thrust_corr_vals = [1.0 1.0 1.0 1.0 1.0 1.0 1.0 1.0];
params.pla_thrust_corr_tab  = [0.7 0.87 0.925 1.09 1.3 ];
params.pla_thrust_corr_vals = [1.0 1.0 1.0 1.0 1.0 ];
params.alt_thrust_corr_tab  = [3048 9144 12192 ];
params.alt_thrust_corr_vals = [1.0 1.0 1.0 ];
